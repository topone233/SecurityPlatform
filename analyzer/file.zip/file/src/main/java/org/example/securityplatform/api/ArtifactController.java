package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.example.securityplatform.dto.ArtifactResponse;
import org.example.securityplatform.service.ArtifactService;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 制品管理 API 控制器
 */
@Tag(name = "制品管理", description = "制品包的上传、下载、查询等操作")
@RestController
@RequestMapping("/api/artifacts")
@RequiredArgsConstructor
public class ArtifactController {

    private final ArtifactService artifactService;

    /**
     * 上传制品
     */
    @Operation(summary = "上传制品", description = "上传 JAR/WAR 包作为测试制品")
    @PostMapping("/upload")
    public ArtifactResponse uploadArtifact(
            @Parameter(description = "任务ID") @RequestParam("taskId") Long taskId,
            @Parameter(description = "制品文件") @RequestParam("file") MultipartFile file,
            @Parameter(description = "制品类型: JAR, WAR, ZIP") @RequestParam("artifactType") String artifactType) {
        return artifactService.uploadArtifact(taskId, file, artifactType);
    }

    /**
     * 下载制品文件
     */
    @Operation(summary = "下载制品", description = "下载指定的制品文件")
    @GetMapping("/{id}/download")
    public ResponseEntity<Resource> downloadArtifact(
            @Parameter(description = "制品ID") @PathVariable Long id) {
        return artifactService.downloadArtifact(id);
    }

    /**
     * 根据 ID 查询制品
     */
    @Operation(summary = "根据ID查询制品", description = "根据制品ID获取制品详情")
    @GetMapping("/{id}")
    public ArtifactResponse getArtifactById(
            @Parameter(description = "制品ID") @PathVariable Long id) {
        return artifactService.getArtifactById(id);
    }

    /**
     * 根据任务 ID 查询制品列表
     */
    @Operation(summary = "根据任务ID查询制品", description = "获取指定任务下的所有制品")
    @GetMapping("/task/{taskId}")
    public List<ArtifactResponse> getArtifactsByTaskId(
            @Parameter(description = "任务ID") @PathVariable Long taskId) {
        return artifactService.getArtifactsByTaskId(taskId);
    }

    /**
     * 根据状态查询制品列表
     */
    @Operation(summary = "根据状态查询制品", description = "获取指定状态的所有制品")
    @GetMapping("/status/{status}")
    public List<ArtifactResponse> getArtifactsByStatus(
            @Parameter(description = "制品状态: PENDING, ANALYZING, COMPLETED, FAILED") @PathVariable String status) {
        return artifactService.getArtifactsByStatus(status);
    }

    /**
     * 查询所有制品
     */
    @Operation(summary = "查询所有制品", description = "获取所有制品列表")
    @GetMapping
    public List<ArtifactResponse> getAllArtifacts() {
        return artifactService.getAllArtifacts();
    }

    /**
     * 更新制品状态
     */
    @Operation(summary = "更新制品状态", description = "更新指定制品的状态")
    @PutMapping("/{id}/status")
    public ArtifactResponse updateArtifactStatus(
            @Parameter(description = "制品ID") @PathVariable Long id,
            @Parameter(description = "新状态: PENDING, ANALYZING, COMPLETED, FAILED") @RequestParam String status) {
        return artifactService.updateArtifactStatus(id, status);
    }

    /**
     * 删除制品
     */
    @Operation(summary = "删除制品", description = "根据ID删除制品")
    @DeleteMapping("/{id}")
    public void deleteArtifact(
            @Parameter(description = "制品ID") @PathVariable Long id) {
        artifactService.deleteArtifact(id);
    }
}