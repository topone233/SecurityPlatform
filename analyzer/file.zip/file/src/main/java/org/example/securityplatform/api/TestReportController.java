package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.TestReportResponse;
import org.example.securityplatform.service.TestReportService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 测试报告控制器
 */
@Tag(name = "测试报告", description = "测试报告生成、查询和管理")
@RestController
@RequestMapping("/api/test-report")
@RequiredArgsConstructor
public class TestReportController {

    private final TestReportService reportService;

    /**
     * 生成测试报告
     */
    @Operation(summary = "生成测试报告", description = "根据测试执行结果生成测试报告")
    @PostMapping("/generate/{artifactId}")
    public Result<TestReportResponse> generateReport(
            @Parameter(description = "制品ID") @PathVariable Long artifactId,
            @Parameter(description = "报告类型: FULL, SUMMARY, RISK") @RequestParam(required = false) String reportType,
            @Parameter(description = "生成人") @RequestParam(required = false) String generatedBy) {
        TestReportResponse response = reportService.generateReport(artifactId, reportType, generatedBy);
        return Result.success(response);
    }

    /**
     * 获取报告
     */
    @Operation(summary = "获取报告", description = "根据ID获取测试报告详情")
    @GetMapping("/{id}")
    public Result<TestReportResponse> getReport(
            @Parameter(description = "报告ID") @PathVariable Long id) {
        TestReportResponse response = reportService.getReport(id);
        return Result.success(response);
    }

    /**
     * 获取制品的报告列表
     */
    @Operation(summary = "获取报告列表", description = "获取制品的所有测试报告")
    @GetMapping("/artifact/{artifactId}")
    public Result<List<TestReportResponse>> getReportsByArtifact(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        List<TestReportResponse> responses = reportService.getReportsByArtifact(artifactId);
        return Result.success(responses);
    }

    /**
     * 获取最新的完成报告
     */
    @Operation(summary = "获取最新报告", description = "获取制品最新的完成报告")
    @GetMapping("/latest/{artifactId}")
    public Result<TestReportResponse> getLatestReport(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        TestReportResponse response = reportService.getLatestReport(artifactId);
        return Result.success(response);
    }

    /**
     * 删除报告
     */
    @Operation(summary = "删除报告", description = "删除指定的测试报告")
    @DeleteMapping("/{id}")
    public Result<Void> deleteReport(
            @Parameter(description = "报告ID") @PathVariable Long id) {
        reportService.deleteReport(id);
        return Result.success(null);
    }
}
