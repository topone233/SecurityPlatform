package org.example.securityplatform.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 基线推荐响应
 */
@Data
public class BaselineRecommendationResponse {
    private Long projectId;
    private String projectName;

    // 推荐的基线制品
    private BaselineArtifact recommended;

    // 历史制品列表
    private List<BaselineArtifact> history;

    @Data
    public static class BaselineArtifact {
        private Long artifactId;
        private String artifactName;
        private Long taskId;
        private String taskName;
        private LocalDateTime testTime;
        private String taskStatus;
    }
}
