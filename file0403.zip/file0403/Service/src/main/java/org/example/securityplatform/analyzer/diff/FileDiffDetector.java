package org.example.securityplatform.analyzer.diff;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.jar.DependencyAnalysisConfig;
import org.example.securityplatform.analyzer.jar.JarInfo;
import org.example.securityplatform.analyzer.jar.MultiJarClasspathBuilder;
import org.example.securityplatform.util.HashUtil;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 文件差异检测器 - 对比两个JAR包的文件差异
 * 支持多JAR类路径分析
 */
@Slf4j
public class FileDiffDetector {

    private final String baselineJarPath;
    private final String targetJarPath;
    private final BytecodeDiffAnalyzer bytecodeDiffAnalyzer = new BytecodeDiffAnalyzer();

    // 多JAR支持
    private MultiJarClasspathBuilder baselineClasspath;
    private MultiJarClasspathBuilder targetClasspath;

    // 过滤配置（用户指定的业务包名/JAR名称）
    private DependencyAnalysisConfig filterConfig;

    public FileDiffDetector(String baselineJarPath, String targetJarPath) {
        this.baselineJarPath = baselineJarPath;
        this.targetJarPath = targetJarPath;
        this.filterConfig = DependencyAnalysisConfig.defaultConfig();
    }

    /**
     * 使用多JAR类路径构建器进行差异检测（带过滤配置）
     */
    public FileDiffDetector(MultiJarClasspathBuilder baselineClasspath,
                           MultiJarClasspathBuilder targetClasspath,
                           DependencyAnalysisConfig filterConfig) {
        this.baselineClasspath = baselineClasspath;
        this.targetClasspath = targetClasspath;
        // 从类路径中获取主JAR路径（用于向后兼容）
        this.baselineJarPath = null;
        this.targetJarPath = null;
        this.filterConfig = filterConfig != null ? filterConfig : DependencyAnalysisConfig.defaultConfig();
    }

    /**
     * 兼容旧版本：不带过滤配置的构造函数
     */
    public FileDiffDetector(MultiJarClasspathBuilder baselineClasspath,
                           MultiJarClasspathBuilder targetClasspath) {
        this(baselineClasspath, targetClasspath, DependencyAnalysisConfig.defaultConfig());
    }

    /**
     * 检测文件差异
     *
     * @return 文件差异列表
     */
    public List<FileDiffModel> detect() throws IOException {
        // 如果使用了多JAR类路径构建器，使用新的检测逻辑
        if (baselineClasspath != null && targetClasspath != null) {
            return detectWithClasspath();
        }

        // 向后兼容：使用传统的单JAR检测逻辑
        return detectSingleJar();
    }

    /**
     * 使用多JAR类路径进行差异检测（根据用户配置过滤）
     */
    private List<FileDiffModel> detectWithClasspath() throws IOException {
        log.info("开始多JAR文件差异检测，过滤配置: 包名={}, JAR名称={}",
                filterConfig.hasPackagePatterns() ? filterConfig.getIncludePackages() : "无",
                filterConfig.hasJarNamePatterns() ? filterConfig.getIncludeJarNames() : "无");

        List<FileDiffModel> diffs = new ArrayList<>();

        // 获取两个类路径的所有类
        Set<String> allPaths = new HashSet<>();
        allPaths.addAll(baselineClasspath.getAllClassPaths());
        allPaths.addAll(targetClasspath.getAllClassPaths());

        log.info("总共 {} 个唯一类路径需要对比", allPaths.size());

        // 根据用户配置过滤类文件
        int skippedByPackageFilter = 0;
        int skippedByJarFilter = 0;
        int skippedDependencyClasses = 0;

        // 对比每个类文件
        for (String path : allPaths) {
            MultiJarClasspathBuilder.ClassLocation baselineLoc = baselineClasspath.getClassLocation(path);
            MultiJarClasspathBuilder.ClassLocation targetLoc = targetClasspath.getClassLocation(path);

            // 1. 检查JAR名称过滤（如果用户指定了特定JAR）
            if (filterConfig.hasJarNamePatterns()) {
                boolean matchesJarPattern = false;
                String baselineJarName = baselineLoc != null ? baselineLoc.getJar().getName() : "";
                String targetJarName = targetLoc != null ? targetLoc.getJar().getName() : "";

                for (String pattern : filterConfig.getIncludeJarNames()) {
                    if (matchesPattern(baselineJarName, pattern) || matchesPattern(targetJarName, pattern)) {
                        matchesJarPattern = true;
                        break;
                    }
                }

                if (!matchesJarPattern) {
                    skippedByJarFilter++;
                    continue;
                }
            }

            // 2. 检查包名过滤（如果用户指定了特定包）
            if (filterConfig.hasPackagePatterns()) {
                String className = path.replace('/', '.').replace('\\', '.');
                if (className.endsWith(".class")) {
                    className = className.substring(0, className.length() - 6);
                }

                boolean matchesPackagePattern = false;
                for (String pattern : filterConfig.getIncludePackages()) {
                    if (className.startsWith(pattern) || matchesPattern(className, pattern)) {
                        matchesPackagePattern = true;
                        break;
                    }
                }

                if (!matchesPackagePattern) {
                    skippedByPackageFilter++;
                    continue;
                }
            } else {
                // 3. 没有指定包名过滤时，默认只关注主JAR（业务代码）
                boolean isBaselineMain = baselineLoc != null && baselineLoc.getJar().isMain();
                boolean isTargetMain = targetLoc != null && targetLoc.getJar().isMain();

                // 跳过：两边都是依赖库的类
                if (!isBaselineMain && !isTargetMain) {
                    skippedDependencyClasses++;
                    continue;
                }
            }

            // 分析符合条件的类文件
            FileDiffModel diff = analyzeFileDiffWithClasspath(path);
            if (diff != null && diff.hasChanges()) {
                diffs.add(diff);
            }
        }

        // 日志统计
        if (filterConfig.hasJarNamePatterns() || filterConfig.hasPackagePatterns()) {
            log.info("多JAR文件差异检测完成: 共 {} 个文件变更（跳过: JAR过滤={}, 包名过滤={}）",
                    diffs.size(), skippedByJarFilter, skippedByPackageFilter);
        } else {
            log.info("多JAR文件差异检测完成: 共 {} 个文件变更，跳过 {} 个依赖库类文件",
                    diffs.size(), skippedDependencyClasses);
        }
        return diffs;
    }

    /**
     * 简单的模式匹配（支持前缀匹配和通配符*）
     */
    private boolean matchesPattern(String text, String pattern) {
        if (pattern.endsWith("*")) {
            // 前缀匹配
            return text.startsWith(pattern.substring(0, pattern.length() - 1));
        } else if (pattern.startsWith("*")) {
            // 后缀匹配
            return text.endsWith(pattern.substring(1));
        } else if (pattern.contains("*")) {
            // 中间通配符（简化处理，只支持一个*）
            int starIndex = pattern.indexOf('*');
            String prefix = pattern.substring(0, starIndex);
            String suffix = pattern.substring(starIndex + 1);
            return text.startsWith(prefix) && text.endsWith(suffix);
        } else {
            // 精确匹配
            return text.equals(pattern);
        }
    }

    /**
     * 分析单个文件差异（使用多JAR类路径）
     */
    private FileDiffModel analyzeFileDiffWithClasspath(String path) throws IOException {
        FileDiffModel diff = new FileDiffModel();
        diff.setFilePath(path);
        diff.setSourceFilePath(FileDiffModel.inferSourcePath(path));

        MultiJarClasspathBuilder.ClassLocation baselineLoc = baselineClasspath.getClassLocation(path);
        MultiJarClasspathBuilder.ClassLocation targetLoc = targetClasspath.getClassLocation(path);

        boolean inBaseline = baselineLoc != null;
        boolean inTarget = targetLoc != null;

        if (!inBaseline && inTarget) {
            // 新增文件
            diff.setDiffType("ADDED");
            diff.setSourceJar(targetLoc.getJar().getName());
            diff.setJarType(targetLoc.getJar().getType().name());

            try (InputStream is = targetClasspath.getClassInputStream(path)) {
                diff.setTargetMd5(HashUtil.calculateMd5(is));
            }
            diff.setBaselineLines(0);
            diff.setTargetLines(0);
            diff.setMethodsAdded(0);

            return diff;

        } else if (inBaseline && !inTarget) {
            // 删除文件
            diff.setDiffType("DELETED");
            diff.setSourceJar(baselineLoc.getJar().getName());
            diff.setJarType(baselineLoc.getJar().getType().name());

            try (InputStream is = baselineClasspath.getClassInputStream(path)) {
                diff.setBaselineMd5(HashUtil.calculateMd5(is));
            }
            diff.setBaselineLines(0);
            diff.setTargetLines(0);
            diff.setMethodsDeleted(0);

            return diff;

        } else if (inBaseline && inTarget) {
            // 两边都有，检查是否修改
            diff.setSourceJar(baselineLoc.getJar().getName());  // 使用baseline的来源
            diff.setJarType(baselineLoc.getJar().getType().name());

            String baselineMd5;
            String targetMd5;
            byte[] baselineBytes;
            byte[] targetBytes;

            try (InputStream baselineIs = baselineClasspath.getClassInputStream(path);
                 InputStream targetIs = targetClasspath.getClassInputStream(path)) {

                // Read bytes once and reuse for both MD5 and bytecode analysis
                baselineBytes = baselineIs.readAllBytes();
                targetBytes = targetIs.readAllBytes();

                baselineMd5 = HashUtil.calculateMd5(new ByteArrayInputStream(baselineBytes));
                targetMd5 = HashUtil.calculateMd5(new ByteArrayInputStream(targetBytes));

                diff.setBaselineMd5(baselineMd5);
                diff.setTargetMd5(targetMd5);
            }

            if (baselineMd5.equals(targetMd5)) {
                // 内容相同
                boolean baselineIsMain = baselineLoc.getJar().isMain();
                boolean targetIsMain = targetLoc.getJar().isMain();

                // 只在跨JAR移动时才判断为MOVED（依赖JAR之间的移动）
                // 主JAR的版本变化不算MOVED
                if (!baselineIsMain && !targetIsMain) {
                    // 两个都是依赖JAR，检查是否跨JAR移动
                    if (!baselineLoc.getJar().getName().equals(targetLoc.getJar().getName())) {
                        diff.setDiffType("MOVED");
                        diff.setSourceJar(baselineLoc.getJar().getName() + " -> " + targetLoc.getJar().getName());
                        log.info("Class {} moved between dependency JARs: {} -> {}",
                                path, baselineLoc.getJar().getName(), targetLoc.getJar().getName());
                        return diff;
                    }
                }

                // 其他情况：未修改（包括主JAR版本变化但类内容不变的情况）
                diff.setDiffType("UNCHANGED");
                return null;
            }

            // 内容修改的文件
            diff.setDiffType("MODIFIED");

            // 检查是否同时发生了移动和修改
            if (!baselineLoc.getJar().getName().equals(targetLoc.getJar().getName())) {
                log.info("Class {} moved and modified from {} to {}",
                        path, baselineLoc.getJar().getName(), targetLoc.getJar().getName());
                diff.setSourceJar(baselineLoc.getJar().getName() + " -> " + targetLoc.getJar().getName());
            }

            // 字节码差异分析 - reuse the bytes
            try {
                BytecodeDiffResult bytecodeDiff = bytecodeDiffAnalyzer.analyze(
                    new ByteArrayInputStream(baselineBytes),
                    new ByteArrayInputStream(targetBytes),
                    path
                );
                diff.setBytecodeDiff(bytecodeDiff);
                diff.setBaselineLines(bytecodeDiff.getBaselineInstructions());
                diff.setTargetLines(bytecodeDiff.getTargetInstructions());
                diff.setMethodsAdded(bytecodeDiff.getMethodsAdded());
                diff.setMethodsDeleted(bytecodeDiff.getMethodsDeleted());
                diff.setMethodsModified(bytecodeDiff.getMethodsModified());

            } catch (Exception e) {
                log.warn("字节码差异分析失败，跳过: {}", path, e);
                diff.setBaselineLines(0);
                diff.setTargetLines(0);
                diff.setMethodsAdded(0);
                diff.setMethodsDeleted(0);
                diff.setMethodsModified(0);
            }

            return diff;
        }

        return null;
    }

    /**
     * 传统的单JAR差异检测（向后兼容）
     */
    private List<FileDiffModel> detectSingleJar() throws IOException {
        log.info("开始文件差异检测: baseline={}, target={}", baselineJarPath, targetJarPath);

        List<FileDiffModel> diffs = new ArrayList<>();

        // 获取两个JAR包的class文件列表
        Map<String, JarEntry> baselineEntries = getClassEntries(baselineJarPath);
        Map<String, JarEntry> targetEntries = getClassEntries(targetJarPath);

        log.info("基线JAR包含 {} 个class文件, 目标JAR包含 {} 个class文件",
                baselineEntries.size(), targetEntries.size());

        Set<String> allPaths = new HashSet<>();
        allPaths.addAll(baselineEntries.keySet());
        allPaths.addAll(targetEntries.keySet());

        log.info("总共需要对比 {} 个文件", allPaths.size());

        int addedCount = 0, deletedCount = 0, modifiedCount = 0, unchangedCount = 0;

        // 对比每个文件
        for (String path : allPaths) {
            FileDiffModel diff = analyzeFileDiff(path, baselineEntries, targetEntries);
            if (diff != null) {
                if (diff.hasChanges()) {
                    diffs.add(diff);
                    switch (diff.getDiffType()) {
                        case "ADDED": addedCount++; break;
                        case "DELETED": deletedCount++; break;
                        case "MODIFIED": modifiedCount++; break;
                    }
                } else {
                    unchangedCount++;
                }
            } else {
                // diff为null说明文件未变更（analyzeFileDiff返回null）
                unchangedCount++;
            }
        }

        log.info("文件差异检测完成: 新增={}, 删除={}, 修改={}, 未变更={}",
                addedCount, deletedCount, modifiedCount, unchangedCount);
        return diffs;
    }

    /**
     * 获取JAR包中的所有class文件
     */
    private Map<String, JarEntry> getClassEntries(String jarPath) throws IOException {
        Map<String, JarEntry> entries = new HashMap<>();
        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> enumeration = jarFile.entries();
            while (enumeration.hasMoreElements()) {
                JarEntry entry = enumeration.nextElement();
                if (entry.getName().endsWith(".class") && !entry.isDirectory()) {
                    entries.put(entry.getName(), entry);
                }
            }
        }
        return entries;
    }

    /**
     * 分析单个文件的差异
     */
    private FileDiffModel analyzeFileDiff(String path,
                                           Map<String, JarEntry> baselineEntries,
                                           Map<String, JarEntry> targetEntries) throws IOException {
        FileDiffModel diff = new FileDiffModel();
        diff.setFilePath(path);
        diff.setSourceFilePath(FileDiffModel.inferSourcePath(path));

        boolean inBaseline = baselineEntries.containsKey(path);
        boolean inTarget = targetEntries.containsKey(path);

        if (!inBaseline && inTarget) {
            // 新增文件
            log.debug("检测到新增文件: {}", path);
            diff.setDiffType("ADDED");
            diff.setBaselineLines(0);
            diff.setBaselineMd5(null);

            try (JarFile targetJar = new JarFile(targetJarPath)) {
                JarEntry entry = targetEntries.get(path);
                try (InputStream is = targetJar.getInputStream(entry)) {
                    diff.setTargetMd5(HashUtil.calculateMd5(is));
                }
                // 字节码分析对于新增的文件跳过，因为没有基线可对比
                diff.setTargetLines(0);
                diff.setMethodsAdded(0);
            } catch (Exception e) {
                log.warn("分析新增的文件失败: {}", path, e);
            }
            return diff;

        } else if (inBaseline && !inTarget) {
            // 删除文件
            diff.setDiffType("DELETED");
            diff.setTargetLines(0);
            diff.setTargetMd5(null);

            try (JarFile baselineJar = new JarFile(baselineJarPath)) {
                JarEntry entry = baselineEntries.get(path);
                try (InputStream is = baselineJar.getInputStream(entry)) {
                    diff.setBaselineMd5(HashUtil.calculateMd5(is));
                }
                // 字节码分析对于删除的文件跳过，因为没有目标文件可对比
                diff.setBaselineLines(0);
                diff.setMethodsDeleted(0);
            } catch (Exception e) {
                log.warn("分析删除的文件失败: {}", path, e);
            }
            return diff;

        } else if (inBaseline && inTarget) {
            // 两边都有，检查是否修改
            try (JarFile baselineJar = new JarFile(baselineJarPath);
                 JarFile targetJar = new JarFile(targetJarPath)) {

                JarEntry baselineEntry = baselineEntries.get(path);
                JarEntry targetEntry = targetEntries.get(path);

                try (InputStream baselineIs = baselineJar.getInputStream(baselineEntry);
                     InputStream targetIs = targetJar.getInputStream(targetEntry)) {

                    // Read bytes once and reuse for both MD5 and bytecode analysis
                    byte[] baselineBytes = baselineIs.readAllBytes();
                    byte[] targetBytes = targetIs.readAllBytes();

                    String baselineMd5 = HashUtil.calculateMd5(new ByteArrayInputStream(baselineBytes));
                    String targetMd5 = HashUtil.calculateMd5(new ByteArrayInputStream(targetBytes));

                    diff.setBaselineMd5(baselineMd5);
                    diff.setTargetMd5(targetMd5);

                    if (baselineMd5.equals(targetMd5)) {
                        // 未修改
                        diff.setDiffType("UNCHANGED");
                        log.debug("文件未变更: {}, MD5={}", path, baselineMd5);
                        return null;
                    }

                    // 修改的文件
                    log.info("检测到修改文件: {}, baselineMD5={}, targetMD5={}", path, baselineMd5, targetMd5);
                    diff.setDiffType("MODIFIED");

                    // Use the same bytes for bytecode analysis
                    try {
                        BytecodeDiffResult bytecodeDiff = analyzeBytecode(
                            new ByteArrayInputStream(baselineBytes),
                            new ByteArrayInputStream(targetBytes),
                            path
                        );
                        diff.setBytecodeDiff(bytecodeDiff);
                        diff.setBaselineLines(bytecodeDiff.getBaselineInstructions());
                        diff.setTargetLines(bytecodeDiff.getTargetInstructions());
                        diff.setMethodsAdded(bytecodeDiff.getMethodsAdded());
                        diff.setMethodsDeleted(bytecodeDiff.getMethodsDeleted());
                        diff.setMethodsModified(bytecodeDiff.getMethodsModified());
                    } catch (Exception e) {
                        log.warn("字节码差异分析失败，跳过: {}", path, e);
                        // 设置默认值
                        diff.setBaselineLines(0);
                        diff.setTargetLines(0);
                        diff.setMethodsAdded(0);
                        diff.setMethodsDeleted(0);
                        diff.setMethodsModified(0);
                    }
                }
            }
            return diff;
        }

        return null;
    }

    /**
     * 分析字节码差异
     */
    private BytecodeDiffResult analyzeBytecode(InputStream baselineStream,
                                                 InputStream targetStream,
                                                 String filePath) throws IOException {
        return bytecodeDiffAnalyzer.analyze(baselineStream, targetStream, filePath);
    }

    /**
     * 获取差异统计
     */
    public DiffStatistics getStatistics(List<FileDiffModel> diffs) {
        DiffStatistics stats = new DiffStatistics();
        for (FileDiffModel diff : diffs) {
            switch (diff.getDiffType()) {
                case "ADDED":
                    stats.addedFiles++;
                    break;
                case "DELETED":
                    stats.deletedFiles++;
                    break;
                case "MODIFIED":
                    stats.modifiedFiles++;
                    break;
            }
            stats.totalMethodsAdded += diff.getMethodsAdded();
            stats.totalMethodsDeleted += diff.getMethodsDeleted();
            stats.totalMethodsModified += diff.getMethodsModified();
        }
        return stats;
    }

    /**
     * 差异统计
     */
    @lombok.Data
    public static class DiffStatistics {
        private int addedFiles = 0;
        private int modifiedFiles = 0;
        private int deletedFiles = 0;
        private int totalMethodsAdded = 0;
        private int totalMethodsDeleted = 0;
        private int totalMethodsModified = 0;
    }
}