package org.example.securityplatform.analyzer.diff;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.jar.JarInfo;
import org.example.securityplatform.analyzer.jar.MultiJarClasspathBuilder;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 调用图构建器 - 使用ASM分析字节码，构建方法调用关系
 * 支持单JAR和多JAR两种模式
 */
@Slf4j
public class CallGraphBuilder {

    // 单JAR模式
    private final String jarPath;

    // 多JAR模式
    private final List<JarInfo> jars;
    private final MultiJarClasspathBuilder classpathBuilder;

    private final List<MethodCallModel> callGraph = new ArrayList<>();

    /**
     * 单JAR构造函数（向后兼容）
     */
    public CallGraphBuilder(String jarPath) {
        this.jarPath = jarPath;
        this.jars = null;
        this.classpathBuilder = null;
    }

    /**
     * 多JAR构造函数
     */
    public CallGraphBuilder(List<JarInfo> jars) {
        this.jarPath = null;
        this.jars = jars;
        this.classpathBuilder = new MultiJarClasspathBuilder(jars);
    }

    /**
     * 构建调用图
     */
    public List<MethodCallModel> build() throws IOException {
        if (classpathBuilder != null) {
            // 多JAR模式
            return buildMultiJar();
        } else {
            // 单JAR模式（向后兼容）
            return buildSingleJar();
        }
    }

    /**
     * 单JAR模式构建调用图
     */
    private List<MethodCallModel> buildSingleJar() throws IOException {
        log.info("开始构建调用图: {}", jarPath);

        int totalClassCount = 0;
        int bootInfClassCount = 0;
        int businessClassCount = 0;

        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> entries = jarFile.entries();

            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String entryName = entry.getName();

                if (entryName.endsWith(".class") && !entry.isDirectory()) {
                    totalClassCount++;

                    // 统计不同类型的class文件
                    if (entryName.startsWith("BOOT-INF/classes/")) {
                        bootInfClassCount++;
                    } else if (!entryName.contains("/") || entryName.split("/").length <= 2) {
                        // 根目录或浅层目录的class（通常是工具类）
                    } else {
                        // 其他嵌套较深的class（可能是业务代码）
                        businessClassCount++;
                    }

                    try (InputStream is = jarFile.getInputStream(entry)) {
                        ClassReader classReader = new ClassReader(is);
                        CallGraphClassVisitor visitor = new CallGraphClassVisitor(entryName);
                        classReader.accept(visitor, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
                        callGraph.addAll(visitor.getCalls());
                    } catch (IOException e) {
                        log.warn("解析class文件失败: {}", entryName, e);
                    }
                }
            }

            log.info("调用图构建统计: 总共 {} 个class文件, BOOT-INF/classes {} 个, 其他业务 {} 个",
                    totalClassCount, bootInfClassCount, businessClassCount);
        }

        log.info("调用图构建完成: 共 {} 条调用关系", callGraph.size());

        // 显示业务代码调用关系样例
        if (log.isInfoEnabled() && !callGraph.isEmpty()) {
            int sampleCount = 0;
            for (MethodCallModel call : callGraph) {
                // 只显示业务代码的调用关系（包含包名的）
                if (call.getCallerClass().contains(".") && call.getCallerClass().split("\\.").length > 2) {
                    if (sampleCount++ < 5) {
                        log.info("  业务调用关系 #{}: {}#{} -> {}#{}",
                                sampleCount,
                                call.getCallerClass(),
                                call.getCallerMethod(),
                                call.getCalleeClass(),
                                call.getCalleeMethod());
                    }
                }
            }

            if (sampleCount == 0) {
                log.warn("未找到任何业务代码调用关系！请检查JAR结构");
            }
        }

        return callGraph;
    }

    /**
     * 多JAR模式构建调用图
     */
    private List<MethodCallModel> buildMultiJar() throws IOException {
        log.info("开始构建调用图（多JAR模式）: {} 个JAR", jars.size());

        for (String classPath : classpathBuilder.getAllClassPaths()) {
            MultiJarClasspathBuilder.ClassLocation location = classpathBuilder.getClassLocation(classPath);
            if (location == null) {
                continue;
            }

            try (InputStream is = classpathBuilder.getClassInputStream(classPath)) {
                if (is == null) {
                    log.warn("无法获取类输入流: {}", classPath);
                    continue;
                }

                ClassReader classReader = new ClassReader(is);
                CallGraphClassVisitor visitor = new CallGraphClassVisitor(classPath, location.getJar().getName());
                classReader.accept(visitor, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
                callGraph.addAll(visitor.getCalls());

            } catch (Exception e) {
                log.warn("解析class文件失败: {}", classPath, e);
            }
        }

        log.info("调用图构建完成: 共 {} 条调用关系", callGraph.size());
        return callGraph;
    }

    /**
     * 获取调用图（已构建后调用）
     */
    public List<MethodCallModel> getCallGraph() {
        return callGraph;
    }

    /**
     * ASM ClassVisitor - 遍历类中的方法
     */
    private static class CallGraphClassVisitor extends ClassVisitor {
        private final String filePath;
        private final String sourceJar;
        private String className;
        private final List<MethodCallModel> calls = new ArrayList<>();

        /**
         * 单JAR构造函数
         */
        public CallGraphClassVisitor(String filePath) {
            super(Opcodes.ASM9);
            this.filePath = filePath;
            this.sourceJar = null;
        }

        /**
         * 多JAR构造函数（带来源JAR信息）
         */
        public CallGraphClassVisitor(String filePath, String sourceJar) {
            super(Opcodes.ASM9);
            this.filePath = filePath;
            this.sourceJar = sourceJar;
        }

        @Override
        public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
            // 将内部类路径格式转为标准格式: com/example/Foo$Inner -> com.example.Foo$Inner
            // 关键：保持完整类名（包含包名）
            this.className = name.replace('/', '.').replace('\\', '.');
            super.visit(version, access, name, signature, superName, interfaces);
        }

        @Override
        public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
            return new CallGraphMethodVisitor(className, name, descriptor, sourceJar, calls);
        }

        public List<MethodCallModel> getCalls() {
            return calls;
        }
    }

    /**
     * ASM MethodVisitor - 分析方法调用指令
     */
    private static class CallGraphMethodVisitor extends MethodVisitor {
        private final String callerClass;
        private final String callerMethod;
        private final String callerDescriptor;
        private final String callerJar;
        private final List<MethodCallModel> calls;
        private int currentLine = 0;

        public CallGraphMethodVisitor(String callerClass, String callerMethod, String callerDescriptor, String callerJar, List<MethodCallModel> calls) {
            super(Opcodes.ASM9);
            this.callerClass = callerClass;
            this.callerMethod = callerMethod;
            this.callerDescriptor = callerDescriptor;
            this.callerJar = callerJar;
            this.calls = calls;
        }

        @Override
        public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
            // 构建调用关系
            MethodCallModel call = new MethodCallModel();
            call.setCallerClass(callerClass);
            call.setCallerMethod(callerMethod);
            call.setCallerDescriptor(callerDescriptor);
            call.setCalleeClass(owner.replace('/', '.'));
            call.setCalleeMethod(name);
            call.setCalleeDescriptor(descriptor);
            call.setCallLine(currentLine > 0 ? currentLine : null);

            // 设置调用者所在JAR（多JAR模式）
            if (callerJar != null) {
                call.setCallerJar(callerJar);
            }

            // 根据操作码确定调用类型
            switch (opcode) {
                case Opcodes.INVOKEVIRTUAL:
                    call.setCallType("VIRTUAL");
                    break;
                case Opcodes.INVOKESTATIC:
                    call.setCallType("STATIC");
                    break;
                case Opcodes.INVOKESPECIAL:
                    call.setCallType("SPECIAL");
                    break;
                case Opcodes.INVOKEINTERFACE:
                    call.setCallType("INTERFACE");
                    break;
                default:
                    call.setCallType("UNKNOWN");
            }

            // 过滤掉一些不需要关注的调用
            if (!shouldSkip(owner, name)) {
                calls.add(call);
            }

            super.visitMethodInsn(opcode, owner, name, descriptor, isInterface);
        }

        @Override
        public void visitLineNumber(int line, org.objectweb.asm.Label start) {
            this.currentLine = line;
            super.visitLineNumber(line, start);
        }

        /**
         * 判断是否应该跳过该方法调用
         * 使用精细化的方法级别过滤，而非粗粒度的类级别过滤
         */
        private boolean shouldSkip(String owner, String name) {
            // 白名单：安全敏感方法需要追踪（即使属于java.lang类）
            Set<String> securitySensitiveMethods = Set.of(
                "clone",           // Object.clone() - 浅拷贝风险
                "intern",          // String.intern() - 内存耗尽风险
                "forName",         // Class.forName() - 动态类加载
                "newInstance",     // Class.newInstance() - 反射创建对象
                "loadClass",       // ClassLoader.loadClass() - 类加载
                "defineClass",     // ClassLoader.defineClass() - 动态定义类
                "exec",            // Runtime.exec() - 命令执行
                "getRuntime"       // Runtime.getRuntime() - 获取Runtime实例
            );

            // 如果是安全敏感方法，必须追踪（不跳过）
            if (securitySensitiveMethods.contains(name)) {
                return false;
            }

            // 黑名单：常见无关方法可跳过（减少噪音）
            Set<String> skipMethods = Set.of(
                "toString",        // Object.toString() - 仅调试用途
                "hashCode",        // Object.hashCode() - 数据结构用途
                "equals",          // Object.equals() - 比较用途
                "getClass",        // Object.getClass() - 类型查询
                "notify",          // Object.notify() - 线程同步
                "notifyAll",       // Object.notifyAll() - 线程同步
                "wait"             // Object.wait() - 线程同步
            );

            // 跳过无关方法（减少调用图噪音）
            if (skipMethods.contains(name)) {
                return true;
            }

            // 保留构造方法追踪（对污点分析重要）
            // 反序列化、对象创建等场景需要追踪 <init>
            return false;
        }
    }
}
