package org.example.securityplatform.service;

import lombok.extern.slf4j.Slf4j;
import org.benf.cfr.reader.api.CfrDriver;
import org.benf.cfr.reader.api.OutputSinkFactory;
import org.example.securityplatform.analyzer.diff.FileDiffModel;
import org.example.securityplatform.analyzer.jar.JarInfo;
import org.example.securityplatform.dto.FileSourceDiff;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Collectors;

/**
 * 源代码差异服务 - 使用CFR反编译器将.class文件转为Java源码
 */
@Slf4j
@Service
public class SourceDiffService {

    /**
     * 反编译变更的class文件（并行优化版本）
     */
    public List<FileSourceDiff> decompileChangedFiles(
            List<FileDiffModel> fileDiffs,
            String baselinePath,
            String targetPath,
            List<JarInfo> baselineJars,
            List<JarInfo> targetJars) {

        log.info("开始源码反编译，共 {} 个变更文件（并行处理）", fileDiffs.size());
        long startTime = System.currentTimeMillis();

        boolean isMultiJar = baselineJars != null && !baselineJars.isEmpty();

        // 使用线程安全的计数器
        AtomicInteger successCount = new AtomicInteger(0);
        AtomicInteger failCount = new AtomicInteger(0);

        // 并行处理所有文件差异
        List<FileSourceDiff> sourceDiffs = fileDiffs.parallelStream()
                .map(diff -> decompileFileDiff(diff, baselinePath, targetPath,
                                               baselineJars, targetJars, isMultiJar,
                                               successCount, failCount))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        long elapsed = System.currentTimeMillis() - startTime;
        log.info("源码反编译完成: 成功={}, 失败={}, 共={}, 耗时={}ms, 平均={}ms/文件",
                successCount.get(), failCount.get(), fileDiffs.size(), elapsed,
                fileDiffs.size() > 0 ? elapsed / fileDiffs.size() : 0);

        return sourceDiffs;
    }

    /**
     * 反编译单个文件差异（并行流调用的helper方法）
     */
    private FileSourceDiff decompileFileDiff(
            FileDiffModel diff,
            String baselinePath,
            String targetPath,
            List<JarInfo> baselineJars,
            List<JarInfo> targetJars,
            boolean isMultiJar,
            AtomicInteger successCount,
            AtomicInteger failCount) {

        try {
            String baselineSource = null;
            String targetSource = null;

            switch (diff.getDiffType()) {
                case "ADDED":
                    targetSource = decompileForSide(diff.getFilePath(), targetPath, targetJars, isMultiJar);
                    break;
                case "DELETED":
                    baselineSource = decompileForSide(diff.getFilePath(), baselinePath, baselineJars, isMultiJar);
                    break;
                case "MODIFIED":
                    baselineSource = decompileForSide(diff.getFilePath(), baselinePath, baselineJars, isMultiJar);
                    targetSource = decompileForSide(diff.getFilePath(), targetPath, targetJars, isMultiJar);
                    break;
                case "MOVED":
                    // 移动的文件，尝试从两边反编译
                    baselineSource = decompileForSide(diff.getFilePath(), baselinePath, baselineJars, isMultiJar);
                    targetSource = decompileForSide(diff.getFilePath(), targetPath, targetJars, isMultiJar);
                    break;
                default:
                    return null;
            }

            boolean hasResult = baselineSource != null || targetSource != null;
            String error = null;
            String actualDiffType = diff.getDiffType();
            String originalDiffType = diff.getDiffType();
            boolean bytecodeDiffButSourceSame = false;

            // Re-evaluate diffType based on decompiled source
            if ("MODIFIED".equals(diff.getDiffType()) && baselineSource != null && targetSource != null) {
                if (baselineSource.equals(targetSource)) {
                    actualDiffType = "UNCHANGED";
                    bytecodeDiffButSourceSame = true;
                    log.debug("字节码差异但反编译后源码相同: {}", diff.getFilePath());
                }
            }

            if (!hasResult && ("MODIFIED".equals(diff.getDiffType()) || "MOVED".equals(diff.getDiffType()))) {
                error = "反编译未返回任何源码";
            }

            // 正确计数：根据差异类型判断成功/失败
            boolean isSuccess = false;
            switch (diff.getDiffType()) {
                case "ADDED":
                    isSuccess = targetSource != null;
                    break;
                case "DELETED":
                    isSuccess = baselineSource != null;
                    break;
                case "MODIFIED":
                case "MOVED":
                    isSuccess = baselineSource != null || targetSource != null;
                    break;
                default:
                    isSuccess = hasResult;
            }

            if (isSuccess) {
                successCount.incrementAndGet();
            } else {
                failCount.incrementAndGet();
            }

            return FileSourceDiff.builder()
                    .filePath(diff.getFilePath())
                    .sourceFilePath(diff.getSourceFilePath())
                    .diffType(actualDiffType)
                    .originalDiffType(originalDiffType)
                    .bytecodeDiffButSourceSame(bytecodeDiffButSourceSame)
                    .baselineSource(baselineSource)
                    .targetSource(targetSource)
                    .error(error)
                    .sourceJar(diff.getSourceJar())
                    .jarType(diff.getJarType())
                    .build();

        } catch (Exception e) {
            log.warn("反编译处理失败: {} - {}", diff.getFilePath(), e.getMessage());
            failCount.incrementAndGet();
            return FileSourceDiff.builder()
                    .filePath(diff.getFilePath())
                    .sourceFilePath(diff.getSourceFilePath())
                    .diffType(diff.getDiffType())
                    .error("反编译失败: " + e.getMessage())
                    .sourceJar(diff.getSourceJar())
                    .jarType(diff.getJarType())
                    .build();
        }
    }

    /**
     * 反编译指定端的class文件
     */
    private String decompileForSide(String classPath, String mainJarPath,
                                     List<JarInfo> jarInfos, boolean isMultiJar) {
        if (isMultiJar) {
            return decompileFromJars(classPath, jarInfos);
        } else {
            return decompileClassFromJar(mainJarPath, classPath);
        }
    }

    /**
     * 从多个JAR中查找并反编译
     */
    private String decompileFromJars(String classPath, List<JarInfo> jarInfos) {
        for (JarInfo jarInfo : jarInfos) {
            String result = decompileClassFromJar(jarInfo.getJarPath(), classPath);
            if (result != null) {
                return result;
            }
        }
        log.warn("在所有JAR中均未找到: {}", classPath);
        return null;
    }

    /**
     * 从JAR中提取class字节并反编译
     * 先提取字节到临时文件，再用CFR反编译，避免JAR路径格式问题
     */
    private String decompileClassFromJar(String jarPath, String classPath) {
        // 1. 在JAR中找到正确的条目名
        String entryName = resolveEntryName(jarPath, classPath);
        if (entryName == null) {
            return null;
        }

        // 2. 从JAR中提取class字节到临时文件
        Path tempFile = null;
        try {
            byte[] classBytes = extractClassBytes(jarPath, entryName);
            if (classBytes == null) {
                log.warn("无法提取class字节: {} from {}", entryName, jarPath);
                return null;
            }

            tempFile = Files.createTempFile("cfr-", ".class");
            Files.write(tempFile, classBytes);

            // 3. 用CFR反编译临时文件
            String source = decompileFile(tempFile.toString());
            return source;

        } catch (Exception e) {
            log.warn("反编译失败: {} in {} - {}", classPath, jarPath, e.getMessage());
            return null;
        } finally {
            if (tempFile != null) {
                try {
                    Files.deleteIfExists(tempFile);
                } catch (Exception ignored) {}
            }
        }
    }

    /**
     * 从JAR中提取class文件的字节
     */
    private byte[] extractClassBytes(String jarPath, String entryName) {
        try (JarFile jar = new JarFile(jarPath)) {
            JarEntry entry = jar.getJarEntry(entryName);
            if (entry == null) {
                return null;
            }
            try (InputStream is = jar.getInputStream(entry)) {
                return is.readAllBytes();
            }
        } catch (IOException e) {
            log.warn("读取JAR条目失败: {} in {} - {}", entryName, jarPath, e.getMessage());
            return null;
        }
    }

    /**
     * 用CFR反编译一个class文件
     */
    private String decompileFile(String classFilePath) {
        StringBuilder output = new StringBuilder();

        OutputSinkFactory sinkFactory = new OutputSinkFactory() {
            @Override
            public List<SinkClass> getSupportedSinks(SinkType sinkType, Collection<SinkClass> available) {
                return Collections.singletonList(SinkClass.STRING);
            }

            @Override
            public <T> Sink<T> getSink(SinkType sinkType, SinkClass sinkClass) {
                if (sinkType == SinkType.JAVA) {
                    return t -> output.append(t);
                }
                return t -> {};
            }
        };

        Map<String, String> options = new HashMap<>();
        options.put("showversion", "false");
        options.put("removeboilerplate", "true");
        options.put("decodestringswitch", "true");
        options.put("sugarenums", "true");
        options.put("decodelambdas", "true");
        options.put("aexagg", "false");

        CfrDriver driver = new CfrDriver.Builder()
                .withOutputSink(sinkFactory)
                .withOptions(options)
                .build();

        driver.analyse(Collections.singletonList(classFilePath));

        String source = output.toString().trim();
        if (source.isEmpty()) {
            return null;
        }
        return source;
    }

    /**
     * 在JAR中解析class条目的实际路径
     * 支持原始路径和规范化路径（BOOT-INF/classes前缀）
     */
    private String resolveEntryName(String jarPath, String classPath) {
        try (JarFile jar = new JarFile(jarPath)) {
            // 1. 尝试原始路径
            if (jar.getEntry(classPath) != null) {
                return classPath;
            }

            // 2. 尝试添加 BOOT-INF/classes 前缀
            String bootPath = "BOOT-INF/classes/" + classPath;
            if (jar.getEntry(bootPath) != null) {
                return bootPath;
            }

            // 3. 尝试添加 WEB-INF/classes 前缀
            String webPath = "WEB-INF/classes/" + classPath;
            if (jar.getEntry(webPath) != null) {
                return webPath;
            }

            // 4. 如果原始路径已有 BOOT-INF/classes 前缀，尝试去掉
            if (classPath.startsWith("BOOT-INF/classes/")) {
                String stripped = classPath.substring("BOOT-INF/classes/".length());
                if (jar.getEntry(stripped) != null) {
                    return stripped;
                }
            }

            // 5. 如果原始路径已有 WEB-INF/classes 前缀，尝试去掉
            if (classPath.startsWith("WEB-INF/classes/")) {
                String stripped = classPath.substring("WEB-INF/classes/".length());
                if (jar.getEntry(stripped) != null) {
                    return stripped;
                }
            }

            // 6. 模糊搜索：限制范围避免匹配错误类
            String filename = classPath.contains("/")
                    ? classPath.substring(classPath.lastIndexOf('/') + 1)
                    : classPath;

            // 提取期望的包路径（用于限制搜索范围）
            String expectedPackage = classPath.contains("/")
                    ? classPath.substring(0, classPath.lastIndexOf('/'))
                    : "";

            Enumeration<JarEntry> entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String entryName = entry.getName();

                // 只匹配同名文件，且必须在相似包路径下
                if (entryName.endsWith(filename) && !entry.isDirectory()) {
                    // 提取条目的包路径
                    String entryPackage = entryName.contains("/")
                            ? entryName.substring(0, entryName.lastIndexOf('/'))
                            : "";

                    // 允许 BOOT-INF/classes 和 WEB-INF/classes 前缀差异
                    String normalizedEntryPackage = entryPackage
                            .replace("BOOT-INF/classes/", "")
                            .replace("WEB-INF/classes/", "");

                    // 包路径必须相同或相似（避免匹配到完全不同包的同名类）
                    if (expectedPackage.equals(normalizedEntryPackage) ||
                        expectedPackage.isEmpty() ||
                        normalizedEntryPackage.isEmpty()) {
                        log.debug("模糊搜索匹配: {} (expectedPackage={}, entryPackage={})",
                                entryName, expectedPackage, normalizedEntryPackage);
                        return entryName;
                    }
                }
            }

            log.debug("在JAR中未找到条目: {} (tried raw, BOOT-INF, WEB-INF, fuzzy)", classPath);
            return null;

        } catch (IOException e) {
            log.warn("解析JAR条目失败: {} in {} - {}", classPath, jarPath, e.getMessage());
            return null;
        }
    }
}
