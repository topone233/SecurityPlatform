package org.example.securityplatform.api;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.dto.TaintAnalysisResultResponse;
import org.example.securityplatform.dto.TaintSinkResponse;
import org.example.securityplatform.service.TaintAnalysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

/**
 * 污点分析API控制器
 */
@Slf4j
@RestController
@RequestMapping("/api/taint")
public class TaintAnalysisController {

    @Autowired
    private TaintAnalysisService taintAnalysisService;

    /**
     * 执行污点分析
     *
     * @param artifactId     制品ID
     * @param vulnerabilityType 漏洞类型（默认SQL_INJECTION）
     * @return 分析结果
     */
    @PostMapping("/analyze/{artifactId}")
    public ResponseEntity<TaintAnalysisResultResponse> analyze(
            @PathVariable Long artifactId,
            @RequestParam(defaultValue = "SQL_INJECTION") String vulnerabilityType) {
        try {
            log.info("收到污点分析请求: artifactId={}, vulnerabilityType={}", artifactId, vulnerabilityType);
            TaintAnalysisResultResponse result = taintAnalysisService.analyze(artifactId, vulnerabilityType);
            return ResponseEntity.ok(result);
        } catch (IOException e) {
            log.error("污点分析失败", e);
            return ResponseEntity.internalServerError().build();
        } catch (IllegalArgumentException e) {
            log.warn("参数错误: {}", e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 获取污点分析结果
     *
     * @param artifactId     制品ID
     * @param vulnerabilityType 漏洞类型（默认SQL_INJECTION）
     * @return 分析结果
     */
    @GetMapping("/result/{artifactId}")
    public ResponseEntity<TaintAnalysisResultResponse> getResult(
            @PathVariable Long artifactId,
            @RequestParam(defaultValue = "SQL_INJECTION") String vulnerabilityType) {
        TaintAnalysisResultResponse result = taintAnalysisService.getResult(artifactId, vulnerabilityType);
        return ResponseEntity.ok(result);
    }

    /**
     * 获取单个Sink的详情
     *
     * @param sinkId Sink ID
     * @return Sink详情（包含所有污点路径）
     */
    @GetMapping("/sink/{sinkId}")
    public ResponseEntity<TaintSinkResponse> getSinkDetail(@PathVariable Long sinkId) {
        try {
            TaintSinkResponse sink = taintAnalysisService.getSinkDetail(sinkId);
            return ResponseEntity.ok(sink);
        } catch (IllegalArgumentException e) {
            log.warn("Sink不存在: {}", sinkId);
            return ResponseEntity.notFound().build();
        }
    }
}