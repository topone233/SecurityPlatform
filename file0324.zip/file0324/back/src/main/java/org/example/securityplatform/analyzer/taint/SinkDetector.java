package org.example.securityplatform.analyzer.taint;

import org.example.securityplatform.entity.TaintSink;

import java.io.IOException;
import java.util.List;

/**
 * Sink检测器接口
 * 支持多种漏洞类型的扩展
 */
public interface SinkDetector {

    /**
     * 获取漏洞类型
     *
     * @return 漏洞类型标识，如 SQL_INJECTION, COMMAND_INJECTION, SSRF
     */
    String getVulnerabilityType();

    /**
     * 检测Sink点
     *
     * @param jarPath   JAR包路径
     * @param artifactId 制品ID
     * @return 检测到的Sink点列表
     * @throws IOException IO异常
     */
    List<TaintSink> detect(String jarPath, Long artifactId) throws IOException;

    /**
     * 获取Sink类型描述
     *
     * @return Sink类型
     */
    default String getSinkType() {
        return "UNKNOWN";
    }
}