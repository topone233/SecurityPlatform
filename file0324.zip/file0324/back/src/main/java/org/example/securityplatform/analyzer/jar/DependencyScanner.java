package org.example.securityplatform.analyzer.jar;

import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 依赖JAR扫描器 - 扫描Spring Boot Fat JAR和WAR文件中的依赖JAR
 */
@Slf4j
public class DependencyScanner {

    private final BusinessModuleFilter moduleFilter;

    public DependencyScanner() {
        this.moduleFilter = new BusinessModuleFilter();
    }

    /**
     * 扫描主JAR包中的依赖模块
     *
     * @param mainJarPath 主JAR路径
     * @param config 依赖分析配置
     * @return 包含主JAR和过滤后依赖JAR的列表
     */
    public List<JarInfo> scanDependencies(String mainJarPath, DependencyAnalysisConfig config) throws IOException {
        List<JarInfo> jars = new ArrayList<>();

        // 添加主JAR
        File mainJarFile = new File(mainJarPath);
        jars.add(new JarInfo(mainJarPath, JarInfo.JarType.MAIN, mainJarFile.getName()));

        log.info("Scanning dependencies for: {}", mainJarFile.getName());

        if (!config.isAnalyzeDependencies()) {
            log.info("Dependency analysis disabled, skipping lib scan");
            return jars;
        }

        // 创建临时目录存放提取的依赖JAR
        Path tempDir = Files.createTempDirectory("dep_scan_");

        try (JarFile jarFile = new JarFile(mainJarPath)) {
            // 扫描 BOOT-INF/lib（Spring Boot Fat JAR）
            List<JarInfo> bootInfDeps = scanLibEntries(
                    jarFile, "BOOT-INF/lib", tempDir, config);
            jars.addAll(bootInfDeps);
            log.info("Found {} dependencies in BOOT-INF/lib", bootInfDeps.size());

            // 扫描 WEB-INF/lib（WAR文件）
            List<JarInfo> webInfDeps = scanLibEntries(
                    jarFile, "WEB-INF/lib", tempDir, config);
            jars.addAll(webInfDeps);
            log.info("Found {} dependencies in WEB-INF/lib", webInfDeps.size());

        } catch (Exception e) {
            log.error("Failed to scan dependencies", e);
            // 即使扫描失败，也返回主JAR
        }

        log.info("Total JARs to analyze: {} (1 main + {} dependencies)",
                jars.size(), jars.size() - 1);

        return jars;
    }

    /**
     * 扫描指定lib目录下的JAR文件
     */
    private List<JarInfo> scanLibEntries(JarFile jarFile, String libPath,
                                         Path tempDir, DependencyAnalysisConfig config) throws IOException {
        List<JarInfo> deps = new ArrayList<>();
        Enumeration<JarEntry> entries = jarFile.entries();

        int scanned = 0;
        int filtered = 0;

        while (entries.hasMoreElements()) {
            JarEntry entry = entries.nextElement();
            String name = entry.getName();

            // 检查是否为lib目录下的JAR文件
            if (name.startsWith(libPath + "/") && name.endsWith(".jar") && !entry.isDirectory()) {
                scanned++;
                String jarName = extractJarName(name);

                // 第一步：快速名称过滤（不需要解压JAR）
                if (config.hasJarNamePatterns() &&
                        !moduleFilter.matchesByName(jarName, config.getIncludeJarNames())) {
                    log.debug("Filtered by name pattern: {}", jarName);
                    filtered++;
                    continue;
                }

                // 提取JAR到临时目录
                Path extractedPath = tempDir.resolve(jarName);
                try {
                    Files.copy(jarFile.getInputStream(entry), extractedPath);
                } catch (IOException e) {
                    log.warn("Failed to extract dependency JAR: {}", jarName, e);
                    continue;
                }

                // 第二步：包名过滤（需要检查JAR内容）
                if (config.hasPackagePatterns()) {
                    if (!moduleFilter.matchesByPackage(extractedPath, config.getIncludePackages())) {
                        log.debug("Filtered by package pattern: {}", jarName);
                        filtered++;
                        // 删除不匹配的临时文件
                        Files.deleteIfExists(extractedPath);
                        continue;
                    }
                }

                // 添加到依赖列表
                deps.add(new JarInfo(extractedPath.toString(), JarInfo.JarType.DEPENDENCY, jarName));
                log.info("  Found business module: {}", jarName);
            }
        }

        log.info("Scanned {} JARs in {}, {} passed filters, {} filtered out",
                scanned, libPath, deps.size(), filtered);

        return deps;
    }

    /**
     * 检测JAR是否为多模块父项目（不包含/仅包含少量业务类）
     *
     * @param mainJarPath 主JAR路径
     * @return true如果JAR看起来是父模块且无业务代码
     */
    public boolean isMultiModuleParent(String mainJarPath) throws IOException {
        try (JarFile jarFile = new JarFile(mainJarPath)) {
            int businessClassCount = 0;

            Enumeration<JarEntry> entries = jarFile.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();

                // 检查BOOT-INF/classes中的业务类
                if (name.startsWith("BOOT-INF/classes/") && name.endsWith(".class") && !entry.isDirectory()) {
                    // 排除框架类
                    if (!name.contains("/springframework/") &&
                        !name.contains("/org/apache/") &&
                        !name.contains("/com/fasterxml/")) {
                        businessClassCount++;
                    }
                }
            }

            log.info("JAR业务类数量: {}", businessClassCount);

            // 业务类少于5个，很可能是父模块
            return businessClassCount < 5;
        }
    }

    /**
     * 从路径中提取JAR文件名
     */
    private String extractJarName(String path) {
        int lastSlash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        return lastSlash >= 0 ? path.substring(lastSlash + 1) : path;
    }

    /**
     * 清理临时目录中的依赖JAR文件
     */
    public void cleanupDependencies(List<JarInfo> jars) {
        for (JarInfo jar : jars) {
            if (jar.getType() == JarInfo.JarType.DEPENDENCY) {
                try {
                    Files.deleteIfExists(Path.of(jar.getJarPath()));
                    log.debug("Cleaned up temporary dependency: {}", jar.getName());
                } catch (IOException e) {
                    log.warn("Failed to cleanup temporary file: {}", jar.getJarPath(), e);
                }
            }
        }

        // 尝试删除临时目录（如果为空）
        for (JarInfo jar : jars) {
            if (jar.getType() == JarInfo.JarType.DEPENDENCY) {
                try {
                    Path parentDir = Path.of(jar.getJarPath()).getParent();
                    if (parentDir != null && Files.exists(parentDir)) {
                        // 检查目录是否为空
                        if (Files.list(parentDir).findFirst().isEmpty()) {
                            Files.delete(parentDir);
                            log.debug("Cleaned up temporary directory: {}", parentDir);
                        }
                    }
                } catch (IOException e) {
                    // 忽略清理失败
                }
                break; // 只需尝试一次
            }
        }
    }
}
