package org.example.securityplatform.analyzer.mybatis;

import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * MyBatis Mapper解析器测试
 */
class MyBatisMapperParserTest {

    private final MyBatisMapperParser parser = new MyBatisMapperParser();

    @Test
    void testSimpleSqlFragment() throws Exception {
        // 场景1：简单SQL片段引用
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"http://mybatis.org/dtd/mybatis-3-mapper.dtd\">\n" +
                "<mapper namespace=\"com.example.TestMapper\">\n" +
                "    <sql id=\"orderBy\">order by ${field}</sql>\n" +
                "    <select id=\"find\">\n" +
                "        SELECT * FROM users <include refid=\"orderBy\"/>\n" +
                "    </select>\n" +
                "</mapper>";

        MyBatisMapperModel mapper = parseXml(xml);

        assertNotNull(mapper);
        assertEquals("com.example.TestMapper", mapper.getNamespace());
        assertEquals(1, mapper.getStatements().size());

        MyBatisMapperModel.SqlStatement stmt = mapper.getStatements().get(0);
        assertEquals("find", stmt.getId());
        assertTrue(stmt.getSql().contains("order by ${field}"));
        assertTrue(stmt.getDollarParams().contains("field"));
    }

    @Test
    void testNestedSqlFragment() throws Exception {
        // 场景2：嵌套引用
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"http://mybatis.org/dtd/mybatis-3-mapper.dtd\">\n" +
                "<mapper namespace=\"com.example.TestMapper\">\n" +
                "    <sql id=\"base\">WHERE id = ${id}</sql>\n" +
                "    <sql id=\"condition\">AND name = ${name} <include refid=\"extra\"/></sql>\n" +
                "    <sql id=\"extra\">AND age > ${age}</sql>\n" +
                "    <select id=\"find\">\n" +
                "        SELECT * FROM users <include refid=\"base\"/> <include refid=\"condition\"/>\n" +
                "    </select>\n" +
                "</mapper>";

        MyBatisMapperModel mapper = parseXml(xml);

        assertNotNull(mapper);
        assertEquals(1, mapper.getStatements().size());

        MyBatisMapperModel.SqlStatement stmt = mapper.getStatements().get(0);
        assertEquals("find", stmt.getId());
        assertTrue(stmt.getDollarParams().contains("id"));
        assertTrue(stmt.getDollarParams().contains("name"));
        assertTrue(stmt.getDollarParams().contains("age"));
        assertEquals(3, stmt.getDollarParams().size());
    }

    @Test
    void testCircularReference() throws Exception {
        // 场景3：循环引用
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"http://mybatis.org/dtd/mybatis-3-mapper.dtd\">\n" +
                "<mapper namespace=\"com.example.TestMapper\">\n" +
                "    <sql id=\"a\">SELECT <include refid=\"b\"/></sql>\n" +
                "    <sql id=\"b\">FROM <include refid=\"a\"/></sql>\n" +
                "    <select id=\"find\">\n" +
                "        <include refid=\"a\"/>\n" +
                "    </select>\n" +
                "</mapper>";

        // 循环引用应该被检测并跳过，不应该抛出异常
        MyBatisMapperModel mapper = parseXml(xml);
        assertNotNull(mapper);
        // 由于循环引用，可能无法完全解析，但不应崩溃
    }

    @Test
    void testNonExistentFragment() throws Exception {
        // 场景4：片段不存在
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"http://mybatis.org/dtd/mybatis-3-mapper.dtd\">\n" +
                "<mapper namespace=\"com.example.TestMapper\">\n" +
                "    <select id=\"find\">\n" +
                "        SELECT * FROM users <include refid=\"nonExist\"/>\n" +
                "    </select>\n" +
                "</mapper>";

        // 引用不存在的片段应该记录警告但不崩溃
        MyBatisMapperModel mapper = parseXml(xml);
        assertNotNull(mapper);
    }

    @Test
    void testRealWorldScenario() throws Exception {
        // 测试实际的UserMapper.xml场景
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"http://mybatis.org/dtd/mybatis-3-mapper.dtd\">\n" +
                "<mapper namespace=\"com.example.cxf.dao.mapper.UserMapper\">\n" +
                "    <resultMap id=\"UserResultMap\" type=\"com.example.cxf.dao.entity.User\">\n" +
                "        <id property=\"id\" column=\"id\"/>\n" +
                "        <result property=\"name\" column=\"name\"/>\n" +
                "        <result property=\"email\" column=\"email\"/>\n" +
                "    </resultMap>\n" +
                "    <select id=\"findById\" resultMap=\"UserResultMap\">\n" +
                "        SELECT * FROM users WHERE id = ${id} or name = ${name}\n" +
                "        <include refid=\"orderBy\"/>\n" +
                "    </select>\n" +
                "    <sql id=\"orderBy\">\n" +
                "        order by ${orderFiled} ${orderDirection}\n" +
                "    </sql>\n" +
                "</mapper>";

        MyBatisMapperModel mapper = parseXml(xml);

        assertNotNull(mapper);
        assertEquals("com.example.cxf.dao.mapper.UserMapper", mapper.getNamespace());
        assertEquals(1, mapper.getStatements().size());

        MyBatisMapperModel.SqlStatement stmt = mapper.getStatements().get(0);
        assertEquals("findById", stmt.getId());
        System.out.println("SQL: " + stmt.getSql());
        System.out.println("Params: " + stmt.getDollarParams());

        // 应该检测到4个注入点：id, name, orderFiled, orderDirection
        assertTrue(stmt.getDollarParams().contains("id"));
        assertTrue(stmt.getDollarParams().contains("name"));
        assertTrue(stmt.getDollarParams().contains("orderFiled"));
        assertTrue(stmt.getDollarParams().contains("orderDirection"));
        assertEquals(4, stmt.getDollarParams().size());
    }

    /**
     * 辅助方法：解析XML字符串
     */
    private MyBatisMapperModel parseXml(String xml) throws Exception {
        ByteArrayInputStream is = new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8));
        // 通过反射调用private的parseMapperXml方法进行测试
        java.lang.reflect.Method method = MyBatisMapperParser.class.getDeclaredMethod(
                "parseMapperXml", java.io.InputStream.class, String.class);
        method.setAccessible(true);
        return (MyBatisMapperModel) method.invoke(parser, is, "test.xml");
    }
}