package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.AnalysisCacheResponse;
import org.example.securityplatform.dto.AnalysisProgressResponse;
import org.example.securityplatform.entity.AnalysisCache;
import org.example.securityplatform.entity.AnalysisProgress;
import org.example.securityplatform.entity.Artifact;
import org.example.securityplatform.repository.ArtifactRepository;
import org.example.securityplatform.service.AnalysisCacheService;
import org.example.securityplatform.service.AnalysisProgressService;
import org.example.securityplatform.service.analysis.AnalysisEngineService;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * 分析进度管理 API 控制器
 */
@Tag(name = "分析进度管理", description = "分析进度查询和缓存管理")
@RestController
@RequestMapping("/api/analysis")
@RequiredArgsConstructor
public class AnalysisProgressController {

    private final AnalysisEngineService analysisEngineService;
    private final AnalysisProgressService progressService;
    private final AnalysisCacheService cacheService;
    private final ArtifactRepository artifactRepository;

    /**
     * 查询分析进度
     */
    @Operation(summary = "查询分析进度", description = "获取制品的实时分析进度信息")
    @GetMapping("/progress/{artifactId}")
    public Result<AnalysisProgressResponse> getAnalysisProgress(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        try {
            AnalysisProgress progress = analysisEngineService.getAnalysisProgress(artifactId);

            // 检查是否超时
            if (progressService.isTimeout(artifactId, 30)) {  // 30分钟超时
                AnalysisProgressResponse response = new AnalysisProgressResponse();
                response.setArtifactId(artifactId);
                response.setStatus("FAILED");
                response.setMessage("分析超时");
                response.setProgressPercentage(100);
                return Result.success(response);
            }

            AnalysisProgressResponse response = new AnalysisProgressResponse();
            BeanUtils.copyProperties(progress, response);
            return Result.success(response);
        } catch (RuntimeException e) {
            // 如果没有进度记录，检查制品状态
            return Result.success(getProgressFromArtifactStatus(artifactId));
        }
    }

    /**
     * 根据制品状态返回进度信息
     */
    private AnalysisProgressResponse getProgressFromArtifactStatus(Long artifactId) {
        AnalysisProgressResponse response = new AnalysisProgressResponse();
        response.setArtifactId(artifactId);

        Optional<Artifact> artifactOpt = artifactRepository.findById(artifactId);
        if (artifactOpt.isPresent()) {
            Artifact artifact = artifactOpt.get();
            String status = artifact.getStatus();

            if ("ANALYZED".equals(status)) {
                // 已分析完成，返回 COMPLETED 状态
                response.setStatus("COMPLETED");
                response.setProgressPercentage(100);
                response.setMessage("分析完成");
            } else if ("FAILED".equals(status)) {
                // 分析失败
                response.setStatus("FAILED");
                response.setProgressPercentage(100);
                response.setMessage("分析失败");
            } else if ("ANALYZING".equals(status)) {
                // 正在分析中
                response.setStatus("RUNNING");
                response.setProgressPercentage(50);
                response.setMessage("正在分析中");
            } else {
                // 其他状态返回 PENDING
                response.setStatus("PENDING");
                response.setProgressPercentage(0);
                response.setMessage("等待分析");
            }
        } else {
            // 制品不存在
            response.setStatus("PENDING");
            response.setProgressPercentage(0);
        }
        return response;
    }

    /**
     * 查询缓存状态
     */
    @Operation(summary = "查询缓存状态", description = "查询制品的分析缓存状态")
    @GetMapping("/cache/{artifactId}")
    public Map<String, Object> getCacheStatus(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        Map<String, Object> result = new HashMap<>();
        result.put("artifactId", artifactId);

        try {
            // 获取制品 MD5
            var artifactOpt = analysisEngineService.getClass(); // 需要通过其他方式获取 MD5
            // 这里简化处理，直接返回缓存相关信息

            result.put("hasCache", false);
            result.put("message", "请通过 MD5 查询缓存");
            return result;
        } catch (Exception e) {
            result.put("hasCache", false);
            result.put("error", e.getMessage());
            return result;
        }
    }

    /**
     * 清除分析缓存
     */
    @Operation(summary = "清除分析缓存", description = "根据MD5清除指定的分析缓存")
    @DeleteMapping("/cache/{md5}")
    public void clearCache(
            @Parameter(description = "制品MD5值") @PathVariable String md5) {
        cacheService.deleteCache(md5);
    }

    /**
     * 手动触发缓存清理
     */
    @Operation(summary = "手动清理过期缓存", description = "手动触发清理过期的分析缓存")
    @PostMapping("/cache/cleanup")
    public Map<String, Integer> cleanupCache() {
        Map<String, Integer> result = new HashMap<>();
        // 这里可以添加手动清理逻辑
        result.put("deleted", 0);
        return result;
    }
}