import api from './index'

export default {
  // Get artifact list by task ID
  getListByTask(taskId) {
    return api.get(`/artifacts/task/${taskId}`)
  },

  // Get artifact by ID
  getById(id) {
    return api.get(`/artifacts/${id}`)
  },

  // Upload artifact (multipart form)
  upload(taskId, file, artifactType = 'JAR', onUploadProgress) {
    const formData = new FormData()
    formData.append('file', file)

    // 构建 URL 参数
    const params = new URLSearchParams()
    if (taskId !== null && taskId !== undefined) {
      params.append('taskId', taskId)
    }
    params.append('artifactType', artifactType)

    return api.post(`/artifacts/upload?${params.toString()}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress
    })
  },

  // Delete artifact
  delete(id) {
    return api.delete(`/artifacts/${id}`)
  },

  // Trigger analysis (async)
  triggerAnalysis(id) {
    return api.post(`/analysis/trigger/${id}`)
  },

  // Trigger analysis (sync)
  triggerAnalysisSync(id) {
    return api.post(`/analysis/trigger-sync/${id}`)
  },

  // Get analysis result
  getAnalysisResult(id) {
    return api.get(`/analysis/result/${id}`)
  },

  // Get analysis progress
  getAnalysisProgress(id) {
    return api.get(`/analysis/progress/${id}`)
  }
}
