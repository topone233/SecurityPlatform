import request from './index'

/**
 * 差异分析相关API
 */
export default {
  /**
   * 获取基线推荐
   */
  getBaselineRecommendation(projectId) {
    return request.get(`/diff-analysis/baseline/${projectId}`)
  },

  /**
   * 创建差异分析任务
   */
  createDiffAnalysis(data) {
    return request.post('/diff-analysis/create', data)
  },

  /**
   * 获取差异分析进度
   */
  getProgress(taskId) {
    return request.get(`/diff-analysis/${taskId}/progress`)
  },

  /**
   * 获取差异分析结果
   */
  getDiffResult(taskId) {
    return request.get(`/diff-analysis/${taskId}`)
  },

  /**
   * 按变更类型筛选API
   */
  getApisByChangeType(taskId, changeType) {
    return request.get(`/diff-analysis/${taskId}/apis`, { params: { changeType } })
  },

  /**
   * 按风险等级筛选API
   */
  getApisByRiskLevel(taskId, riskLevel) {
    return request.get(`/diff-analysis/${taskId}/risks`, { params: { riskLevel } })
  },

  /**
   * 导出差异分析报告
   */
  exportReport(taskId) {
    return request.get(`/diff-analysis/${taskId}/export`, { responseType: 'blob' })
  }
}
