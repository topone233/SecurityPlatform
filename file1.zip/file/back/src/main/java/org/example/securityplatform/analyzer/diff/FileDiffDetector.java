package org.example.securityplatform.analyzer.diff;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.util.HashUtil;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 文件差异检测器 - 对比两个JAR包的文件差异
 */
@Slf4j
public class FileDiffDetector {

    private final String baselineJarPath;
    private final String targetJarPath;
    private final BytecodeDiffAnalyzer bytecodeDiffAnalyzer = new BytecodeDiffAnalyzer();

    public FileDiffDetector(String baselineJarPath, String targetJarPath) {
        this.baselineJarPath = baselineJarPath;
        this.targetJarPath = targetJarPath;
    }

    /**
     * 检测文件差异
     *
     * @return 文件差异列表
     */
    public List<FileDiffModel> detect() throws IOException {
        log.info("开始文件差异检测: baseline={}, target={}", baselineJarPath, targetJarPath);

        List<FileDiffModel> diffs = new ArrayList<>();

        // 获取两个JAR包的class文件列表
        Map<String, JarEntry> baselineEntries = getClassEntries(baselineJarPath);
        Map<String, JarEntry> targetEntries = getClassEntries(targetJarPath);

        Set<String> allPaths = new HashSet<>();
        allPaths.addAll(baselineEntries.keySet());
        allPaths.addAll(targetEntries.keySet());

        // 对比每个文件
        for (String path : allPaths) {
            FileDiffModel diff = analyzeFileDiff(path, baselineEntries, targetEntries);
            if (diff != null && diff.hasChanges()) {
                diffs.add(diff);
            }
        }

        log.info("文件差异检测完成: 共 {} 个文件变更", diffs.size());
        return diffs;
    }

    /**
     * 获取JAR包中的所有class文件
     */
    private Map<String, JarEntry> getClassEntries(String jarPath) throws IOException {
        Map<String, JarEntry> entries = new HashMap<>();
        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> enumeration = jarFile.entries();
            while (enumeration.hasMoreElements()) {
                JarEntry entry = enumeration.nextElement();
                if (entry.getName().endsWith(".class") && !entry.isDirectory()) {
                    entries.put(entry.getName(), entry);
                }
            }
        }
        return entries;
    }

    /**
     * 分析单个文件的差异
     */
    private FileDiffModel analyzeFileDiff(String path,
                                           Map<String, JarEntry> baselineEntries,
                                           Map<String, JarEntry> targetEntries) throws IOException {
        FileDiffModel diff = new FileDiffModel();
        diff.setFilePath(path);
        diff.setSourceFilePath(FileDiffModel.inferSourcePath(path));

        boolean inBaseline = baselineEntries.containsKey(path);
        boolean inTarget = targetEntries.containsKey(path);

        if (!inBaseline && inTarget) {
            // 新增文件
            diff.setDiffType("ADDED");
            diff.setBaselineLines(0);
            diff.setBaselineMd5(null);

            try (JarFile targetJar = new JarFile(targetJarPath)) {
                JarEntry entry = targetEntries.get(path);
                try (InputStream is = targetJar.getInputStream(entry)) {
                    diff.setTargetMd5(HashUtil.calculateMd5(is));
                    BytecodeDiffResult bytecodeDiff = analyzeBytecode(null, is, path);
                    diff.setBytecodeDiff(bytecodeDiff);
                    diff.setTargetLines(bytecodeDiff.getTargetInstructions());
                    diff.setMethodsAdded(bytecodeDiff.getMethodsAdded());
                }
            }
            return diff;

        } else if (inBaseline && !inTarget) {
            // 删除文件
            diff.setDiffType("DELETED");
            diff.setTargetLines(0);
            diff.setTargetMd5(null);

            try (JarFile baselineJar = new JarFile(baselineJarPath)) {
                JarEntry entry = baselineEntries.get(path);
                try (InputStream is = baselineJar.getInputStream(entry)) {
                    diff.setBaselineMd5(HashUtil.calculateMd5(is));
                    BytecodeDiffResult bytecodeDiff = analyzeBytecode(is, null, path);
                    diff.setBytecodeDiff(bytecodeDiff);
                    diff.setBaselineLines(bytecodeDiff.getBaselineInstructions());
                    diff.setMethodsDeleted(bytecodeDiff.getMethodsDeleted());
                }
            }
            return diff;

        } else if (inBaseline && inTarget) {
            // 两边都有，检查是否修改
            try (JarFile baselineJar = new JarFile(baselineJarPath);
                 JarFile targetJar = new JarFile(targetJarPath)) {

                JarEntry baselineEntry = baselineEntries.get(path);
                JarEntry targetEntry = targetEntries.get(path);

                try (InputStream baselineIs = baselineJar.getInputStream(baselineEntry);
                     InputStream targetIs = targetJar.getInputStream(targetEntry)) {

                    String baselineMd5 = HashUtil.calculateMd5(baselineIs);
                    String targetMd5 = HashUtil.calculateMd5(targetIs);

                    diff.setBaselineMd5(baselineMd5);
                    diff.setTargetMd5(targetMd5);

                    if (baselineMd5.equals(targetMd5)) {
                        // 未修改
                        diff.setDiffType("UNCHANGED");
                        return null;
                    }

                    // 修改的文件
                    diff.setDiffType("MODIFIED");

                    // 重新打开流进行字节码分析
                    try (InputStream baselineIs2 = baselineJar.getInputStream(baselineEntry);
                         InputStream targetIs2 = targetJar.getInputStream(targetEntry)) {

                        BytecodeDiffResult bytecodeDiff = analyzeBytecode(baselineIs2, targetIs2, path);
                        diff.setBytecodeDiff(bytecodeDiff);
                        diff.setBaselineLines(bytecodeDiff.getBaselineInstructions());
                        diff.setTargetLines(bytecodeDiff.getTargetInstructions());
                        diff.setMethodsAdded(bytecodeDiff.getMethodsAdded());
                        diff.setMethodsDeleted(bytecodeDiff.getMethodsDeleted());
                        diff.setMethodsModified(bytecodeDiff.getMethodsModified());
                    }
                }
            }
            return diff;
        }

        return null;
    }

    /**
     * 分析字节码差异
     */
    private BytecodeDiffResult analyzeBytecode(InputStream baselineStream,
                                                 InputStream targetStream,
                                                 String filePath) throws IOException {
        return bytecodeDiffAnalyzer.analyze(baselineStream, targetStream, filePath);
    }

    /**
     * 获取差异统计
     */
    public DiffStatistics getStatistics(List<FileDiffModel> diffs) {
        DiffStatistics stats = new DiffStatistics();
        for (FileDiffModel diff : diffs) {
            switch (diff.getDiffType()) {
                case "ADDED":
                    stats.addedFiles++;
                    break;
                case "DELETED":
                    stats.deletedFiles++;
                    break;
                case "MODIFIED":
                    stats.modifiedFiles++;
                    break;
            }
            stats.totalMethodsAdded += diff.getMethodsAdded();
            stats.totalMethodsDeleted += diff.getMethodsDeleted();
            stats.totalMethodsModified += diff.getMethodsModified();
        }
        return stats;
    }

    /**
     * 差异统计
     */
    @lombok.Data
    public static class DiffStatistics {
        private int addedFiles = 0;
        private int modifiedFiles = 0;
        private int deletedFiles = 0;
        private int totalMethodsAdded = 0;
        private int totalMethodsDeleted = 0;
        private int totalMethodsModified = 0;
    }
}