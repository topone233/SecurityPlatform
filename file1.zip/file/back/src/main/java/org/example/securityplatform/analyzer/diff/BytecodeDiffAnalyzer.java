package org.example.securityplatform.analyzer.diff;

import lombok.extern.slf4j.Slf4j;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * 字节码差异分析器 - 对比两个class文件的字节码差异
 */
@Slf4j
public class BytecodeDiffAnalyzer {

    /**
     * 分析两个字节码文件的差异
     *
     * @param baselineStream 基线版本的字节码输入流
     * @param targetStream   目标版本的字节码输入流
     * @param filePath       文件路径（用于日志）
     * @return 字节码差异结果
     */
    public BytecodeDiffResult analyze(InputStream baselineStream, InputStream targetStream, String filePath) {
        BytecodeDiffResult result = new BytecodeDiffResult();
        result.setFilePath(filePath);

        try {
            // 提取基线版本的方法信息
            Map<String, MethodInfo> baselineMethods = extractMethods(baselineStream);

            // 提取目标版本的方法信息
            Map<String, MethodInfo> targetMethods = extractMethods(targetStream);

            // 对比方法差异
            List<MethodChangeModel> methodChanges = new ArrayList<>();
            int methodsAdded = 0;
            int methodsDeleted = 0;
            int methodsModified = 0;

            // 查找新增和修改的方法
            for (Map.Entry<String, MethodInfo> entry : targetMethods.entrySet()) {
                String methodKey = entry.getKey();
                MethodInfo targetMethod = entry.getValue();

                if (!baselineMethods.containsKey(methodKey)) {
                    // 新增方法
                    MethodChangeModel change = new MethodChangeModel();
                    change.setMethodName(targetMethod.methodName);
                    change.setDescriptor(targetMethod.descriptor);
                    change.setAccess(targetMethod.access);
                    change.setChangeType("ADDED");
                    change.setTargetInstructions(targetMethod.instructionCount);
                    methodChanges.add(change);
                    methodsAdded++;
                } else {
                    // 检查是否修改
                    MethodInfo baselineMethod = baselineMethods.get(methodKey);
                    if (baselineMethod.instructionCount != targetMethod.instructionCount ||
                        !Objects.equals(baselineMethod.codeHash, targetMethod.codeHash)) {
                        // 方法修改
                        MethodChangeModel change = new MethodChangeModel();
                        change.setMethodName(targetMethod.methodName);
                        change.setDescriptor(targetMethod.descriptor);
                        change.setAccess(targetMethod.access);
                        change.setChangeType("MODIFIED");
                        change.setBaselineInstructions(baselineMethod.instructionCount);
                        change.setTargetInstructions(targetMethod.instructionCount);
                        methodChanges.add(change);
                        methodsModified++;
                    }
                }
            }

            // 查找删除的方法
            for (Map.Entry<String, MethodInfo> entry : baselineMethods.entrySet()) {
                String methodKey = entry.getKey();
                if (!targetMethods.containsKey(methodKey)) {
                    MethodInfo baselineMethod = entry.getValue();
                    MethodChangeModel change = new MethodChangeModel();
                    change.setMethodName(baselineMethod.methodName);
                    change.setDescriptor(baselineMethod.descriptor);
                    change.setAccess(baselineMethod.access);
                    change.setChangeType("DELETED");
                    change.setBaselineInstructions(baselineMethod.instructionCount);
                    methodChanges.add(change);
                    methodsDeleted++;
                }
            }

            result.setMethodChanges(methodChanges);
            result.setMethodsAdded(methodsAdded);
            result.setMethodsDeleted(methodsDeleted);
            result.setMethodsModified(methodsModified);
            result.setHasDiff(methodsAdded > 0 || methodsDeleted > 0 || methodsModified > 0);

        } catch (IOException e) {
            log.warn("字节码差异分析失败: {}", filePath, e);
            result.setHasDiff(false);
        }

        return result;
    }

    /**
     * 提取class文件中的方法信息
     */
    private Map<String, MethodInfo> extractMethods(InputStream inputStream) throws IOException {
        Map<String, MethodInfo> methods = new HashMap<>();

        ClassReader classReader = new ClassReader(inputStream);
        ClassVisitor visitor = new ClassVisitor(Opcodes.ASM9) {
            @Override
            public MethodVisitor visitMethod(int access, String name, String descriptor,
                                              String signature, String[] exceptions) {
                MethodInfo info = new MethodInfo();
                info.methodName = name;
                info.descriptor = descriptor;
                info.access = access;

                return new MethodVisitor(Opcodes.ASM9) {
                    private int instructionCount = 0;
                    private final StringBuilder codeBuilder = new StringBuilder();

                    @Override
                    public void visitInsn(int opcode) {
                        instructionCount++;
                        codeBuilder.append(opcode).append(",");
                    }

                    @Override
                    public void visitIntInsn(int opcode, int operand) {
                        instructionCount++;
                        codeBuilder.append(opcode).append(":").append(operand).append(",");
                    }

                    @Override
                    public void visitVarInsn(int opcode, int var) {
                        instructionCount++;
                        codeBuilder.append(opcode).append(":").append(var).append(",");
                    }

                    @Override
                    public void visitMethodInsn(int opcode, String owner, String name,
                                                String descriptor, boolean isInterface) {
                        instructionCount++;
                        codeBuilder.append(opcode).append(":")
                                   .append(owner).append(".").append(name).append(",");
                    }

                    @Override
                    public void visitEnd() {
                        info.instructionCount = instructionCount;
                        info.codeHash = String.valueOf(codeBuilder.toString().hashCode());
                        String key = name + descriptor;
                        methods.put(key, info);
                    }
                };
            }
        };

        classReader.accept(visitor, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
        return methods;
    }

    /**
     * 方法信息内部类
     */
    private static class MethodInfo {
        String methodName;
        String descriptor;
        int access;
        int instructionCount;
        String codeHash;
    }
}