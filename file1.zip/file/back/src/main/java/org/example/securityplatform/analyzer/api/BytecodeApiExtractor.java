package org.example.securityplatform.analyzer.api;

import lombok.extern.slf4j.Slf4j;
import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * 基于ASM的字节码API提取器
 * 用于从编译后的.class文件中提取Spring MVC和JAX-RS的API信息
 */
@Slf4j
public class BytecodeApiExtractor {

    private static final String SPRING_REQUEST_MAPPING = "Lorg/springframework/web/bind/annotation/RequestMapping;";
    private static final String SPRING_GET_MAPPING = "Lorg/springframework/web/bind/annotation/GetMapping;";
    private static final String SPRING_POST_MAPPING = "Lorg/springframework/web/bind/annotation/PostMapping;";
    private static final String SPRING_PUT_MAPPING = "Lorg/springframework/web/bind/annotation/PutMapping;";
    private static final String SPRING_DELETE_MAPPING = "Lorg/springframework/web/bind/annotation/DeleteMapping;";
    private static final String SPRING_PATCH_MAPPING = "Lorg/springframework/web/bind/annotation/PatchMapping;";

    private static final String JAX_RS_PATH = "Ljavax/ws/rs/Path;";
    private static final String JAX_RS_GET = "Ljavax/ws/rs/GET;";
    private static final String JAX_RS_POST = "Ljavax/ws/rs/POST;";
    private static final String JAX_RS_PUT = "Ljavax/ws/rs/PUT;";
    private static final String JAX_RS_DELETE = "Ljavax/ws/rs/DELETE;";

    /**
     * 从.class文件中提取API信息
     */
    public List<ApiModel> extractFromClassFile(String classFilePath) {
        List<ApiModel> apis = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(classFilePath)) {
            ClassReader reader = new ClassReader(fis);
            ApiClassVisitor visitor = new ApiClassVisitor(apis);
            reader.accept(visitor, 0);
        } catch (IOException e) {
            log.error("解析class文件失败: {}", classFilePath, e);
        }

        return apis;
    }

    /**
     * ASM ClassVisitor - 访问类信息
     */
    private static class ApiClassVisitor extends ClassVisitor {
        private final List<ApiModel> apis;
        private String className;
        private String classLevelPath = "";

        public ApiClassVisitor(List<ApiModel> apis) {
            super(Opcodes.ASM9);
            this.apis = apis;
        }

        @Override
        public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
            // 将内部类名转换为标准类名 (org/example/Test -> org.example.Test)
            this.className = name.replace('/', '.');
            super.visit(version, access, name, signature, superName, interfaces);
        }

        @Override
        public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
            // 检查类级别的@RequestMapping或@Path注解
            if (SPRING_REQUEST_MAPPING.equals(descriptor)) {
                return new SpringRequestMappingVisitor(value -> classLevelPath = value, null);
            } else if (JAX_RS_PATH.equals(descriptor)) {
                return new JaxRsPathVisitor(value -> classLevelPath = value);
            }
            return super.visitAnnotation(descriptor, visible);
        }

        @Override
        public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
            return new ApiMethodVisitor(apis, className, classLevelPath, name, descriptor);
        }
    }

    /**
     * ASM MethodVisitor - 访问方法信息并提取API
     */
    private static class ApiMethodVisitor extends MethodVisitor {
        private final List<ApiModel> apis;
        private final String className;
        private final String classLevelPath;
        private final String methodName;
        private final String methodDescriptor;

        // 临时存储方法上的注解信息
        private String currentHttpMethod;
        private String currentPath;
        private String framework;

        public ApiMethodVisitor(List<ApiModel> apis, String className, String classLevelPath,
                               String methodName, String methodDescriptor) {
            super(Opcodes.ASM9);
            this.apis = apis;
            this.className = className;
            this.classLevelPath = classLevelPath;
            this.methodName = methodName;
            this.methodDescriptor = methodDescriptor;
        }

        @Override
        public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
            // Spring MVC 注解
            if (SPRING_GET_MAPPING.equals(descriptor)) {
                currentHttpMethod = "GET";
                framework = "SPRING_MVC";
                return new SpringRequestMappingVisitor(value -> currentPath = value, null);
            } else if (SPRING_POST_MAPPING.equals(descriptor)) {
                currentHttpMethod = "POST";
                framework = "SPRING_MVC";
                return new SpringRequestMappingVisitor(value -> currentPath = value, null);
            } else if (SPRING_PUT_MAPPING.equals(descriptor)) {
                currentHttpMethod = "PUT";
                framework = "SPRING_MVC";
                return new SpringRequestMappingVisitor(value -> currentPath = value, null);
            } else if (SPRING_DELETE_MAPPING.equals(descriptor)) {
                currentHttpMethod = "DELETE";
                framework = "SPRING_MVC";
                return new SpringRequestMappingVisitor(value -> currentPath = value, null);
            } else if (SPRING_PATCH_MAPPING.equals(descriptor)) {
                currentHttpMethod = "PATCH";
                framework = "SPRING_MVC";
                return new SpringRequestMappingVisitor(value -> currentPath = value, null);
            } else if (SPRING_REQUEST_MAPPING.equals(descriptor)) {
                framework = "SPRING_MVC";
                return new SpringRequestMappingVisitor(path -> currentPath = path, method -> currentHttpMethod = method);
            }
            // JAX-RS 注解
            else if (JAX_RS_GET.equals(descriptor)) {
                currentHttpMethod = "GET";
                framework = "JAX_RS";
            } else if (JAX_RS_POST.equals(descriptor)) {
                currentHttpMethod = "POST";
                framework = "JAX_RS";
            } else if (JAX_RS_PUT.equals(descriptor)) {
                currentHttpMethod = "PUT";
                framework = "JAX_RS";
            } else if (JAX_RS_DELETE.equals(descriptor)) {
                currentHttpMethod = "DELETE";
                framework = "JAX_RS";
            } else if (JAX_RS_PATH.equals(descriptor)) {
                return new JaxRsPathVisitor(value -> currentPath = value);
            }

            return super.visitAnnotation(descriptor, visible);
        }

        @Override
        public void visitEnd() {
            // 如果找到了HTTP方法和路径，创建API模型
            if (currentHttpMethod != null && (currentPath != null || !classLevelPath.isEmpty())) {
                String fullPath = classLevelPath;
                if (currentPath != null) {
                    fullPath = classLevelPath + currentPath;
                }
                fullPath = fullPath.replace("//", "/");

                ApiModel api = new ApiModel();
                api.setUrl(fullPath);
                api.setHttpMethod(currentHttpMethod);
                api.setControllerClass(className);
                api.setMethodName(methodName);
                api.setFramework(framework);
                api.setParameters(extractParameters(methodDescriptor));

                apis.add(api);
            }
            super.visitEnd();
        }

        /**
         * 从方法描述符中提取参数信息
         */
        private String extractParameters(String descriptor) {
            if (descriptor == null || descriptor.isEmpty()) {
                return "";
            }

            try {
                Type[] argumentTypes = Type.getArgumentTypes(descriptor);
                StringBuilder params = new StringBuilder();
                for (Type type : argumentTypes) {
                    if (params.length() > 0) {
                        params.append(", ");
                    }
                    params.append(type.getClassName());
                }
                return params.toString();
            } catch (Exception e) {
                return "";
            }
        }
    }

    /**
     * Spring @RequestMapping 注解访问器
     */
    private static class SpringRequestMappingVisitor extends AnnotationVisitor {
        private final Consumer<String> pathCallback;
        private final Consumer<String> methodCallback;

        public SpringRequestMappingVisitor(Consumer<String> pathCallback, Consumer<String> methodCallback) {
            super(Opcodes.ASM9);
            this.pathCallback = pathCallback;
            this.methodCallback = methodCallback;
        }

        @Override
        public void visit(String name, Object value) {
            if ("value".equals(name) || "path".equals(name)) {
                if (pathCallback != null) {
                    pathCallback.accept(value.toString());
                }
            } else if ("method".equals(name) && methodCallback != null) {
                // RequestMethod通常是一个数组，这里简化处理
                String methodStr = value.toString();
                if (methodStr.contains("GET")) methodCallback.accept("GET");
                else if (methodStr.contains("POST")) methodCallback.accept("POST");
                else if (methodStr.contains("PUT")) methodCallback.accept("PUT");
                else if (methodStr.contains("DELETE")) methodCallback.accept("DELETE");
                else if (methodStr.contains("PATCH")) methodCallback.accept("PATCH");
            }
            super.visit(name, value);
        }

        @Override
        public AnnotationVisitor visitArray(String name) {
            if (("value".equals(name) || "path".equals(name)) && pathCallback != null) {
                return new AnnotationArrayVisitor(pathCallback);
            } else if ("method".equals(name) && methodCallback != null) {
                return new AnnotationArrayVisitor(item -> {
                    if (item.contains("GET")) methodCallback.accept("GET");
                    else if (item.contains("POST")) methodCallback.accept("POST");
                    else if (item.contains("PUT")) methodCallback.accept("PUT");
                    else if (item.contains("DELETE")) methodCallback.accept("DELETE");
                    else if (item.contains("PATCH")) methodCallback.accept("PATCH");
                });
            }
            return super.visitArray(name);
        }
    }

    /**
     * JAX-RS @Path 注解访问器
     */
    private static class JaxRsPathVisitor extends AnnotationVisitor {
        private final Consumer<String> callback;

        public JaxRsPathVisitor(Consumer<String> callback) {
            super(Opcodes.ASM9);
            this.callback = callback;
        }

        @Override
        public void visit(String name, Object value) {
            if ("value".equals(name) && callback != null) {
                callback.accept(value.toString());
            }
            super.visit(name, value);
        }
    }

    /**
     * 注解数组访问器
     */
    private static class AnnotationArrayVisitor extends AnnotationVisitor {
        private final Consumer<String> callback;

        public AnnotationArrayVisitor(Consumer<String> callback) {
            super(Opcodes.ASM9);
            this.callback = callback;
        }

        @Override
        public void visit(String name, Object value) {
            if (callback != null) {
                callback.accept(value.toString());
            }
            super.visit(name, value);
        }
    }
}
