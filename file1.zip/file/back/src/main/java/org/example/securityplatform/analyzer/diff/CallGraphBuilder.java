package org.example.securityplatform.analyzer.diff;

import lombok.extern.slf4j.Slf4j;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 调用图构建器 - 使用ASM分析字节码，构建方法调用关系
 */
@Slf4j
public class CallGraphBuilder {

    private final String jarPath;
    private final List<MethodCallModel> callGraph = new ArrayList<>();

    public CallGraphBuilder(String jarPath) {
        this.jarPath = jarPath;
    }

    /**
     * 构建调用图
     */
    public List<MethodCallModel> build() throws IOException {
        log.info("开始构建调用图: {}", jarPath);

        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> entries = jarFile.entries();

            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (entry.getName().endsWith(".class") && !entry.isDirectory()) {
                    try (InputStream is = jarFile.getInputStream(entry)) {
                        ClassReader classReader = new ClassReader(is);
                        CallGraphClassVisitor visitor = new CallGraphClassVisitor(entry.getName());
                        classReader.accept(visitor, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
                        callGraph.addAll(visitor.getCalls());
                    } catch (IOException e) {
                        log.warn("解析class文件失败: {}", entry.getName(), e);
                    }
                }
            }
        }

        log.info("调用图构建完成: 共 {} 条调用关系", callGraph.size());
        return callGraph;
    }

    /**
     * 获取调用图（已构建后调用）
     */
    public List<MethodCallModel> getCallGraph() {
        return callGraph;
    }

    /**
     * ASM ClassVisitor - 遍历类中的方法
     */
    private static class CallGraphClassVisitor extends ClassVisitor {
        private final String filePath;
        private String className;
        private final List<MethodCallModel> calls = new ArrayList<>();

        public CallGraphClassVisitor(String filePath) {
            super(Opcodes.ASM9);
            this.filePath = filePath;
        }

        @Override
        public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
            // 将内部类路径格式转为标准格式: com/example/Foo$Inner -> com.example.Foo$Inner
            this.className = name.replace('/', '.');
            super.visit(version, access, name, signature, superName, interfaces);
        }

        @Override
        public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
            return new CallGraphMethodVisitor(className, name, descriptor, calls);
        }

        public List<MethodCallModel> getCalls() {
            return calls;
        }
    }

    /**
     * ASM MethodVisitor - 分析方法调用指令
     */
    private static class CallGraphMethodVisitor extends MethodVisitor {
        private final String callerClass;
        private final String callerMethod;
        private final String callerDescriptor;
        private final List<MethodCallModel> calls;
        private int currentLine = 0;

        public CallGraphMethodVisitor(String callerClass, String callerMethod, String callerDescriptor, List<MethodCallModel> calls) {
            super(Opcodes.ASM9);
            this.callerClass = callerClass;
            this.callerMethod = callerMethod;
            this.callerDescriptor = callerDescriptor;
            this.calls = calls;
        }

        @Override
        public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
            // 构建调用关系
            MethodCallModel call = new MethodCallModel();
            call.setCallerClass(callerClass);
            call.setCallerMethod(callerMethod);
            call.setCallerDescriptor(callerDescriptor);
            call.setCalleeClass(owner.replace('/', '.'));
            call.setCalleeMethod(name);
            call.setCalleeDescriptor(descriptor);
            call.setCallLine(currentLine > 0 ? currentLine : null);

            // 根据操作码确定调用类型
            switch (opcode) {
                case Opcodes.INVOKEVIRTUAL:
                    call.setCallType("VIRTUAL");
                    break;
                case Opcodes.INVOKESTATIC:
                    call.setCallType("STATIC");
                    break;
                case Opcodes.INVOKESPECIAL:
                    call.setCallType("SPECIAL");
                    break;
                case Opcodes.INVOKEINTERFACE:
                    call.setCallType("INTERFACE");
                    break;
                default:
                    call.setCallType("UNKNOWN");
            }

            // 过滤掉一些不需要关注的调用
            if (!shouldSkip(owner, name)) {
                calls.add(call);
            }

            super.visitMethodInsn(opcode, owner, name, descriptor, isInterface);
        }

        @Override
        public void visitLineNumber(int line, org.objectweb.asm.Label start) {
            this.currentLine = line;
            super.visitLineNumber(line, start);
        }

        /**
         * 判断是否应该跳过该方法调用
         */
        private boolean shouldSkip(String owner, String name) {
            // 跳过Java核心类库的调用（可选，根据需求调整）
            if (owner.startsWith("java/lang/Object") ||
                owner.startsWith("java/lang/String") ||
                owner.startsWith("java/lang/Class")) {
                return true;
            }

            // 跳过构造方法的调用（通常不需要追溯）
            // 注意：某些场景可能需要保留，比如反序列化漏洞
            // if ("<init>".equals(name)) {
            //     return true;
            // }

            return false;
        }
    }
}
