package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.*;
import org.example.securityplatform.service.TestExecutionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 测试执行控制器
 */
@Tag(name = "测试执行", description = "测试执行生命周期管理和结果记录")
@RestController
@RequestMapping("/api/test-execution")
@RequiredArgsConstructor
public class TestExecutionController {

    private final TestExecutionService executionService;

    /**
     * 创建测试执行记录
     */
    @Operation(summary = "创建测试执行记录", description = "为测试清单项创建测试执行记录")
    @PostMapping
    public Result<TestExecutionResponse> createExecution(@RequestBody TestExecutionRequest request) {
        TestExecutionResponse response = executionService.createExecution(request);
        return Result.success(response);
    }

    /**
     * 批量创建测试执行（为所有TODO状态的测试清单创建执行记录）
     */
    @Operation(summary = "批量创建执行记录", description = "为制品下所有TODO状态的测试清单创建执行记录")
    @PostMapping("/batch/{artifactId}")
    public Result<List<TestExecutionResponse>> batchCreateExecutions(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        List<TestExecutionResponse> responses = executionService.batchCreateExecutions(artifactId);
        return Result.success(responses);
    }

    /**
     * 开始执行测试
     */
    @Operation(summary = "开始执行测试", description = "将测试执行状态更新为RUNNING")
    @PutMapping("/{id}/start")
    public Result<TestExecutionResponse> startExecution(
            @Parameter(description = "执行记录ID") @PathVariable Long id) {
        TestExecutionResponse response = executionService.startExecution(id);
        return Result.success(response);
    }

    /**
     * 完成测试执行
     */
    @Operation(summary = "完成测试执行", description = "记录测试结果并完成执行")
    @PutMapping("/{id}/complete")
    public Result<TestExecutionResponse> completeExecution(
            @Parameter(description = "执行记录ID") @PathVariable Long id,
            @RequestBody TestExecutionResultRequest result) {
        TestExecutionResponse response = executionService.completeExecution(id, result);
        return Result.success(response);
    }

    /**
     * 取消测试执行
     */
    @Operation(summary = "取消测试执行", description = "取消正在进行的测试执行")
    @PutMapping("/{id}/cancel")
    public Result<TestExecutionResponse> cancelExecution(
            @Parameter(description = "执行记录ID") @PathVariable Long id,
            @Parameter(description = "取消原因") @RequestParam(required = false) String reason) {
        TestExecutionResponse response = executionService.cancelExecution(id, reason);
        return Result.success(response);
    }

    /**
     * 获取测试执行记录
     */
    @Operation(summary = "获取执行记录", description = "根据ID获取测试执行记录详情")
    @GetMapping("/{id}")
    public Result<TestExecutionResponse> getExecution(
            @Parameter(description = "执行记录ID") @PathVariable Long id) {
        TestExecutionResponse response = executionService.getExecution(id);
        return Result.success(response);
    }

    /**
     * 获取制品的所有测试执行记录
     */
    @Operation(summary = "获取制品执行记录", description = "获取制品下的所有测试执行记录")
    @GetMapping("/artifact/{artifactId}")
    public Result<List<TestExecutionResponse>> getExecutionsByArtifact(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        List<TestExecutionResponse> responses = executionService.getExecutionsByArtifact(artifactId);
        return Result.success(responses);
    }

    /**
     * 获取测试清单的执行记录
     */
    @Operation(summary = "获取清单执行记录", description = "获取测试清单项的所有执行记录")
    @GetMapping("/checklist/{checklistId}")
    public Result<List<TestExecutionResponse>> getExecutionsByChecklist(
            @Parameter(description = "清单项ID") @PathVariable Long checklistId) {
        List<TestExecutionResponse> responses = executionService.getExecutionsByChecklist(checklistId);
        return Result.success(responses);
    }

    /**
     * 获取执行统计
     */
    @Operation(summary = "获取执行统计", description = "获取测试执行的统计数据")
    @GetMapping("/statistics/{artifactId}")
    public Result<Map<String, Object>> getExecutionStatistics(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        Map<String, Object> stats = executionService.getExecutionStatistics(artifactId);
        return Result.success(stats);
    }
}
