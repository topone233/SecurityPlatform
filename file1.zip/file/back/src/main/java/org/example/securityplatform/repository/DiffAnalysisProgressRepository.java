package org.example.securityplatform.repository;

import org.example.securityplatform.entity.DiffAnalysisProgress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * 差异分析进度数据访问接口
 */
@Repository
public interface DiffAnalysisProgressRepository extends JpaRepository<DiffAnalysisProgress, Long> {
    List<DiffAnalysisProgress> findByDiffTaskId(Long diffTaskId);
    Optional<DiffAnalysisProgress> findByDiffTaskIdAndCurrentStep(Long diffTaskId, String currentStep);
    void deleteByDiffTaskId(Long diffTaskId);
}
