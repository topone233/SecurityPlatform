import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    redirect: '/dashboard'
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: () => import('@/views/Dashboard.vue'),
    meta: { title: '仪表盘' }
  },
  {
    path: '/projects',
    name: 'ProjectList',
    component: () => import('@/views/ProjectList.vue'),
    meta: { title: '项目列表' }
  },
  {
    path: '/projects/:id',
    name: 'ProjectDetail',
    component: () => import('@/views/ProjectDetail.vue'),
    meta: { title: '项目详情' }
  },
  {
    path: '/tasks/:id',
    name: 'TaskDetail',
    component: () => import('@/views/TaskDetail.vue'),
    meta: { title: '任务详情' }
  },
  {
    path: '/artifacts/:id',
    name: 'ArtifactDetail',
    component: () => import('@/views/ArtifactDetail.vue'),
    meta: { title: '制品详情' }
  },
  {
    path: '/analysis/:artifactId',
    name: 'AnalysisResult',
    component: () => import('@/views/AnalysisResult.vue'),
    meta: { title: '分析结果' }
  },
  {
    path: '/strategy/checklist/:artifactId',
    name: 'TestChecklist',
    component: () => import('@/views/TestChecklist.vue'),
    meta: { title: '测试清单' }
  },
  {
    path: '/risk-exclusion/:artifactId',
    name: 'RiskExclusion',
    component: () => import('@/views/RiskExclusion.vue'),
    meta: { title: '风险排除' }
  },
  {
    path: '/execution/:artifactId',
    name: 'TestExecution',
    component: () => import('@/views/TestExecution.vue'),
    meta: { title: '测试执行' }
  },
  {
    path: '/reports',
    name: 'ReportList',
    component: () => import('@/views/ReportList.vue'),
    meta: { title: '测试报告' }
  },
  {
    path: '/reports/:id',
    name: 'ReportDetail',
    component: () => import('@/views/ReportDetail.vue'),
    meta: { title: '报告详情' }
  },
  {
    path: '/diff-analysis',
    name: 'DiffAnalysis',
    component: () => import('@/views/DiffAnalysis.vue'),
    meta: { title: '差异分析' }
  },
  {
    path: '/quick-diff',
    name: 'QuickDiff',
    component: () => import('@/views/QuickDiff.vue'),
    meta: { title: '快速对比' }
  },
  {
    path: '/quick-diff/history',
    name: 'QuickDiffHistory',
    component: () => import('@/views/QuickDiffHistory.vue'),
    meta: { title: '快速对比历史' }
  },
  {
    path: '/quick-diff/:id',
    name: 'QuickDiffDetail',
    component: () => import('@/views/QuickDiffDetail.vue'),
    meta: { title: '快速对比详情' }
  },
  {
    path: '/rule-management/test-cases',
    name: 'TestCaseManage',
    component: () => import('@/views/TestCaseManage.vue'),
    meta: { title: '测试用例库' }
  },
  {
    path: '/rule-management/config-items',
    name: 'ConfigCheckItemManage',
    component: () => import('@/views/ConfigCheckItemManage.vue'),
    meta: { title: '配置检查项' }
  },
  {
    path: '/rule-management/danger-function-rules',
    name: 'DangerFunctionRuleManage',
    component: () => import('@/views/DangerFunctionRuleManage.vue'),
    meta: { title: '危险函数规则' }
  },
  {
    path: '/taint-analysis',
    name: 'TaintAnalysis',
    component: () => import('@/views/TaintAnalysis.vue'),
    meta: { title: '污点分析' }
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('@/views/NotFound.vue'),
    meta: { title: '页面不存在' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  document.title = `${to.meta.title || '安全测试平台'} - 安全测试辅助平台`
  next()
})

export default router
