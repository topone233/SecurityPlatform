<template>
  <div class="sidebar-container">
    <div class="logo">
      <el-icon><Lock /></el-icon>
      <span>安全测试平台</span>
    </div>
    <el-menu
      :default-active="activeMenu"
      router
      background-color="#304156"
      text-color="#bfcbd9"
      active-text-color="#409eff"
    >
      <el-menu-item index="/dashboard">
        <el-icon><DataBoard /></el-icon>
        <span>仪表盘</span>
      </el-menu-item>

      <el-menu-item index="/projects">
        <el-icon><Folder /></el-icon>
        <span>项目管理</span>
      </el-menu-item>

      <el-sub-menu index="diff">
        <template #title>
          <el-icon><Sort /></el-icon>
          <span>差异对比</span>
        </template>
        <el-menu-item index="/quick-diff">
          <el-icon><Promotion /></el-icon>
          <span>快速对比</span>
        </el-menu-item>
        <el-menu-item index="/quick-diff/history">
          <el-icon><Clock /></el-icon>
          <span>快速对比历史</span>
        </el-menu-item>
        <el-menu-item index="/diff-analysis">
          <el-icon><Histogram /></el-icon>
          <span>差异分析</span>
        </el-menu-item>
      </el-sub-menu>

      <el-menu-item index="/reports">
        <el-icon><Document /></el-icon>
        <span>测试报告</span>
      </el-menu-item>

      <el-menu-item index="/taint-analysis">
        <el-icon><Aim /></el-icon>
        <span>污点分析</span>
      </el-menu-item>

      <el-sub-menu index="rules">
        <template #title>
          <el-icon><Setting /></el-icon>
          <span>规则配置</span>
        </template>
        <el-menu-item index="/rule-management/test-cases">
          <el-icon><Document /></el-icon>
          <span>测试用例库</span>
        </el-menu-item>
        <el-menu-item index="/rule-management/config-items">
          <el-icon><Checked /></el-icon>
          <span>配置检查项</span>
        </el-menu-item>
        <el-menu-item index="/rule-management/danger-function-rules">
          <el-icon><Warning /></el-icon>
          <span>危险函数规则</span>
        </el-menu-item>
      </el-sub-menu>
    </el-menu>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import {
  Clock, Setting, Checked, Warning, Aim, Lock,
  DataBoard, Folder, Sort, Promotion, Histogram, Document
} from '@element-plus/icons-vue'

const route = useRoute()

const activeMenu = computed(() => {
  const path = route.path
  if (path.startsWith('/projects')) return '/projects'
  if (path.startsWith('/quick-diff')) return '/quick-diff'
  if (path.startsWith('/diff-analysis')) return '/diff-analysis'
  if (path.startsWith('/reports')) return '/reports'
  if (path.startsWith('/taint-analysis')) return '/taint-analysis'
  if (path.startsWith('/rule-management')) return '/rule-management'
  return path
})
</script>

<style lang="scss" scoped>
.sidebar-container {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.logo {
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #263445;
  color: #fff;
  font-size: 18px;
  font-weight: bold;
  gap: 8px;

  .el-icon {
    font-size: 24px;
  }
}

.el-menu {
  border-right: none;
  flex: 1;
}
</style>
