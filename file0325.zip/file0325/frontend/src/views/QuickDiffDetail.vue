<template>
  <div class="quick-diff-detail">
    <el-card shadow="never" v-loading="loading">
      <template #header>
        <div class="card-header">
          <span>对比详情</span>
          <el-button @click="goBack">返回列表</el-button>
        </div>
      </template>

      <div v-if="error" class="error-container">
        <el-result icon="error" title="加载失败" :sub-title="error">
          <el-button type="primary" @click="loadDetail">重试</el-button>
        </el-result>
      </div>

      <div v-else-if="result">
        <!-- 文件变更统计 -->
        <div class="summary-section">
          <h3>文件变更统计</h3>
          <el-row :gutter="20">
            <el-col :span="6">
              <el-statistic title="新增文件" :value="result.fileSummary?.addedFiles || 0">
                <template #suffix>
                  <el-icon color="#67C23A"><DocumentAdd /></el-icon>
                </template>
              </el-statistic>
            </el-col>
            <el-col :span="6">
              <el-statistic title="修改文件" :value="result.fileSummary?.modifiedFiles || 0">
                <template #suffix>
                  <el-icon color="#E6A23C"><Edit /></el-icon>
                </template>
              </el-statistic>
            </el-col>
            <el-col :span="6">
              <el-statistic title="删除文件" :value="result.fileSummary?.deletedFiles || 0">
                <template #suffix>
                  <el-icon color="#F56C6C"><Delete /></el-icon>
                </template>
              </el-statistic>
            </el-col>
            <el-col :span="6">
              <el-statistic title="方法变更" :value="totalMethodChanges">
                <template #suffix>
                  <el-icon color="#409EFF"><Operation /></el-icon>
                </template>
              </el-statistic>
            </el-col>
          </el-row>
        </div>

        <el-divider />

        <!-- API变更统计 -->
        <div class="summary-section">
          <h3>API变更统计</h3>
          <el-row :gutter="20">
            <el-col :span="4">
              <div class="stat-box high">
                <div class="label">高危</div>
                <div class="value">{{ result.apiSummary?.highRiskApis || 0 }}</div>
              </div>
            </el-col>
            <el-col :span="4">
              <div class="stat-box medium">
                <div class="label">中危</div>
                <div class="value">{{ result.apiSummary?.mediumRiskApis || 0 }}</div>
              </div>
            </el-col>
            <el-col :span="4">
              <div class="stat-box low">
                <div class="label">低危</div>
                <div class="value">{{ result.apiSummary?.lowRiskApis || 0 }}</div>
              </div>
            </el-col>
            <el-col :span="4">
              <div class="stat-box">
                <div class="label">新增API</div>
                <div class="value">{{ result.apiSummary?.newApis || 0 }}</div>
              </div>
            </el-col>
            <el-col :span="4">
              <div class="stat-box">
                <div class="label">修改API</div>
                <div class="value">{{ result.apiSummary?.modifiedApis || 0 }}</div>
              </div>
            </el-col>
            <el-col :span="4">
              <div class="stat-box">
                <div class="label">删除API</div>
                <div class="value">{{ result.apiSummary?.deletedApis || 0 }}</div>
              </div>
            </el-col>
          </el-row>
        </div>

        <el-divider v-if="result.apiDiffs?.length" />

        <!-- API变更详情 -->
        <div class="detail-section" v-if="result.apiDiffs?.length">
          <h3>API变更详情</h3>
          <el-tabs v-model="activeTab">
            <el-tab-pane label="全部" name="all" />
            <el-tab-pane label="新增" name="NEW_API" />
            <el-tab-pane label="修改" name="MODIFIED_API" />
            <el-tab-pane label="受影响" name="AFFECTED_API" />
            <el-tab-pane label="删除" name="DELETED_API" />
          </el-tabs>

          <el-table :data="filteredApiDiffs" style="width: 100%">
            <el-table-column prop="httpMethod" label="方法" width="80">
              <template #default="{ row }">
                <el-tag :type="getMethodTagType(row.httpMethod)" size="small">
                  {{ row.httpMethod }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="apiUrl" label="API路径" min-width="200" show-overflow-tooltip />
            <el-table-column prop="changeType" label="变更类型" width="100">
              <template #default="{ row }">
                <el-tag :type="getChangeTypeTag(row.changeType)" size="small">
                  {{ getChangeTypeLabel(row.changeType) }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="riskLevel" label="风险" width="80">
              <template #default="{ row }">
                <el-tag :type="getRiskTagType(row.riskLevel)" size="small">
                  {{ row.riskLevel }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="changeReason" label="原因" min-width="200" show-overflow-tooltip />
            <el-table-column label="操作" width="80">
              <template #default="{ row }">
                <el-button type="primary" link @click="showApiDetail(row)">详情</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>

        <el-divider v-if="result.fileDiffs?.length" />

        <!-- 文件差异详情 -->
        <div class="detail-section" v-if="result.fileDiffs?.length">
          <h3>文件差异详情</h3>
          <el-table :data="result.fileDiffs" style="width: 100%">
            <el-table-column prop="filePath" label="文件路径" min-width="250" show-overflow-tooltip />
            <el-table-column prop="diffType" label="类型" width="100">
              <template #default="{ row }">
                <el-tag :type="getDiffTypeTag(row.diffType)" size="small">
                  {{ row.diffType }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="方法变更" min-width="200">
              <template #default="{ row }">
                <template v-if="row.methodChanges && row.methodChanges.length > 0">
                  <div class="method-changes">
                    <template v-for="(mc, index) in row.methodChanges.slice(0, 3)" :key="index">
                      <el-tag
                        :type="mc.changeType === 'ADDED' ? 'success' : mc.changeType === 'DELETED' ? 'danger' : 'warning'"
                        size="small"
                        class="method-tag"
                      >
                        {{ mc.changeType === 'ADDED' ? '+' : mc.changeType === 'DELETED' ? '-' : '~' }}{{ mc.methodName }}
                      </el-tag>
                    </template>
                    <el-popover
                      v-if="row.methodChanges.length > 3"
                      placement="left"
                      :width="400"
                      trigger="click"
                    >
                      <template #reference>
                        <el-tag type="info" size="small" class="method-tag clickable">
                          +{{ row.methodChanges.length - 3 }} 更多
                        </el-tag>
                      </template>
                      <div class="method-popover">
                        <div class="method-popover-header">
                          <span>共 {{ row.methodChanges.length }} 个方法变更</span>
                        </div>
                        <div class="method-popover-list">
                          <div
                            v-for="(mc, index) in row.methodChanges"
                            :key="index"
                            class="method-item"
                          >
                            <el-tag
                              :type="mc.changeType === 'ADDED' ? 'success' : mc.changeType === 'DELETED' ? 'danger' : 'warning'"
                              size="small"
                            >
                              {{ mc.changeType === 'ADDED' ? '+' : mc.changeType === 'DELETED' ? '-' : '~' }}
                              {{ mc.changeType === 'ADDED' ? '新增' : mc.changeType === 'DELETED' ? '删除' : '修改' }}
                            </el-tag>
                            <span class="method-name">{{ mc.methodName }}</span>
                          </div>
                        </div>
                      </div>
                    </el-popover>
                  </div>
                </template>
                <template v-else>
                  <span v-if="row.methodsAdded > 0" class="added">+{{ row.methodsAdded }}</span>
                  <span v-if="row.methodsModified > 0" class="modified">~{{ row.methodsModified }}</span>
                  <span v-if="row.methodsDeleted > 0" class="deleted">-{{ row.methodsDeleted }}</span>
                  <span v-if="row.methodsAdded === 0 && row.methodsModified === 0 && row.methodsDeleted === 0">-</span>
                </template>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </el-card>

    <!-- API详情弹窗 -->
    <el-dialog v-model="apiDetailVisible" title="API变更详情" width="600px">
      <el-descriptions :column="1" border v-if="selectedApi">
        <el-descriptions-item label="API路径">{{ selectedApi.apiUrl }}</el-descriptions-item>
        <el-descriptions-item label="HTTP方法">{{ selectedApi.httpMethod }}</el-descriptions-item>
        <el-descriptions-item label="控制器">{{ selectedApi.controllerClass }}</el-descriptions-item>
        <el-descriptions-item label="方法名">{{ selectedApi.methodName }}</el-descriptions-item>
        <el-descriptions-item label="变更类型">{{ getChangeTypeLabel(selectedApi.changeType) }}</el-descriptions-item>
        <el-descriptions-item label="风险等级">{{ selectedApi.riskLevel }}</el-descriptions-item>
        <el-descriptions-item label="变更原因">{{ selectedApi.changeReason }}</el-descriptions-item>
        <el-descriptions-item label="调用链" v-if="selectedApi.callChain?.length">
          <div class="call-chain">
            <template v-for="(node, index) in selectedApi.callChain" :key="index">
              <span class="node">{{ node.className }}.{{ node.methodName }}</span>
              <span v-if="index < selectedApi.callChain.length - 1" class="arrow">→</span>
            </template>
          </div>
        </el-descriptions-item>
      </el-descriptions>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { DocumentAdd, Edit, Delete, Operation } from '@element-plus/icons-vue'
import { useRoute, useRouter } from 'vue-router'
import diffAnalysisApi from '@/api/diffAnalysis'

const router = useRouter()
const route = useRoute()

const loading = ref(true)
const error = ref('')
const result = ref(null)
const activeTab = ref('all')
const apiDetailVisible = ref(false)
const selectedApi = ref(null)

// 计算属性
const totalMethodChanges = computed(() => {
  const s = result.value?.fileSummary || {}
  return (s.totalMethodsAdded || 0) + (s.totalMethodsModified || 0) + (s.totalMethodsDeleted || 0)
})

const filteredApiDiffs = computed(() => {
  if (!result.value?.apiDiffs) return []
  if (activeTab.value === 'all') return result.value.apiDiffs
  return result.value.apiDiffs.filter(api => api.changeType === activeTab.value)
})

// 方法
const loadDetail = async () => {
  const id = route.params.id
  loading.value = true
  error.value = ''

  try {
    const res = await diffAnalysisApi.getQuickDiffDetail(id)
    result.value = res.data || res
  } catch (e) {
    console.error('加载详情失败', e)
    error.value = e.message || '加载失败'
  } finally {
    loading.value = false
  }
}

const goBack = () => {
  router.push('/quick-diff/history')
}

const showApiDetail = (api) => {
  selectedApi.value = api
  apiDetailVisible.value = true
}

// 标签类型
const getMethodTagType = (method) => {
  const types = { GET: 'success', POST: 'primary', PUT: 'warning', DELETE: 'danger' }
  return types[method] || 'info'
}

const getChangeTypeTag = (type) => {
  const types = { NEW_API: 'success', MODIFIED_API: 'warning', AFFECTED_API: 'info', DELETED_API: 'danger' }
  return types[type] || ''
}

const getChangeTypeLabel = (type) => {
  const labels = { NEW_API: '新增', MODIFIED_API: '修改', AFFECTED_API: '受影响', DELETED_API: '删除' }
  return labels[type] || type
}

const getRiskTagType = (level) => {
  const types = { HIGH: 'danger', MEDIUM: 'warning', LOW: 'info' }
  return types[level] || ''
}

const getDiffTypeTag = (type) => {
  const types = { ADDED: 'success', MODIFIED: 'warning', DELETED: 'danger' }
  return types[type] || ''
}

onMounted(() => {
  loadDetail()
})
</script>

<style scoped>
.quick-diff-detail {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.error-container {
  padding: 60px 20px;
  text-align: center;
}

.summary-section {
  padding: 10px 0;
}

.summary-section h3 {
  margin-bottom: 15px;
  color: #303133;
}

.stat-box {
  text-align: center;
  padding: 20px;
  border-radius: 8px;
  background: #f5f7fa;
}

.stat-box.high {
  background: #fef0f0;
}

.stat-box.medium {
  background: #fdf6ec;
}

.stat-box.low {
  background: #f0f9eb;
}

.stat-box .label {
  font-size: 14px;
  color: #666;
}

.stat-box .value {
  font-size: 28px;
  font-weight: bold;
  margin-top: 5px;
}

.detail-section h3 {
  margin-bottom: 15px;
  color: #303133;
}

.added {
  color: #67C23A;
  margin-right: 10px;
}

.modified {
  color: #E6A23C;
  margin-right: 10px;
}

.deleted {
  color: #F56C6C;
}

.call-chain {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 5px;
}

.call-chain .node {
  padding: 2px 8px;
  background: #f0f2f5;
  border-radius: 4px;
  font-size: 12px;
}

.call-chain .arrow {
  color: #409EFF;
}

.method-changes {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.method-tag {
  font-size: 11px;
}

.method-tag.clickable {
  cursor: pointer;
}

.method-tag.clickable:hover {
  opacity: 0.8;
}

.method-popover {
  max-height: 400px;
  overflow-y: auto;
}

.method-popover-header {
  font-weight: bold;
  margin-bottom: 10px;
  padding-bottom: 8px;
  border-bottom: 1px solid #ebeef5;
}

.method-popover-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.method-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 4px 0;
}

.method-name {
  font-family: monospace;
  font-size: 13px;
  word-break: break-all;
}
</style>
