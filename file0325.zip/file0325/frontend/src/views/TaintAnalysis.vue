<template>
  <div class="taint-analysis">
    <!-- 头部 -->
    <el-card shadow="never">
      <div class="header">
        <h2>污点分析</h2>
        <div class="header-actions">
          <el-select v-model="vulnerabilityType" placeholder="选择漏洞类型" style="width: 150px;">
            <el-option label="SQL注入" value="SQL_INJECTION" />
            <el-option label="命令注入" value="COMMAND_INJECTION" disabled />
            <el-option label="SSRF" value="SSRF" disabled />
          </el-select>
          <el-select
            v-model="artifactId"
            filterable
            allow-create
            default-first-option
            placeholder="选择或输入制品ID"
            style="width: 250px; margin-left: 10px;"
            clearable
            :loading="loading"
          >
            <el-option
              v-for="item in artifacts"
              :key="item.id"
              :label="`${item.id} - ${item.artifactName}`"
              :value="String(item.id)"
            >
              <span>{{ item.id }} - {{ item.artifactName }}</span>
              <span style="color: #999; margin-left: 10px;">{{ item.artifactType }}</span>
            </el-option>
          </el-select>
          <el-button
            type="primary"
            :loading="analyzing"
            @click="startAnalysis"
            :disabled="!artifactId"
            style="margin-left: 10px;"
          >
            {{ analyzing ? '分析中...' : '开始分析' }}
          </el-button>
        </div>
      </div>
      <el-alert
        v-if="analyzing"
        :title="`正在分析制品 ${artifactId}...`"
        type="info"
        :closable="false"
        show-icon
        style="margin-top: 15px;"
      />
    </el-card>

    <!-- 结果区域 -->
    <template v-if="result">
      <!-- 统计卡片 -->
      <el-row :gutter="20" style="margin-top: 20px;">
        <el-col :span="6">
          <div class="stat-card">
            <div class="stat-icon" style="background: #F56C6C;">
              <el-icon><Warning /></el-icon>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ result.totalSinks }}</div>
              <div class="stat-label">Sink点总数</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="stat-card">
            <div class="stat-icon" style="background: #E6A23C;">
              <el-icon><Connection /></el-icon>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ result.tracedPaths }}</div>
              <div class="stat-label">已追踪路径</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="stat-card">
            <div class="stat-icon" style="background: #67C23A;">
              <el-icon><CircleCheck /></el-icon>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ result.reachablePaths }}</div>
              <div class="stat-label">可达路径</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="stat-card">
            <div class="stat-icon" style="background: #409EFF;">
              <el-icon><DataAnalysis /></el-icon>
            </div>
            <div class="stat-content">
              <div class="stat-value">{{ reachableRate }}%</div>
              <div class="stat-label">可达率</div>
            </div>
          </div>
        </el-col>
      </el-row>

      <!-- Sink列表 -->
      <el-card shadow="never" style="margin-top: 20px;">
        <template #header>
          <div class="card-header">
            <span>Sink点列表</span>
            <el-tag type="danger">{{ result.totalSinks }} 个风险点</el-tag>
          </div>
        </template>

        <el-table
          :data="result.sinks"
          stripe
          style="width: 100%"
          @row-click="handleRowClick"
        >
          <el-table-column type="expand">
            <template #default="{ row }">
              <div class="expand-content" v-if="row.paths && row.paths.length > 0">
                <h4>污点传播路径</h4>
                <TaintFlowGraph
                  :sink-data="row"
                  :paths="row.paths"
                />
              </div>
              <el-empty v-else description="无法追溯到Controller入口" :image-size="100" />
            </template>
          </el-table-column>
          <el-table-column prop="sinkClass" label="Sink类" min-width="180">
            <template #default="{ row }">
              <span class="mono">{{ getShortClassName(row.sinkClass) }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="sinkMethod" label="Sink方法" width="150">
            <template #default="{ row }">
              <span class="mono">{{ row.sinkMethod }}()</span>
            </template>
          </el-table-column>
          <el-table-column label="可注入参数" width="180">
            <template #default="{ row }">
              <template v-if="row.vulnerableParams && row.vulnerableParams.length > 0">
                <el-tag
                  v-for="param in row.vulnerableParams"
                  :key="param"
                  type="danger"
                  size="small"
                  style="margin-right: 5px;"
                >
                  {{ formatDollarParam(param) }}
                </el-tag>
              </template>
              <span v-else>-</span>
            </template>
          </el-table-column>
          <el-table-column prop="riskLevel" label="风险等级" width="100">
            <template #default="{ row }">
              <el-tag :type="getRiskType(row.riskLevel)">
                {{ row.riskLevel }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="可达路径" width="100" align="center">
            <template #default="{ row }">
              <el-badge
                :value="row.paths ? row.paths.length : 0"
                :type="row.paths && row.paths.length > 0 ? 'danger' : 'info'"
              >
                <el-icon><Connection /></el-icon>
              </el-badge>
            </template>
          </el-table-column>
          <el-table-column prop="sqlSnippet" label="SQL片段" min-width="250">
            <template #default="{ row }">
              <el-popover
                placement="top"
                :width="500"
                trigger="hover"
                v-if="row.sqlSnippet"
              >
                <template #reference>
                  <span class="sql-preview">{{ truncateText(row.sqlSnippet, 50) }}</span>
                </template>
                <pre class="sql-full">{{ row.sqlSnippet }}</pre>
              </el-popover>
              <span v-else>-</span>
            </template>
          </el-table-column>
        </el-table>
      </el-card>
    </template>

    <!-- 空状态 -->
    <el-empty
      v-if="!result && !analyzing"
      description="请输入制品ID开始分析"
      style="margin-top: 100px;"
    />
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Warning, Connection, CircleCheck, DataAnalysis } from '@element-plus/icons-vue'
import taintAnalysisApi from '@/api/taintAnalysis'
import artifactApi from '@/api/artifact'
import TaintFlowGraph from '@/components/taint/TaintFlowGraph.vue'

const artifactId = ref('')
const artifacts = ref([])
const loading = ref(false)
const vulnerabilityType = ref('SQL_INJECTION')
const analyzing = ref(false)
const result = ref(null)

const reachableRate = computed(() => {
  if (!result.value || result.value.totalSinks === 0) return 0
  return Math.round((result.value.reachablePaths / result.value.totalSinks) * 100)
})

async function startAnalysis() {
  if (!artifactId.value) {
    ElMessage.warning('请输入制品ID')
    return
  }

  analyzing.value = true
  result.value = null

  try {
    const res = await taintAnalysisApi.analyze(
      parseInt(artifactId.value),
      vulnerabilityType.value
    )
    result.value = res
    ElMessage.success(`分析完成，发现 ${res.totalSinks} 个Sink点`)
  } catch (error) {
    console.error('污点分析失败', error)
    ElMessage.error(error.response?.data?.message || '分析失败，请检查制品ID是否正确')
  } finally {
    analyzing.value = false
  }
}

async function loadArtifacts() {
  loading.value = true
  try {
    const res = await artifactApi.getAll()
    artifacts.value = res || []
  } catch (error) {
    console.error('加载制品列表失败', error)
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadArtifacts()
})

function handleRowClick(row) {
  // 点击行时展开详情
}

function getShortClassName(className) {
  if (!className) return '-'
  const parts = className.split('.')
  return parts.length > 2
    ? `...${parts.slice(-2).join('.')}`
    : className
}

function truncateText(text, maxLength) {
  if (!text) return ''
  return text.length > maxLength ? text.substring(0, maxLength) + '...' : text
}

function getRiskType(riskLevel) {
  const types = {
    HIGH: 'danger',
    MEDIUM: 'warning',
    LOW: 'info'
  }
  return types[riskLevel] || 'info'
}

function formatDollarParam(param) {
  return '${' + param + '}'
}
</script>

<style scoped>
.taint-analysis {
  padding: 20px;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header h2 {
  margin: 0;
  font-size: 20px;
}

.header-actions {
  display: flex;
  align-items: center;
}

.stat-card {
  display: flex;
  align-items: center;
  padding: 20px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.05);
}

.stat-icon {
  width: 50px;
  height: 50px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 24px;
  margin-right: 15px;
}

.stat-content {
  flex: 1;
}

.stat-value {
  font-size: 24px;
  font-weight: 600;
  color: #303133;
}

.stat-label {
  font-size: 14px;
  color: #909399;
  margin-top: 5px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.expand-content {
  padding: 20px;
}

.expand-content h4 {
  margin: 0 0 15px 0;
  color: #303133;
}

.mono {
  font-family: 'Consolas', 'Monaco', monospace;
  font-size: 13px;
}

.sql-preview {
  color: #606266;
  font-family: 'Consolas', 'Monaco', monospace;
  font-size: 12px;
  cursor: pointer;
}

.sql-full {
  background: #f5f7fa;
  padding: 10px;
  border-radius: 4px;
  font-size: 12px;
  overflow-x: auto;
  white-space: pre-wrap;
  word-break: break-all;
}
</style>