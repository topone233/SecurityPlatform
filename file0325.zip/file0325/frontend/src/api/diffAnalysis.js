import request from './index'

/**
 * 差异分析相关API
 */
export default {
  /**
   * 预览JAR包中的依赖信息
   * @param {File} file JAR文件
   * @returns {Promise} 包含依赖JAR列表和业务包名列表
   */
  previewDependencies(file) {
    const formData = new FormData()
    formData.append('file', file)
    return request.post('/quick-diff/preview-dependencies', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      timeout: 60000 // 1分钟超时
    })
  },

  /**
   * 快速差异对比 - 直接上传两个JAR包对比
   * @param {File} baselineFile 基线文件
   * @param {File} targetFile 目标文件
   * @param {Object} options 可选配置
   * @param {boolean} options.analyzeDependencies 是否分析依赖JAR
   * @param {string[]} options.includePackages 包含的包名模式
   * @param {string[]} options.includeJarNames 包含的JAR名称模式
   */
  quickDiff(baselineFile, targetFile, options = {}) {
    const formData = new FormData()
    formData.append('baseline', baselineFile)
    formData.append('target', targetFile)

    // 添加依赖分析配置
    if (options.analyzeDependencies) {
      formData.append('analyzeDependencies', 'true')
      if (options.includePackages && options.includePackages.length > 0) {
        formData.append('includePackages', options.includePackages.join(','))
      }
      if (options.includeJarNames && options.includeJarNames.length > 0) {
        formData.append('includeJarNames', options.includeJarNames.join(','))
      }
    }

    return request.post('/quick-diff/analyze', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      timeout: 300000 // 5分钟超时
    })
  },

  /**
   * 获取基线推荐
   */
  getBaselineRecommendation(projectId) {
    return request.get(`/diff-analysis/baseline/${projectId}`)
  },

  /**
   * 创建差异分析任务
   */
  createDiffAnalysis(data) {
    return request.post('/diff-analysis/create', data)
  },

  /**
   * 获取差异分析进度
   */
  getProgress(taskId) {
    return request.get(`/diff-analysis/${taskId}/progress`)
  },

  /**
   * 获取差异分析结果
   */
  getDiffResult(taskId) {
    return request.get(`/diff-analysis/${taskId}`)
  },

  /**
   * 按变更类型筛选API
   */
  getApisByChangeType(taskId, changeType) {
    return request.get(`/diff-analysis/${taskId}/apis`, { params: { changeType } })
  },

  /**
   * 按风险等级筛选API
   */
  getApisByRiskLevel(taskId, riskLevel) {
    return request.get(`/diff-analysis/${taskId}/risks`, { params: { riskLevel } })
  },

  /**
   * 导出差异分析报告
   */
  exportReport(taskId) {
    return request.get(`/diff-analysis/${taskId}/export`, { responseType: 'blob' })
  },

  /**
   * 快速差异对比并保存
   * @param {File} baselineFile 基线文件
   * @param {File} targetFile 目标文件
   * @param {string} description 描述
   * @param {Object} options 可选配置（同quickDiff）
   */
  quickDiffSave(baselineFile, targetFile, description, options = {}) {
    const formData = new FormData()
    formData.append('baseline', baselineFile)
    formData.append('target', targetFile)
    if (description) {
      formData.append('description', description)
    }

    // 添加依赖分析配置
    if (options.analyzeDependencies) {
      formData.append('analyzeDependencies', 'true')
      if (options.includePackages && options.includePackages.length > 0) {
        formData.append('includePackages', options.includePackages.join(','))
      }
      if (options.includeJarNames && options.includeJarNames.length > 0) {
        formData.append('includeJarNames', options.includeJarNames.join(','))
      }
    }

    return request.post('/quick-diff/save', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      timeout: 300000 // 5分钟超时
    })
  },

  /**
   * 获取快速对比历史列表
   */
  getQuickDiffList() {
    return request.get('/quick-diff/list')
  },

  /**
   * 获取快速对比详情
   */
  getQuickDiffDetail(id) {
    return request.get(`/quick-diff/${id}`)
  },

  /**
   * 删除快速对比记录
   */
  deleteQuickDiff(id) {
    return request.delete(`/quick-diff/${id}`)
  }
}
