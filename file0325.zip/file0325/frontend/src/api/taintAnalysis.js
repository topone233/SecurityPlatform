import request from './index'

/**
 * 污点分析API
 */
export default {
  /**
   * 执行污点分析
   * @param {number} artifactId 制品ID
   * @param {string} vulnerabilityType 漏洞类型
   */
  analyze(artifactId, vulnerabilityType = 'SQL_INJECTION') {
    return request.post(`/taint/analyze/${artifactId}`, null, {
      params: { vulnerabilityType },
      timeout: 300000 // 5分钟超时
    })
  },

  /**
   * 获取污点分析结果
   * @param {number} artifactId 制品ID
   * @param {string} vulnerabilityType 漏洞类型
   */
  getResult(artifactId, vulnerabilityType = 'SQL_INJECTION') {
    return request.get(`/taint/result/${artifactId}`, {
      params: { vulnerabilityType }
    })
  },

  /**
   * 获取Sink详情
   * @param {number} sinkId Sink ID
   */
  getSinkDetail(sinkId) {
    return request.get(`/taint/sink/${sinkId}`)
  }
}