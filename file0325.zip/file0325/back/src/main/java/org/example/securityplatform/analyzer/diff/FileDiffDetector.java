package org.example.securityplatform.analyzer.diff;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.jar.JarInfo;
import org.example.securityplatform.analyzer.jar.MultiJarClasspathBuilder;
import org.example.securityplatform.util.HashUtil;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 文件差异检测器 - 对比两个JAR包的文件差异
 * 支持多JAR类路径分析
 */
@Slf4j
public class FileDiffDetector {

    private final String baselineJarPath;
    private final String targetJarPath;
    private final BytecodeDiffAnalyzer bytecodeDiffAnalyzer = new BytecodeDiffAnalyzer();

    // 多JAR支持
    private MultiJarClasspathBuilder baselineClasspath;
    private MultiJarClasspathBuilder targetClasspath;

    public FileDiffDetector(String baselineJarPath, String targetJarPath) {
        this.baselineJarPath = baselineJarPath;
        this.targetJarPath = targetJarPath;
    }

    /**
     * 使用多JAR类路径构建器进行差异检测
     */
    public FileDiffDetector(MultiJarClasspathBuilder baselineClasspath,
                           MultiJarClasspathBuilder targetClasspath) {
        this.baselineClasspath = baselineClasspath;
        this.targetClasspath = targetClasspath;
        // 从类路径中获取主JAR路径（用于向后兼容）
        this.baselineJarPath = null;
        this.targetJarPath = null;
    }

    /**
     * 检测文件差异
     *
     * @return 文件差异列表
     */
    public List<FileDiffModel> detect() throws IOException {
        // 如果使用了多JAR类路径构建器，使用新的检测逻辑
        if (baselineClasspath != null && targetClasspath != null) {
            return detectWithClasspath();
        }

        // 向后兼容：使用传统的单JAR检测逻辑
        return detectSingleJar();
    }

    /**
     * 使用多JAR类路径进行差异检测
     */
    private List<FileDiffModel> detectWithClasspath() throws IOException {
        log.info("开始多JAR文件差异检测");

        List<FileDiffModel> diffs = new ArrayList<>();

        // 获取两个类路径的所有类
        Set<String> allPaths = new HashSet<>();
        allPaths.addAll(baselineClasspath.getAllClassPaths());
        allPaths.addAll(targetClasspath.getAllClassPaths());

        log.info("总共 {} 个唯一类路径需要对比", allPaths.size());

        // 对比每个类文件
        for (String path : allPaths) {
            FileDiffModel diff = analyzeFileDiffWithClasspath(path);
            if (diff != null && diff.hasChanges()) {
                diffs.add(diff);
            }
        }

        log.info("多JAR文件差异检测完成: 共 {} 个文件变更", diffs.size());
        return diffs;
    }

    /**
     * 分析单个文件差异（使用多JAR类路径）
     */
    private FileDiffModel analyzeFileDiffWithClasspath(String path) throws IOException {
        FileDiffModel diff = new FileDiffModel();
        diff.setFilePath(path);
        diff.setSourceFilePath(FileDiffModel.inferSourcePath(path));

        MultiJarClasspathBuilder.ClassLocation baselineLoc = baselineClasspath.getClassLocation(path);
        MultiJarClasspathBuilder.ClassLocation targetLoc = targetClasspath.getClassLocation(path);

        boolean inBaseline = baselineLoc != null;
        boolean inTarget = targetLoc != null;

        if (!inBaseline && inTarget) {
            // 新增文件
            diff.setDiffType("ADDED");
            diff.setSourceJar(targetLoc.getJar().getName());
            diff.setJarType(targetLoc.getJar().getType().name());

            try (InputStream is = targetClasspath.getClassInputStream(path)) {
                diff.setTargetMd5(HashUtil.calculateMd5(is));
            }
            diff.setBaselineLines(0);
            diff.setTargetLines(0);
            diff.setMethodsAdded(0);

            return diff;

        } else if (inBaseline && !inTarget) {
            // 删除文件
            diff.setDiffType("DELETED");
            diff.setSourceJar(baselineLoc.getJar().getName());
            diff.setJarType(baselineLoc.getJar().getType().name());

            try (InputStream is = baselineClasspath.getClassInputStream(path)) {
                diff.setBaselineMd5(HashUtil.calculateMd5(is));
            }
            diff.setBaselineLines(0);
            diff.setTargetLines(0);
            diff.setMethodsDeleted(0);

            return diff;

        } else if (inBaseline && inTarget) {
            // 两边都有，检查是否修改
            diff.setSourceJar(baselineLoc.getJar().getName());  // 使用baseline的来源
            diff.setJarType(baselineLoc.getJar().getType().name());

            String baselineMd5;
            String targetMd5;

            try (InputStream baselineIs = baselineClasspath.getClassInputStream(path);
                 InputStream targetIs = targetClasspath.getClassInputStream(path)) {

                baselineMd5 = HashUtil.calculateMd5(baselineIs);
                targetMd5 = HashUtil.calculateMd5(targetIs);

                diff.setBaselineMd5(baselineMd5);
                diff.setTargetMd5(targetMd5);
            }

            if (baselineMd5.equals(targetMd5)) {
                // 未修改
                diff.setDiffType("UNCHANGED");
                return null;
            }

            // 修改的文件
            diff.setDiffType("MODIFIED");

            // 检查来源JAR是否变化
            if (!baselineLoc.getJar().getName().equals(targetLoc.getJar().getName())) {
                log.info("Class {} moved from {} to {}", path,
                        baselineLoc.getJar().getName(), targetLoc.getJar().getName());
                diff.setSourceJar(baselineLoc.getJar().getName() + " -> " + targetLoc.getJar().getName());
            }

            // 字节码差异分析
            try (InputStream baselineIs = baselineClasspath.getClassInputStream(path);
                 InputStream targetIs = targetClasspath.getClassInputStream(path)) {

                BytecodeDiffResult bytecodeDiff = bytecodeDiffAnalyzer.analyze(baselineIs, targetIs, path);
                diff.setBytecodeDiff(bytecodeDiff);
                diff.setBaselineLines(bytecodeDiff.getBaselineInstructions());
                diff.setTargetLines(bytecodeDiff.getTargetInstructions());
                diff.setMethodsAdded(bytecodeDiff.getMethodsAdded());
                diff.setMethodsDeleted(bytecodeDiff.getMethodsDeleted());
                diff.setMethodsModified(bytecodeDiff.getMethodsModified());

            } catch (Exception e) {
                log.warn("字节码差异分析失败，跳过: {}", path, e);
                diff.setBaselineLines(0);
                diff.setTargetLines(0);
                diff.setMethodsAdded(0);
                diff.setMethodsDeleted(0);
                diff.setMethodsModified(0);
            }

            return diff;
        }

        return null;
    }

    /**
     * 传统的单JAR差异检测（向后兼容）
     */
    private List<FileDiffModel> detectSingleJar() throws IOException {
        log.info("开始文件差异检测: baseline={}, target={}", baselineJarPath, targetJarPath);

        List<FileDiffModel> diffs = new ArrayList<>();

        // 获取两个JAR包的class文件列表
        Map<String, JarEntry> baselineEntries = getClassEntries(baselineJarPath);
        Map<String, JarEntry> targetEntries = getClassEntries(targetJarPath);

        Set<String> allPaths = new HashSet<>();
        allPaths.addAll(baselineEntries.keySet());
        allPaths.addAll(targetEntries.keySet());

        // 对比每个文件
        for (String path : allPaths) {
            FileDiffModel diff = analyzeFileDiff(path, baselineEntries, targetEntries);
            if (diff != null && diff.hasChanges()) {
                diffs.add(diff);
            }
        }

        log.info("文件差异检测完成: 共 {} 个文件变更", diffs.size());
        return diffs;
    }

    /**
     * 获取JAR包中的所有class文件
     */
    private Map<String, JarEntry> getClassEntries(String jarPath) throws IOException {
        Map<String, JarEntry> entries = new HashMap<>();
        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> enumeration = jarFile.entries();
            while (enumeration.hasMoreElements()) {
                JarEntry entry = enumeration.nextElement();
                if (entry.getName().endsWith(".class") && !entry.isDirectory()) {
                    entries.put(entry.getName(), entry);
                }
            }
        }
        return entries;
    }

    /**
     * 分析单个文件的差异
     */
    private FileDiffModel analyzeFileDiff(String path,
                                           Map<String, JarEntry> baselineEntries,
                                           Map<String, JarEntry> targetEntries) throws IOException {
        FileDiffModel diff = new FileDiffModel();
        diff.setFilePath(path);
        diff.setSourceFilePath(FileDiffModel.inferSourcePath(path));

        boolean inBaseline = baselineEntries.containsKey(path);
        boolean inTarget = targetEntries.containsKey(path);

        if (!inBaseline && inTarget) {
            // 新增文件
            diff.setDiffType("ADDED");
            diff.setBaselineLines(0);
            diff.setBaselineMd5(null);

            try (JarFile targetJar = new JarFile(targetJarPath)) {
                JarEntry entry = targetEntries.get(path);
                try (InputStream is = targetJar.getInputStream(entry)) {
                    diff.setTargetMd5(HashUtil.calculateMd5(is));
                }
                // 字节码分析对于新增的文件跳过，因为没有基线可对比
                diff.setTargetLines(0);
                diff.setMethodsAdded(0);
            } catch (Exception e) {
                log.warn("分析新增的文件失败: {}", path, e);
            }
            return diff;

        } else if (inBaseline && !inTarget) {
            // 删除文件
            diff.setDiffType("DELETED");
            diff.setTargetLines(0);
            diff.setTargetMd5(null);

            try (JarFile baselineJar = new JarFile(baselineJarPath)) {
                JarEntry entry = baselineEntries.get(path);
                try (InputStream is = baselineJar.getInputStream(entry)) {
                    diff.setBaselineMd5(HashUtil.calculateMd5(is));
                }
                // 字节码分析对于删除的文件跳过，因为没有目标文件可对比
                diff.setBaselineLines(0);
                diff.setMethodsDeleted(0);
            } catch (Exception e) {
                log.warn("分析删除的文件失败: {}", path, e);
            }
            return diff;

        } else if (inBaseline && inTarget) {
            // 两边都有，检查是否修改
            try (JarFile baselineJar = new JarFile(baselineJarPath);
                 JarFile targetJar = new JarFile(targetJarPath)) {

                JarEntry baselineEntry = baselineEntries.get(path);
                JarEntry targetEntry = targetEntries.get(path);

                try (InputStream baselineIs = baselineJar.getInputStream(baselineEntry);
                     InputStream targetIs = targetJar.getInputStream(targetEntry)) {

                    String baselineMd5 = HashUtil.calculateMd5(baselineIs);
                    String targetMd5 = HashUtil.calculateMd5(targetIs);

                    diff.setBaselineMd5(baselineMd5);
                    diff.setTargetMd5(targetMd5);

                    if (baselineMd5.equals(targetMd5)) {
                        // 未修改
                        diff.setDiffType("UNCHANGED");
                        return null;
                    }

                    // 修改的文件
                    diff.setDiffType("MODIFIED");

                    // 重新打开流进行字节码分析
                    try (InputStream baselineIs2 = baselineJar.getInputStream(baselineEntry);
                         InputStream targetIs2 = targetJar.getInputStream(targetEntry)) {

                        BytecodeDiffResult bytecodeDiff = analyzeBytecode(baselineIs2, targetIs2, path);
                        diff.setBytecodeDiff(bytecodeDiff);
                        diff.setBaselineLines(bytecodeDiff.getBaselineInstructions());
                        diff.setTargetLines(bytecodeDiff.getTargetInstructions());
                        diff.setMethodsAdded(bytecodeDiff.getMethodsAdded());
                        diff.setMethodsDeleted(bytecodeDiff.getMethodsDeleted());
                        diff.setMethodsModified(bytecodeDiff.getMethodsModified());
                    } catch (Exception e) {
                        log.warn("字节码差异分析失败，跳过: {}", path, e);
                        // 设置默认值
                        diff.setBaselineLines(0);
                        diff.setTargetLines(0);
                        diff.setMethodsAdded(0);
                        diff.setMethodsDeleted(0);
                        diff.setMethodsModified(0);
                    }
                }
            }
            return diff;
        }

        return null;
    }

    /**
     * 分析字节码差异
     */
    private BytecodeDiffResult analyzeBytecode(InputStream baselineStream,
                                                 InputStream targetStream,
                                                 String filePath) throws IOException {
        return bytecodeDiffAnalyzer.analyze(baselineStream, targetStream, filePath);
    }

    /**
     * 获取差异统计
     */
    public DiffStatistics getStatistics(List<FileDiffModel> diffs) {
        DiffStatistics stats = new DiffStatistics();
        for (FileDiffModel diff : diffs) {
            switch (diff.getDiffType()) {
                case "ADDED":
                    stats.addedFiles++;
                    break;
                case "DELETED":
                    stats.deletedFiles++;
                    break;
                case "MODIFIED":
                    stats.modifiedFiles++;
                    break;
            }
            stats.totalMethodsAdded += diff.getMethodsAdded();
            stats.totalMethodsDeleted += diff.getMethodsDeleted();
            stats.totalMethodsModified += diff.getMethodsModified();
        }
        return stats;
    }

    /**
     * 差异统计
     */
    @lombok.Data
    public static class DiffStatistics {
        private int addedFiles = 0;
        private int modifiedFiles = 0;
        private int deletedFiles = 0;
        private int totalMethodsAdded = 0;
        private int totalMethodsDeleted = 0;
        private int totalMethodsModified = 0;
    }
}