package org.example.securityplatform.repository;

import org.example.securityplatform.entity.TaintPath;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 污点路径数据访问接口
 */
@Repository
public interface TaintPathRepository extends JpaRepository<TaintPath, Long> {

    List<TaintPath> findBySinkId(Long sinkId);

    List<TaintPath> findBySourceClass(String sourceClass);

    List<TaintPath> findBySourceClassAndSourceMethod(String sourceClass, String sourceMethod);

    List<TaintPath> findByIsReachable(Boolean isReachable);

    void deleteBySinkId(Long sinkId);

    void deleteBySinkIdIn(List<Long> sinkIds);
}