package org.example.securityplatform.analyzer.mybatis;

import lombok.extern.slf4j.Slf4j;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * MyBatis Mapper XML解析器
 * 从JAR包中提取并解析Mapper XML文件，检测${}占位符注入风险
 */
@Slf4j
public class MyBatisMapperParser {

    private static final Pattern DOLLAR_PARAM_PATTERN = Pattern.compile("\\$\\{([^}]+)\\}");

    /**
     * 解析JAR包中的MyBatis Mapper文件
     *
     * @param jarPath JAR包路径
     * @return Mapper模型列表
     */
    public List<MyBatisMapperModel> parse(String jarPath) throws IOException {
        List<MyBatisMapperModel> mappers = new ArrayList<>();

        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> entries = jarFile.entries();

            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (isMapperXml(entry.getName())) {
                    try (InputStream is = jarFile.getInputStream(entry)) {
                        MyBatisMapperModel mapper = parseMapperXml(is, entry.getName());
                        if (mapper != null && !mapper.getStatements().isEmpty()) {
                            mappers.add(mapper);
                        }
                    } catch (Exception e) {
                        log.warn("解析Mapper XML失败: {}", entry.getName(), e);
                    }
                }
            }
        }

        log.info("从JAR包中解析到 {} 个Mapper文件", mappers.size());
        return mappers;
    }

    /**
     * 判断是否是Mapper XML文件
     */
    private boolean isMapperXml(String fileName) {
        String lowerName = fileName.toLowerCase();
        return lowerName.endsWith(".xml") &&
                (lowerName.contains("mapper") ||
                        lowerName.contains("mybatis") ||
                        lowerName.contains("dao"));
    }

    /**
     * 解析单个Mapper XML文件
     */
    private MyBatisMapperModel parseMapperXml(InputStream is, String filePath) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        // 禁用外部实体解析，防止XXE攻击
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);

        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(is);

        Element root = document.getDocumentElement();
        String namespace = root.getAttribute("namespace");

        MyBatisMapperModel mapper = new MyBatisMapperModel();
        mapper.setNamespace(namespace);
        mapper.setFilePath(filePath);

        // 解析各种SQL语句
        parseStatements(root, mapper, "select");
        parseStatements(root, mapper, "insert");
        parseStatements(root, mapper, "update");
        parseStatements(root, mapper, "delete");

        return mapper;
    }

    /**
     * 解析指定类型的SQL语句
     */
    private void parseStatements(Element root, MyBatisMapperModel mapper, String tagName) {
        NodeList nodes = root.getElementsByTagName(tagName);
        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                MyBatisMapperModel.SqlStatement stmt = new MyBatisMapperModel.SqlStatement();

                stmt.setId(element.getAttribute("id"));
                stmt.setType(tagName.toUpperCase());
                stmt.setSql(extractSql(element));

                // 检测${}占位符
                List<String> dollarParams = extractDollarParams(stmt.getSql());
                stmt.setDollarParams(dollarParams);

                // 只有包含${}占位符的才记录
                if (!dollarParams.isEmpty()) {
                    mapper.getStatements().add(stmt);
                }
            }
        }
    }

    /**
     * 从元素中提取SQL文本（包括处理动态SQL标签）
     */
    private String extractSql(Element element) {
        StringBuilder sql = new StringBuilder();
        extractTextRecursive(element, sql);
        return sql.toString().trim().replaceAll("\\s+", " ");
    }

    /**
     * 递归提取文本内容
     */
    private void extractTextRecursive(Element element, StringBuilder sql) {
        NodeList children = element.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == Node.TEXT_NODE) {
                String text = child.getTextContent().trim();
                if (!text.isEmpty()) {
                    sql.append(text).append(" ");
                }
            } else if (child.getNodeType() == Node.ELEMENT_NODE) {
                // 处理动态SQL标签，提取其中的内容
                Element childElement = (Element) child;
                String tagName = childElement.getTagName();
                if ("if".equals(tagName) || "where".equals(tagName) ||
                        "set".equals(tagName) || "trim".equals(tagName) ||
                        "foreach".equals(tagName) || "choose".equals(tagName)) {
                    extractTextRecursive(childElement, sql);
                }
            }
        }
    }

    /**
     * 检测SQL中的${}占位符
     *
     * @param sql SQL文本
     * @return 参数名列表
     */
    public List<String> extractDollarParams(String sql) {
        List<String> params = new ArrayList<>();
        if (sql == null) {
            return params;
        }

        Matcher matcher = DOLLAR_PARAM_PATTERN.matcher(sql);
        while (matcher.find()) {
            String param = matcher.group(1).trim();
            if (!params.contains(param)) {
                params.add(param);
            }
        }
        return params;
    }
}