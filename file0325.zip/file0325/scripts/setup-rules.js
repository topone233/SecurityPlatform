#!/usr/bin/env node

/**
 * 一键导入流程脚本
 *
 * 执行步骤：
 * 1. 验证配置文件格式
 * 2. 测试 API 连接
 * 3. 导入规则
 * 4. 验证导入结果
 */

const { execSync } = require('child_process');
const path = require('path');

console.log('🚀 危险函数规则一键导入流程\n');
console.log('=' .repeat(60));

// 步骤 1: 验证配置文件
console.log('\n📝 步骤 1/4: 验证规则配置文件格式');
console.log('-'.repeat(60));
try {
  execSync('node scripts/validate-rules.js', { stdio: 'inherit' });
} catch (error) {
  console.error('\n❌ 配置文件验证失败，请修复错误后重试');
  process.exit(1);
}

// 步骤 2: 测试 API 连接
console.log('\n\n🔗 步骤 2/4: 测试 API 连接');
console.log('-'.repeat(60));
try {
  execSync('node scripts/test-api.js', { stdio: 'inherit' });
} catch (error) {
  console.error('\n❌ API 连接失败，请确认后端服务已启动');
  console.error('💡 启动命令: mvn spring-boot:run');
  process.exit(1);
}

// 步骤 3: 导入规则
console.log('\n\n📥 步骤 3/4: 导入规则到数据库');
console.log('-'.repeat(60));

const args = process.argv.slice(2);
const shouldClear = args.includes('--clear') ? '--clear' : '';

try {
  if (shouldClear) {
    console.log('⚠️  将清空现有规则后导入');
  }
  execSync(`node scripts/import-rules.js ${shouldClear}`, { stdio: 'inherit' });
} catch (error) {
  console.error('\n❌ 规则导入失败');
  process.exit(1);
}

// 步骤 4: 验证结果
console.log('\n\n✅ 步骤 4/4: 验证导入结果');
console.log('-'.repeat(60));
try {
  execSync('node scripts/test-api.js', { stdio: 'inherit' });
} catch (error) {
  console.error('\n❌ 验证失败');
  process.exit(1);
}

console.log('\n' + '='.repeat(60));
console.log('🎉 一键导入流程完成！');
console.log('='.repeat(60));
console.log('\n📚 下一步:');
console.log('   1. 访问前端管理界面: http://localhost:5173');
console.log('   2. 导航至: 规则管理 -> 危险函数规则');
console.log('   3. 创建分析任务测试规则效果');
console.log('\n📖 详细文档: docs/DANGER_FUNCTION_RULES.md\n');

process.exit(0);