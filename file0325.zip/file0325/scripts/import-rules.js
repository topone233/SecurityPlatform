#!/usr/bin/env node

/**
 * 危险函数规则导入脚本
 *
 * 功能：
 * 1. 读取 config/danger-function-rules.json 配置文件
 * 2. 通过 API 批量导入规则到数据库
 * 3. 支持清空现有规则或追加规则
 *
 * 使用方法：
 * node scripts/import-rules.js [--clear] [--api-url=http://localhost:8080]
 *
 * 参数：
 * --clear        导入前清空现有规则
 * --api-url      指定 API 地址（默认 http://localhost:8080）
 */

const fs = require('fs');
const path = require('path');

// 解析命令行参数
const args = process.argv.slice(2);
const shouldClear = args.includes('--clear');
const apiUrlArg = args.find(arg => arg.startsWith('--api-url='));
const baseUrl = apiUrlArg ? apiUrlArg.split('=')[1] : 'http://localhost:8001';

const RULES_FILE = path.join(__dirname, '../config/danger-function-rules.json');
const API_ENDPOINT = `${baseUrl}/api/danger-function-rules`;

console.log('🚀 危险函数规则导入工具');
console.log(`📍 API 地址: ${API_ENDPOINT}`);
console.log(`📁 配置文件: ${RULES_FILE}`);
console.log(`🗑️  清空现有规则: ${shouldClear ? '是' : '否'}\n`);

// 读取规则配置文件
async function loadRules() {
  try {
    const content = fs.readFileSync(RULES_FILE, 'utf-8');
    const data = JSON.parse(content);
    return data.rules || [];
  } catch (error) {
    console.error('❌ 读取配置文件失败:', error.message);
    process.exit(1);
  }
}

// 获取现有规则
async function fetchExistingRules() {
  try {
    const response = await fetch(API_ENDPOINT);

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const result = await response.json();

    // 处理 Result<T> 响应格式
    if (result.code !== 200) {
      throw new Error(`API Error ${result.code}: ${result.message}`);
    }

    return result.data || [];
  } catch (error) {
    console.error('❌ 获取现有规则失败:', error.message);
    console.error('💡 请确认后端服务已启动且 API 可访问');
    process.exit(1);
  }
}

// 删除所有规则
async function clearAllRules(existingRules) {
  console.log(`🗑️  正在删除 ${existingRules.length} 条现有规则...`);

  let deleted = 0;
  let failed = 0;

  for (const rule of existingRules) {
    try {
      const response = await fetch(`${API_ENDPOINT}/${rule.id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        const result = await response.json();

        // 处理 Result<T> 响应格式
        if (result.code === 200) {
          deleted++;
          process.stdout.write(`\r✅ 已删除: ${deleted}/${existingRules.length}`);
        } else {
          failed++;
          console.error(`\n❌ 删除规则失败 [ID: ${rule.id}]: API Error ${result.code} - ${result.message}`);
        }
      } else {
        failed++;
        console.error(`\n❌ 删除规则失败 [ID: ${rule.id}]: HTTP ${response.status}`);
      }
    } catch (error) {
      failed++;
      console.error(`\n❌ 删除规则失败 [ID: ${rule.id}]: ${error.message}`);
    }
  }

  console.log(`\n📊 删除完成: 成功 ${deleted} 条，失败 ${failed} 条\n`);
  return { deleted, failed };
}

// 创建规则
async function createRule(rule) {
  try {
    const response = await fetch(API_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(rule)
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`HTTP ${response.status}: ${error}`);
    }

    const result = await response.json();

    // 处理 Result<T> 响应格式
    if (result.code !== 200) {
      throw new Error(`API Error ${result.code}: ${result.message}`);
    }

    return result.data;
  } catch (error) {
    throw error;
  }
}

// 导入规则
async function importRules(rules) {
  console.log(`📥 正在导入 ${rules.length} 条规则...\n`);

  let imported = 0;
  let failed = 0;
  const failedRules = [];

  for (const rule of rules) {
    try {
      await createRule(rule);
      imported++;

      // 显示进度
      const percentage = ((imported / rules.length) * 100).toFixed(1);
      process.stdout.write(`\r⏳ 进度: ${imported}/${rules.length} (${percentage}%)`);

    } catch (error) {
      failed++;
      failedRules.push({
        ruleName: rule.ruleName,
        error: error.message
      });
    }
  }

  console.log(`\n\n📊 导入完成:`);
  console.log(`   ✅ 成功: ${imported} 条`);
  console.log(`   ❌ 失败: ${failed} 条`);

  if (failedRules.length > 0) {
    console.log('\n❌ 失败的规则:');
    failedRules.forEach(({ ruleName, error }) => {
      console.log(`   - ${ruleName}: ${error}`);
    });
  }

  return { imported, failed, failedRules };
}

// 统计规则类型
function printRuleStatistics(rules) {
  const statistics = {};

  rules.forEach(rule => {
    const type = rule.functionType;
    statistics[type] = (statistics[type] || 0) + 1;
  });

  console.log('\n📈 规则统计:');
  Object.entries(statistics)
    .sort((a, b) => b[1] - a[1])
    .forEach(([type, count]) => {
      console.log(`   ${type}: ${count} 条`);
    });
  console.log(`   总计: ${rules.length} 条\n`);
}

// 主函数
async function main() {
  try {
    // 1. 加载规则
    const rules = await loadRules();
    console.log(`✅ 成功加载 ${rules.length} 条规则\n`);

    // 2. 显示统计
    printRuleStatistics(rules);

    // 3. 获取现有规则
    const existingRules = await fetchExistingRules();
    console.log(`📊 数据库中现有规则: ${existingRules.length} 条\n`);

    // 4. 清空现有规则（如果指定）
    if (shouldClear && existingRules.length > 0) {
      await clearAllRules(existingRules);
    }

    // 5. 导入规则
    const result = await importRules(rules);

    // 6. 最终验证
    const finalRules = await fetchExistingRules();
    console.log(`\n✨ 数据库中现在有 ${finalRules.length} 条规则`);

    // 7. 返回退出码
    process.exit(result.failed > 0 ? 1 : 0);

  } catch (error) {
    console.error('\n❌ 导入过程出错:', error);
    process.exit(1);
  }
}

// 运行
main();