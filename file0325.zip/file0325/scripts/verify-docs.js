#!/usr/bin/env node

/**
 * 文档一致性验证脚本
 *
 * 检查所有文档中的端口号是否一致
 */

const fs = require('fs');
const path = require('path');

const DOCS_DIR = path.join(__dirname, '../docs');
const EXPECTED_PORT = {
  backend: '8001',
  frontend: '3000'
};

console.log('🔍 验证文档端口配置一致性...\n');

const errors = [];
const warnings = [];
const checkedFiles = [];

// 检查文件中的端口号
function checkFile(filePath, filename) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');

    // 检查后端端口
    const backendPortMatches = content.match(/localhost:80\d{2}/g) || [];
    backendPortMatches.forEach(match => {
      if (!match.includes(EXPECTED_PORT.backend)) {
        errors.push(`❌ ${filename}: 发现错误的后端端口 "${match}" (应为 ${EXPECTED_PORT.backend})`);
      }
    });

    // 检查前端端口
    const frontendPortMatches = content.match(/localhost:5\d{3}/g) || [];
    frontendPortMatches.forEach(match => {
      if (!match.includes(EXPECTED_PORT.frontend)) {
        warnings.push(`⚠️  ${filename}: 发现可能错误的前端端口 "${match}" (应为 ${EXPECTED_PORT.frontend})`);
      }
    });

    // 检查 Result 格式说明
    if (content.includes('Result<T>') || content.includes('Result<T')) {
      if (!content.includes('code') || !content.includes('message') || !content.includes('data')) {
        warnings.push(`⚠️  ${filename}: 提到 Result<T> 但未完整说明字段`);
      }
    }

    checkedFiles.push(filename);

  } catch (error) {
    // 忽略无法读取的文件
  }
}

// 递归检查 docs 目录
function checkDocsDir(dir) {
  const files = fs.readdirSync(dir);

  files.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);

    if (stat.isDirectory()) {
      checkDocsDir(filePath);
    } else if (file.endsWith('.md')) {
      checkFile(filePath, `docs/${file}`);
    }
  });
}

// 检查主目录的 README.md
checkFile(path.join(__dirname, '../README.md'), 'README.md');

// 检查 docs 目录
checkDocsDir(DOCS_DIR);

// 输出结果
console.log('📁 已检查文件:');
checkedFiles.forEach((file, index) => {
  console.log(`   ${index + 1}. ${file}`);
});

console.log(`\n📊 检查统计:`);
console.log(`   已检查文件: ${checkedFiles.length} 个`);
console.log(`   错误: ${errors.length} 个`);
console.log(`   警告: ${warnings.length} 个\n`);

if (errors.length > 0) {
  console.log('❌ 发现错误:\n');
  errors.forEach(error => console.log(`   ${error}`));
  console.log();
}

if (warnings.length > 0) {
  console.log('⚠️  发现警告:\n');
  warnings.forEach(warning => console.log(`   ${warning}`));
  console.log();
}

if (errors.length === 0 && warnings.length === 0) {
  console.log('✅ 所有文档端口配置一致\n');
  console.log('📋 配置信息:');
  console.log(`   后端端口: ${EXPECTED_PORT.backend}`);
  console.log(`   前端端口: ${EXPECTED_PORT.frontend}\n`);
  process.exit(0);
} else if (errors.length > 0) {
  console.log('❌ 文档端口配置不一致，请修正\n');
  process.exit(1);
} else {
  console.log('⚠️  文档存在潜在问题，建议检查\n');
  process.exit(0);
}