#!/usr/bin/env node

/**
 * 测试脚本 - 验证后端 API 连接和规则导入功能
 */

const API_BASE = 'http://localhost:8001';

console.log('🔍 测试后端 API 连接...\n');

async function testAPI() {
  try {
    // 测试 API 连接
    const response = await fetch(`${API_BASE}/api/danger-function-rules`);

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const result = await response.json();

    // 处理 Result<T> 响应格式
    if (result.code !== 200) {
      throw new Error(`API Error ${result.code}: ${result.message}`);
    }

    const rules = result.data || [];

    console.log('✅ API 连接成功');
    console.log(`📊 当前规则数量: ${rules.length}\n`);

    if (rules.length > 0) {
      console.log('📋 现有规则列表（前5条）:');
      rules.slice(0, 5).forEach((rule, index) => {
        console.log(`   ${index + 1}. ${rule.ruleName} [${rule.functionType}] - ${rule.riskLevel}`);
      });

      console.log('\n💡 提示: 运行以下命令导入完整规则');
      console.log('   node scripts/import-rules.js --clear');
    } else {
      console.log('⚠️  数据库中没有规则');
      console.log('\n💡 提示: 运行以下命令导入规则');
      console.log('   node scripts/import-rules.js');
    }

    return true;

  } catch (error) {
    console.error('❌ API 连接失败:', error.message);
    console.error('\n💡 请确认:');
    console.error('   1. 后端服务已启动 (mvn spring-boot:run)');
    console.error('   2. API 地址正确 (http://localhost:8001)');
    return false;
  }
}

testAPI();