#!/usr/bin/env node

/**
 * 验证配置文件格式是否正确
 */

const fs = require('fs');
const path = require('path');

const RULES_FILE = path.join(__dirname, '../config/danger-function-rules.json');

console.log('🔍 验证规则配置文件格式...\n');

try {
  // 读取文件
  const content = fs.readFileSync(RULES_FILE, 'utf-8');
  const data = JSON.parse(content);

  console.log('✅ JSON 格式正确');
  console.log(`📊 规则总数: ${data.rules.length}\n`);

  // 验证必填字段
  const requiredFields = [
    'ruleName', 'functionType', 'classPattern', 'methodPattern',
    'description', 'riskLevel', 'securityImpact', 'remediation', 'enabled'
  ];

  let errors = 0;
  const functionTypes = new Set();
  const riskLevels = new Set();

  data.rules.forEach((rule, index) => {
    const missing = requiredFields.filter(field => rule[field] === undefined || rule[field] === null);

    if (missing.length > 0) {
      console.error(`❌ 规则 ${index + 1} [${rule.ruleName || '未命名'}]: 缺少字段 ${missing.join(', ')}`);
      errors++;
    }

    if (rule.functionType) functionTypes.add(rule.functionType);
    if (rule.riskLevel) riskLevels.add(rule.riskLevel);
  });

  if (errors > 0) {
    console.log(`\n❌ 发现 ${errors} 个错误`);
    process.exit(1);
  }

  console.log('✅ 所有规则字段完整\n');

  console.log('📈 统计信息:');
  console.log(`   函数类型: ${functionTypes.size} 种`);
  console.log(`   风险等级: ${riskLevels.size} 种\n`);

  console.log('📋 函数类型分布:');
  const typeCount = {};
  data.rules.forEach(rule => {
    typeCount[rule.functionType] = (typeCount[rule.functionType] || 0) + 1;
  });

  Object.entries(typeCount)
    .sort((a, b) => b[1] - a[1])
    .forEach(([type, count]) => {
      console.log(`   ${type}: ${count} 条`);
    });

  console.log('\n📊 风险等级分布:');
  const levelCount = {};
  data.rules.forEach(rule => {
    levelCount[rule.riskLevel] = (levelCount[rule.riskLevel] || 0) + 1;
  });

  ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].forEach(level => {
    if (levelCount[level]) {
      console.log(`   ${level}: ${levelCount[level]} 条`);
    }
  });

  console.log('\n✅ 配置文件验证通过');
  console.log('\n💡 下一步:');
  console.log('   1. 启动后端服务: mvn spring-boot:run');
  console.log('   2. 测试 API 连接: node scripts/test-api.js');
  console.log('   3. 导入规则: node scripts/import-rules.js --clear');

  process.exit(0);

} catch (error) {
  console.error('❌ 验证失败:', error.message);
  process.exit(1);
}