<template>
  <div class="change-impact-graph">
    <div v-if="loading" class="loading-container">
      <el-progress type="circle" :percentage="100" :indeterminate="true" />
      <p>加载变更影响图谱...</p>
    </div>

    <div v-else-if="graphData" class="graph-container" ref="graphContainer"></div>

    <el-empty v-else description="暂无变更影响数据" />
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, watch } from 'vue'
import { Graph } from '@antv/g6'
import diffAnalysisApi from '@/api/diffAnalysis'

const props = defineProps({
  diffTaskId: {
    type: [Number, String],
    required: true
  },
  focusChangeId: {
    type: String,
    default: null
  },
  filters: {
    type: Object,
    default: () => ({
      riskLevels: ['HIGH', 'MEDIUM', 'LOW'],
      changeTypes: ['ADDED', 'MODIFIED', 'DELETED']
    })
  }
})

const emit = defineEmits(['node-click'])

const graphContainer = ref(null)
const graph = ref(null)
const graphData = ref(null)
const loading = ref(true)

const loadImpactGraph = async () => {
  loading.value = true
  try {
    const response = await diffAnalysisApi.getImpactGraph(props.diffTaskId, props.filters)
    graphData.value = response
    if (response) {
      renderGraph(response)
    }
  } catch (e) {
    console.error('Failed to load impact graph:', e)
  } finally {
    loading.value = false
  }
}

const renderGraph = (data) => {
  if (!graphContainer.value) return

  const width = graphContainer.value.offsetWidth
  const height = graphContainer.value.offsetHeight || 600

  // 构建节点和边
  const nodes = buildNodes(data)
  const edges = buildEdges(data)

  // 创建图谱实例
  graph.value = new Graph({
    container: graphContainer.value,
    width,
    height,
    autoFit: 'view',
    padding: 20,
    behaviors: ['drag-canvas', 'zoom-canvas', 'drag-element'],
    layout: {
      type: 'dagre',
      rankdir: 'LR', // 从左到右
      nodesep: 80,
      ranksep: 120
    },
    node: {
      style: {
        size: (d) => {
          const label = d.data?.label || ''
          const lines = label.split('\n').length
          return [Math.max(150, label.length * 8), Math.max(40, lines * 20)]
        },
        fill: (d) => {
          const type = d.data?.nodeType
          if (type === 'change') return '#FFCDD2' // 红色 - 变更点
          if (type === 'api') return '#BBDEFB' // 蓝色 - API
          const risk = d.data?.riskLevel
          if (risk === 'HIGH') return '#FFCCBC' // 橙色
          if (risk === 'MEDIUM') return '#FFE0B2' // 黄色
          return '#E8F5E9' // 绿色
        },
        stroke: (d) => {
          const risk = d.data?.riskLevel
          if (risk === 'HIGH') return '#E53935'
          if (risk === 'MEDIUM') return '#FB8C00'
          return '#43A047'
        },
        lineWidth: 2,
        labelText: (d) => d.data?.label || '',
        labelFontSize: 12,
        labelFill: '#424242'
      }
    },
    edge: {
      style: {
        stroke: (d) => d.data?.edgeType === 'impact' ? '#FF9800' : '#5B8FF9',
        lineWidth: 2,
        lineDash: (d) => d.data?.edgeType === 'impact' ? [5, 5] : [],
        endArrow: true
      }
    }
  })

  // 设置数据
  graph.value.setData({ nodes, edges })

  // 绑定事件
  graph.value.on('node:click', (event) => {
    const node = event.target
    emit('node-click', node.data)
  })

  // 渲染
  graph.value.render()
}

const buildNodes = (data) => {
  const nodes = []
  const nodeMap = new Map()

  // 添加变更节点
  if (data.changes) {
    data.changes.forEach(change => {
      const nodeId = `change-${change.id}`
      if (!nodeMap.has(nodeId)) {
        nodes.push({
          id: nodeId,
          data: {
            nodeType: 'change',
            label: `${change.className.split('.').pop()}\n${change.methodName}()`,
            ...change
          }
        })
        nodeMap.set(nodeId, true)
      }
    })
  }

  // 添加受影响节点
  if (data.affected) {
    data.affected.forEach(affected => {
      const nodeId = `affected-${affected.id}`
      if (!nodeMap.has(nodeId)) {
        nodes.push({
          id: nodeId,
          data: {
            nodeType: 'affected',
            label: `${affected.className.split('.').pop()}\n${affected.methodName}()`,
            ...affected
          }
        })
        nodeMap.set(nodeId, true)
      }
    })
  }

  // 添加API节点
  if (data.apis) {
    data.apis.forEach(api => {
      const nodeId = `api-${api.id}`
      if (!nodeMap.has(nodeId)) {
        nodes.push({
          id: nodeId,
          data: {
            nodeType: 'api',
            label: `${api.controllerClass.split('.').pop()}\n${api.httpMethod} ${api.apiUrl}`,
            ...api
          }
        })
        nodeMap.set(nodeId, true)
      }
    })
  }

  return nodes
}

const buildEdges = (data) => {
  const edges = []

  // 添加调用边
  if (data.callEdges) {
    data.callEdges.forEach(edge => {
      edges.push({
        id: `call-edge-${edge.id}`,
        source: `change-${edge.sourceId}`,
        target: `affected-${edge.targetId}`,
        data: {
          edgeType: 'call',
          callLine: edge.callLine
        }
      })
    })
  }

  // 添加影响边
  if (data.impactEdges) {
    data.impactEdges.forEach(edge => {
      edges.push({
        id: `impact-edge-${edge.id}`,
        source: `affected-${edge.sourceId}`,
        target: `api-${edge.targetId}`,
        data: {
          edgeType: 'impact'
        }
      })
    })
  }

  return edges
}

onMounted(() => {
  loadImpactGraph()
})

onBeforeUnmount(() => {
  if (graph.value) {
    graph.value.destroy()
  }
})

watch(() => props.filters, () => {
  loadImpactGraph()
}, { deep: true })
</script>

<style lang="scss" scoped>
.change-impact-graph {
  width: 100%;
  height: 600px;

  .loading-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
  }

  .graph-container {
    width: 100%;
    height: 100%;
  }
}
</style>