-- 为快速差异对比记录添加源代码差异字段
ALTER TABLE quick_diff_record ADD COLUMN source_diffs_json TEXT;
