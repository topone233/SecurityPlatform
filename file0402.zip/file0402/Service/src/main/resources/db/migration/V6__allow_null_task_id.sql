-- 允许 artifact 表的 task_id 为 NULL（支持差异分析场景）
-- 差异分析时，制品不需要关联到具体的任务

-- 删除外键约束
ALTER TABLE artifact DROP CONSTRAINT IF EXISTS fk_artifact_task;

-- 修改 task_id 为可为 NULL
ALTER TABLE artifact ALTER COLUMN task_id DROP NOT NULL;

-- 重新添加外键约束（允许 NULL）
ALTER TABLE artifact
    ADD CONSTRAINT fk_artifact_task
    FOREIGN KEY (task_id) REFERENCES task(id) ON DELETE CASCADE;

-- 添加注释说明
COMMENT ON COLUMN artifact.task_id IS '任务ID（差异分析时可为NULL）';
