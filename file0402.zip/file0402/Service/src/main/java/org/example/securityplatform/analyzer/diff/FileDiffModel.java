package org.example.securityplatform.analyzer.diff;

import lombok.Data;

import java.io.InputStream;

/**
 * 文件差异模型
 */
@Data
public class FileDiffModel {
    private String filePath;           // class文件路径
    private String sourceFilePath;     // 推断的源文件路径
    private String diffType;           // ADDED, MODIFIED, DELETED

    // 多JAR支持：记录类来源
    private String sourceJar;          // 来源JAR名称（主JAR或依赖JAR名称）
    private String jarType;            // MAIN 或 DEPENDENCY

    // 行数统计
    private int baselineLines;
    private int targetLines;
    private int addedLines;
    private int deletedLines;

    // 方法变更统计
    private int methodsAdded;
    private int methodsDeleted;
    private int methodsModified;

    // 字节码差异详情
    private BytecodeDiffResult bytecodeDiff;

    // 文件内容（用于MD5对比）
    private String baselineMd5;
    private String targetMd5;

    /**
     * 是否有变更
     */
    public boolean hasChanges() {
        return !"UNCHANGED".equals(diffType);
    }

    /**
     * 从class文件路径推断源文件路径
     * 例如: com/example/Foo.class -> com/example/Foo.java
     */
    public static String inferSourcePath(String classPath) {
        if (classPath == null) return null;
        // 移除 .class 后缀，添加 .java
        if (classPath.endsWith(".class")) {
            return classPath.substring(0, classPath.length() - 6) + ".java";
        }
        return classPath;
    }
}