package org.example.securityplatform.analyzer.core;

import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * 影响追溯器
 * 统一的链路追溯框架，支持DFS和BFS两种策略
 * <p>
 * 核心功能：
 * 1. 从指定方法出发，反向追溯调用链
 * 2. 支持接口-实现类映射（自动处理 XxxImpl → Xxx）
 * 3. 深度限制和循环检测
 * 4. 支持终止条件（如找到Controller方法即停止）
 *
 * @param <T> 调用边类型
 */
@Slf4j
public class ImpactTracer<T> {

    /** 反向调用图：被调用者键 → 调用边列表 */
    private final Map<String, List<T>> reverseCallGraph;

    /** 从调用边提取调用者键 */
    private final Function<T, String> callerKeyExtractor;

    /** 从调用边提取被调用者键 */
    private final Function<T, String> calleeKeyExtractor;

    /** 接口映射器 */
    private final InterfaceMapper interfaceMapper;

    /** 所有类名集合（用于接口推断） */
    private final Set<String> classNames;

    /** 分析配置 */
    private final AnalysisConfig config;

    /**
     * 追溯结果
     */
    public static class TraceResult {
        /** 到达的方法键 */
        private String methodKey;
        /** 调用链（从起始方法到到达方法） */
        private List<String> callChain;

        public TraceResult(String methodKey, List<String> callChain) {
            this.methodKey = methodKey;
            this.callChain = callChain;
        }

        public String getMethodKey() {
            return methodKey;
        }

        public List<String> getCallChain() {
            return callChain;
        }
    }

    /**
     * 构建器模式，方便创建ImpactTracer实例
     */
    public static class Builder<T> {
        private Map<String, List<T>> reverseCallGraph;
        private Function<T, String> callerKeyExtractor;
        private Function<T, String> calleeKeyExtractor;
        private InterfaceMapper interfaceMapper;
        private Set<String> classNames = new HashSet<>();
        private AnalysisConfig config = AnalysisConfig.defaultConfig();

        public Builder<T> reverseCallGraph(Map<String, List<T>> reverseCallGraph) {
            this.reverseCallGraph = reverseCallGraph;
            return this;
        }

        public Builder<T> callerKeyExtractor(Function<T, String> extractor) {
            this.callerKeyExtractor = extractor;
            return this;
        }

        public Builder<T> calleeKeyExtractor(Function<T, String> extractor) {
            this.calleeKeyExtractor = extractor;
            return this;
        }

        public Builder<T> interfaceMapper(InterfaceMapper mapper) {
            this.interfaceMapper = mapper;
            return this;
        }

        public Builder<T> classNames(Set<String> classNames) {
            this.classNames = classNames;
            return this;
        }

        public Builder<T> config(AnalysisConfig config) {
            this.config = config;
            return this;
        }

        public ImpactTracer<T> build() {
            if (reverseCallGraph == null) {
                throw new IllegalArgumentException("reverseCallGraph is required");
            }
            if (callerKeyExtractor == null || calleeKeyExtractor == null) {
                throw new IllegalArgumentException("callerKeyExtractor and calleeKeyExtractor are required");
            }
            if (interfaceMapper == null) {
                interfaceMapper = new InterfaceMapper();
            }
            return new ImpactTracer<>(this);
        }
    }

    private ImpactTracer(Builder<T> builder) {
        this.reverseCallGraph = builder.reverseCallGraph;
        this.callerKeyExtractor = builder.callerKeyExtractor;
        this.calleeKeyExtractor = builder.calleeKeyExtractor;
        this.interfaceMapper = builder.interfaceMapper;
        this.classNames = builder.classNames;
        this.config = builder.config;
    }

    // ========== DFS追溯 ==========

    /**
     * DFS追溯（递归，单路径，取第一个调用者）
     * 适用于：快速比对中的影响链路追溯
     *
     * @param startMethodKey 起始方法键
     * @return 调用链（从起始方法到最顶层调用者）
     */
    public List<String> traceDfsSinglePath(String startMethodKey) {
        List<String> chain = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        traceDfsRecursive(startMethodKey, visited, chain, 0);
        return chain;
    }

    /**
     * DFS追溯（递归，所有路径，直到满足终止条件或达到深度限制）
     * 适用于：API影响追溯
     *
     * @param startMethodKey 起始方法键
     * @param stopCondition  终止条件（如：找到Controller方法）
     * @return 所有追溯结果
     */
    public List<TraceResult> traceDfsAllPaths(String startMethodKey, Predicate<String> stopCondition) {
        List<TraceResult> results = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        List<String> currentChain = new ArrayList<>();

        traceDfsAllRecursive(startMethodKey, visited, currentChain, 0, stopCondition, results);

        return results;
    }

    // ========== BFS追溯 ==========

    /**
     * BFS追溯（广度优先，适合找最短路径）
     * 适用于：污点追踪（从Sink追溯到Controller）
     *
     * @param startMethodKey 起始方法键
     * @param stopCondition  终止条件（如：找到Controller方法）
     * @return 所有追溯结果（先到达的是最短路径）
     */
    public List<TraceResult> traceBfs(String startMethodKey, Predicate<String> stopCondition) {
        List<TraceResult> results = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        Queue<TraceState> queue = new LinkedList<>();

        queue.offer(new TraceState(startMethodKey, new ArrayList<>()));

        while (!queue.isEmpty()) {
            TraceState state = queue.poll();

            if (visited.contains(state.methodKey)) {
                continue;
            }
            visited.add(state.methodKey);

            // 深度限制
            if (state.callChain.size() >= config.getMaxTraceDepth()) {
                continue;
            }

            // 终止条件
            if (stopCondition.test(state.methodKey)) {
                List<String> chain = new ArrayList<>(state.callChain);
                chain.add(state.methodKey);
                results.add(new TraceResult(state.methodKey, chain));
                continue;
            }

            // 查找调用者
            List<T> callers = findCallers(state.methodKey);
            for (T caller : callers) {
                String callerKey = callerKeyExtractor.apply(caller);
                if (!visited.contains(callerKey)) {
                    List<String> newChain = new ArrayList<>(state.callChain);
                    newChain.add(state.methodKey);
                    queue.offer(new TraceState(callerKey, newChain));
                }
            }
        }

        return results;
    }

    // ========== 通用查询方法 ==========

    /**
     * 查找方法的直接调用者
     * 支持接口映射：如果找不到精确匹配，尝试通过接口推断
     *
     * @param methodKey 方法键（格式：类名#方法名）
     * @return 调用者列表
     */
    public List<T> findCallers(String methodKey) {
        // 1. 精确匹配
        List<T> callers = reverseCallGraph.get(methodKey);
        if (callers != null && !callers.isEmpty()) {
            return callers;
        }

        // 2. 通过接口映射查找
        if (!classNames.isEmpty()) {
            List<String> interfaceKeys = interfaceMapper.findInterfaceMethodKeys(methodKey, classNames);
            for (String interfaceKey : interfaceKeys) {
                callers = reverseCallGraph.get(interfaceKey);
                if (callers != null && !callers.isEmpty()) {
                    log.debug("接口映射找到调用者: {} -> {}", methodKey, interfaceKey);
                    return callers;
                }
            }
        }

        return Collections.emptyList();
    }

    /**
     * 检查方法是否在反向调用图中存在（包括接口映射）
     */
    public boolean hasCallers(String methodKey) {
        return !findCallers(methodKey).isEmpty();
    }

    /**
     * 获取反向调用图
     */
    public Map<String, List<T>> getReverseCallGraph() {
        return reverseCallGraph;
    }

    // ========== 内部方法 ==========

    private void traceDfsRecursive(String methodKey, Set<String> visited, List<String> chain, int depth) {
        if (depth >= config.getMaxTraceDepth()) {
            return;
        }

        if (visited.contains(methodKey)) {
            return;
        }

        visited.add(methodKey);
        chain.add(methodKey);

        List<T> callers = findCallers(methodKey);
        if (!callers.isEmpty()) {
            // 取第一个调用者继续追溯
            String nextCaller = callerKeyExtractor.apply(callers.get(0));
            traceDfsRecursive(nextCaller, visited, chain, depth + 1);
        }
    }

    private void traceDfsAllRecursive(String methodKey, Set<String> visited, List<String> currentChain,
                                       int depth, Predicate<String> stopCondition, List<TraceResult> results) {
        if (depth >= config.getMaxTraceDepth()) {
            return;
        }

        if (visited.contains(methodKey)) {
            return;
        }
        visited.add(methodKey);

        // 终止条件
        if (stopCondition.test(methodKey)) {
            List<String> chain = new ArrayList<>(currentChain);
            chain.add(methodKey);
            results.add(new TraceResult(methodKey, chain));
            return;
        }

        // 查找调用者
        List<T> callers = findCallers(methodKey);
        for (T caller : callers) {
            String callerKey = callerKeyExtractor.apply(caller);

            List<String> newChain = new ArrayList<>(currentChain);
            newChain.add(methodKey);
            traceDfsAllRecursive(callerKey, visited, newChain, depth + 1, stopCondition, results);
        }
    }

    /**
     * BFS追踪状态
     */
    private static class TraceState {
        final String methodKey;
        final List<String> callChain;

        TraceState(String methodKey, List<String> callChain) {
            this.methodKey = methodKey;
            this.callChain = callChain;
        }
    }
}
