package org.example.securityplatform.analyzer.diff;

import lombok.Data;

import java.util.List;

/**
 * 字节码差异结果
 */
@Data
public class BytecodeDiffResult {
    private String filePath;
    private boolean hasDiff;

    // 方法变更
    private List<MethodChangeModel> methodChanges;
    private int methodsAdded;
    private int methodsDeleted;
    private int methodsModified;

    // 指令统计
    private int baselineInstructions;
    private int targetInstructions;
    private int addedInstructions;
    private int deletedInstructions;

    // 变更行范围（字节码行号）
    private List<LineRange> changedLineRanges;

    @Data
    public static class LineRange {
        private int start;
        private int end;
    }

    /**
     * 是否有变更
     */
    public boolean hasChanges() {
        return methodsAdded > 0 || methodsDeleted > 0 || methodsModified > 0;
    }
}