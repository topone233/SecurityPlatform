package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.TestEnvironmentResponse;
import org.example.securityplatform.service.TestEnvironmentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 测试环境控制器
 */
@Tag(name = "测试环境", description = "测试环境的配置和管理")
@RestController
@RequestMapping("/api/test-environment")
@RequiredArgsConstructor
public class TestEnvironmentController {

    private final TestEnvironmentService environmentService;

    /**
     * 获取所有活跃的测试环境
     */
    @Operation(summary = "获取活跃环境", description = "获取所有启用的测试环境")
    @GetMapping("/active")
    public Result<List<TestEnvironmentResponse>> getActiveEnvironments() {
        List<TestEnvironmentResponse> responses = environmentService.getActiveEnvironments();
        return Result.success(responses);
    }

    /**
     * 获取所有测试环境
     */
    @Operation(summary = "获取所有环境", description = "获取所有测试环境列表")
    @GetMapping
    public Result<List<TestEnvironmentResponse>> getAllEnvironments() {
        List<TestEnvironmentResponse> responses = environmentService.getAllEnvironments();
        return Result.success(responses);
    }

    /**
     * 获取测试环境详情
     */
    @Operation(summary = "获取环境详情", description = "根据ID获取测试环境详情")
    @GetMapping("/{id}")
    public Result<TestEnvironmentResponse> getEnvironment(
            @Parameter(description = "环境ID") @PathVariable Long id) {
        TestEnvironmentResponse response = environmentService.getEnvironment(id);
        return Result.success(response);
    }

    /**
     * 按类型获取测试环境
     */
    @Operation(summary = "按类型获取环境", description = "获取指定类型的所有测试环境")
    @GetMapping("/type/{envType}")
    public Result<List<TestEnvironmentResponse>> getEnvironmentsByType(
            @Parameter(description = "环境类型: DEV, TEST, STAGING, PROD") @PathVariable String envType) {
        List<TestEnvironmentResponse> responses = environmentService.getEnvironmentsByType(envType);
        return Result.success(responses);
    }

    /**
     * 创建测试环境
     */
    @Operation(summary = "创建测试环境", description = "创建新的测试环境配置")
    @PostMapping
    public Result<TestEnvironmentResponse> createEnvironment(
            @Parameter(description = "环境名称") @RequestParam String envName,
            @Parameter(description = "环境类型: DEV, TEST, STAGING, PROD") @RequestParam String envType,
            @Parameter(description = "环境描述") @RequestParam(required = false) String description,
            @RequestBody(required = false) Map<String, Object> configData) {
        TestEnvironmentResponse response = environmentService.createEnvironment(envName, envType, description, configData);
        return Result.success(response);
    }

    /**
     * 更新测试环境
     */
    @Operation(summary = "更新测试环境", description = "更新测试环境配置")
    @PutMapping("/{id}")
    public Result<TestEnvironmentResponse> updateEnvironment(
            @Parameter(description = "环境ID") @PathVariable Long id,
            @Parameter(description = "环境名称") @RequestParam(required = false) String envName,
            @Parameter(description = "环境类型") @RequestParam(required = false) String envType,
            @Parameter(description = "环境描述") @RequestParam(required = false) String description,
            @RequestBody(required = false) Map<String, Object> configData) {
        TestEnvironmentResponse response = environmentService.updateEnvironment(id, envName, envType, description, configData);
        return Result.success(response);
    }

    /**
     * 启用测试环境
     */
    @Operation(summary = "启用测试环境", description = "启用指定的测试环境")
    @PutMapping("/{id}/enable")
    public Result<TestEnvironmentResponse> enableEnvironment(
            @Parameter(description = "环境ID") @PathVariable Long id) {
        TestEnvironmentResponse response = environmentService.toggleEnvironment(id, true);
        return Result.success(response);
    }

    /**
     * 禁用测试环境
     */
    @Operation(summary = "禁用测试环境", description = "禁用指定的测试环境")
    @PutMapping("/{id}/disable")
    public Result<TestEnvironmentResponse> disableEnvironment(
            @Parameter(description = "环境ID") @PathVariable Long id) {
        TestEnvironmentResponse response = environmentService.toggleEnvironment(id, false);
        return Result.success(response);
    }

    /**
     * 删除测试环境
     */
    @Operation(summary = "删除测试环境", description = "删除指定的测试环境")
    @DeleteMapping("/{id}")
    public Result<Void> deleteEnvironment(
            @Parameter(description = "环境ID") @PathVariable Long id) {
        environmentService.deleteEnvironment(id);
        return Result.success(null);
    }
}
