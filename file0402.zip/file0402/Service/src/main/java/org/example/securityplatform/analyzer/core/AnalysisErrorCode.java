package org.example.securityplatform.analyzer.core;

/**
 * 分析错误码枚举
 */
public enum AnalysisErrorCode {

    /** JAR文件不存在 */
    JAR_FILE_NOT_FOUND,

    /** JAR解析错误 */
    JAR_PARSE_ERROR,

    /** 调用图构建错误 */
    CALL_GRAPH_BUILD_ERROR,

    /** 接口映射错误 */
    INTERFACE_MAPPING_ERROR,

    /** 追溯深度超限 */
    TRACE_DEPTH_EXCEEDED,

    /** 字节码分析错误 */
    BYTECODE_ANALYSIS_ERROR,

    /** API提取错误 */
    API_EXTRACT_ERROR,

    /** 配置解析错误 */
    CONFIG_PARSE_ERROR
}
