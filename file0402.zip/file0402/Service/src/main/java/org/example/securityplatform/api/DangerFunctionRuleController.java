package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.DangerFunctionRuleRequest;
import org.example.securityplatform.dto.DangerFunctionRuleResponse;
import org.example.securityplatform.service.DangerFunctionRuleService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 危险函数规则管理控制器
 */
@Tag(name = "危险函数规则管理", description = "危险函数扫描规则的CRUD操作")
@RestController
@RequestMapping("/api/danger-function-rules")
@RequiredArgsConstructor
public class DangerFunctionRuleController {

    private final DangerFunctionRuleService ruleService;

    /**
     * 获取所有规则
     */
    @Operation(summary = "获取所有规则", description = "获取所有危险函数规则列表")
    @GetMapping
    public Result<List<DangerFunctionRuleResponse>> getAllRules() {
        List<DangerFunctionRuleResponse> rules = ruleService.getAllRules();
        return Result.success(rules);
    }

    /**
     * 获取所有启用的规则
     */
    @Operation(summary = "获取启用的规则", description = "获取所有启用状态的规则")
    @GetMapping("/enabled")
    public Result<List<DangerFunctionRuleResponse>> getAllEnabledRules() {
        List<DangerFunctionRuleResponse> rules = ruleService.getAllEnabledRules();
        return Result.success(rules);
    }

    /**
     * 获取规则详情
     */
    @Operation(summary = "获取规则详情", description = "根据ID获取规则详情")
    @GetMapping("/{id}")
    public Result<DangerFunctionRuleResponse> getRule(
            @Parameter(description = "规则ID") @PathVariable Long id) {
        DangerFunctionRuleResponse rule = ruleService.getRuleById(id);
        return Result.success(rule);
    }

    /**
     * 按类型获取规则
     */
    @Operation(summary = "按类型获取规则", description = "获取指定类型的所有规则")
    @GetMapping("/by-type/{functionType}")
    public Result<List<DangerFunctionRuleResponse>> getRulesByType(
            @Parameter(description = "函数类型") @PathVariable String functionType) {
        List<DangerFunctionRuleResponse> rules = ruleService.getRulesByFunctionType(functionType);
        return Result.success(rules);
    }

    /**
     * 创建规则
     */
    @Operation(summary = "创建规则", description = "创建新的危险函数规则")
    @PostMapping
    public Result<DangerFunctionRuleResponse> createRule(@RequestBody DangerFunctionRuleRequest request) {
        DangerFunctionRuleResponse rule = ruleService.createRule(request);
        return Result.success(rule);
    }

    /**
     * 更新规则
     */
    @Operation(summary = "更新规则", description = "更新指定的危险函数规则")
    @PutMapping("/{id}")
    public Result<DangerFunctionRuleResponse> updateRule(
            @Parameter(description = "规则ID") @PathVariable Long id,
            @RequestBody DangerFunctionRuleRequest request) {
        DangerFunctionRuleResponse rule = ruleService.updateRule(id, request);
        return Result.success(rule);
    }

    /**
     * 删除规则
     */
    @Operation(summary = "删除规则", description = "删除指定的危险函数规则")
    @DeleteMapping("/{id}")
    public Result<Void> deleteRule(
            @Parameter(description = "规则ID") @PathVariable Long id) {
        ruleService.deleteRule(id);
        return Result.success(null);
    }

    /**
     * 启用/禁用规则
     */
    @Operation(summary = "启用/禁用规则", description = "切换规则的启用状态")
    @PutMapping("/{id}/toggle")
    public Result<DangerFunctionRuleResponse> toggleRule(
            @Parameter(description = "规则ID") @PathVariable Long id,
            @Parameter(description = "是否启用") @RequestParam boolean enabled) {
        DangerFunctionRuleResponse rule = ruleService.toggleRule(id, enabled);
        return Result.success(rule);
    }

    /**
     * 获取所有函数类型
     */
    @Operation(summary = "获取所有函数类型", description = "获取所有危险函数类型列表")
    @GetMapping("/function-types")
    public Result<List<String>> getAllFunctionTypes() {
        List<String> types = ruleService.getAllFunctionTypes();
        return Result.success(types);
    }
}
