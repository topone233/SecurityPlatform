package org.example.securityplatform.service;

import lombok.extern.slf4j.Slf4j;
import org.benf.cfr.reader.api.CfrDriver;
import org.benf.cfr.reader.api.OutputSinkFactory;
import org.example.securityplatform.analyzer.diff.FileDiffModel;
import org.example.securityplatform.analyzer.jar.JarInfo;
import org.example.securityplatform.dto.FileSourceDiff;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 源代码差异服务 - 使用CFR反编译器将.class文件转为Java源码
 */
@Slf4j
@Service
public class SourceDiffService {

    /**
     * 反编译变更的class文件
     */
    public List<FileSourceDiff> decompileChangedFiles(
            List<FileDiffModel> fileDiffs,
            String baselinePath,
            String targetPath,
            List<JarInfo> baselineJars,
            List<JarInfo> targetJars) {

        log.info("开始源码反编译，共 {} 个变更文件", fileDiffs.size());
        long startTime = System.currentTimeMillis();

        List<FileSourceDiff> sourceDiffs = new ArrayList<>();
        int successCount = 0;
        int failCount = 0;
        int total = fileDiffs.size();

        for (int i = 0; i < fileDiffs.size(); i++) {
            FileDiffModel diff = fileDiffs.get(i);

            // 进度日志（每10%输出一次）
            if (total > 10 && (i % (total / 10) == 0)) {
                log.info("反编译进度: {}/{} ({} 个成功, {} 个失败)",
                        i, total, successCount, failCount);
            }

            try {
                String baselineSource = null;
                String targetSource = null;

                boolean isMultiJar = baselineJars != null && !baselineJars.isEmpty();

                switch (diff.getDiffType()) {
                    case "ADDED":
                        targetSource = decompileForSide(diff.getFilePath(), targetPath, targetJars, isMultiJar);
                        break;
                    case "DELETED":
                        baselineSource = decompileForSide(diff.getFilePath(), baselinePath, baselineJars, isMultiJar);
                        break;
                    case "MODIFIED":
                        baselineSource = decompileForSide(diff.getFilePath(), baselinePath, baselineJars, isMultiJar);
                        targetSource = decompileForSide(diff.getFilePath(), targetPath, targetJars, isMultiJar);
                        break;
                    default:
                        continue;
                }

                boolean hasResult = baselineSource != null || targetSource != null;
                String error = null;
                String actualDiffType = diff.getDiffType();
                String originalDiffType = diff.getDiffType();  // 保存原始差异类型
                boolean bytecodeDiffButSourceSame = false;     // 标记字节码差异但源码相同

                // Re-evaluate diffType based on decompiled source
                if ("MODIFIED".equals(diff.getDiffType()) && baselineSource != null && targetSource != null) {
                    if (baselineSource.equals(targetSource)) {
                        actualDiffType = "UNCHANGED";
                        bytecodeDiffButSourceSame = true;  // 标记为字节码差异但源码相同
                        log.debug("字节码差异但反编译后源码相同: {}", diff.getFilePath());
                    }
                }

                if (!hasResult && "MODIFIED".equals(diff.getDiffType())) {
                    error = "反编译未返回任何源码";
                }

                if (hasResult) {
                    successCount++;
                } else {
                    failCount++;
                }

                sourceDiffs.add(FileSourceDiff.builder()
                        .filePath(diff.getFilePath())
                        .sourceFilePath(diff.getSourceFilePath())
                        .diffType(actualDiffType)  // Use re-evaluated diffType
                        .originalDiffType(originalDiffType)  // 保存原始差异类型
                        .bytecodeDiffButSourceSame(bytecodeDiffButSourceSame)  // 标记字节码差异但源码相同
                        .baselineSource(baselineSource)
                        .targetSource(targetSource)
                        .error(error)
                        .sourceJar(diff.getSourceJar())
                        .jarType(diff.getJarType())
                        .build());

            } catch (Exception e) {
                log.warn("反编译处理失败: {} - {}", diff.getFilePath(), e.getMessage());
                sourceDiffs.add(FileSourceDiff.builder()
                        .filePath(diff.getFilePath())
                        .sourceFilePath(diff.getSourceFilePath())
                        .diffType(diff.getDiffType())
                        .error("反编译失败: " + e.getMessage())
                        .sourceJar(diff.getSourceJar())
                        .jarType(diff.getJarType())
                        .build());
                failCount++;
            }
        }

        long elapsed = System.currentTimeMillis() - startTime;
        log.info("源码反编译完成: 成功={}, 失败={}, 共={}, 耗时={}ms, 平均={}ms/文件",
                successCount, failCount, fileDiffs.size(), elapsed,
                fileDiffs.size() > 0 ? elapsed / fileDiffs.size() : 0);

        return sourceDiffs;
    }

    /**
     * 反编译指定端的class文件
     */
    private String decompileForSide(String classPath, String mainJarPath,
                                     List<JarInfo> jarInfos, boolean isMultiJar) {
        if (isMultiJar) {
            return decompileFromJars(classPath, jarInfos);
        } else {
            return decompileClassFromJar(mainJarPath, classPath);
        }
    }

    /**
     * 从多个JAR中查找并反编译
     */
    private String decompileFromJars(String classPath, List<JarInfo> jarInfos) {
        for (JarInfo jarInfo : jarInfos) {
            String result = decompileClassFromJar(jarInfo.getJarPath(), classPath);
            if (result != null) {
                return result;
            }
        }
        log.warn("在所有JAR中均未找到: {}", classPath);
        return null;
    }

    /**
     * 从JAR中提取class字节并反编译
     * 先提取字节到临时文件，再用CFR反编译，避免JAR路径格式问题
     */
    private String decompileClassFromJar(String jarPath, String classPath) {
        // 1. 在JAR中找到正确的条目名
        String entryName = resolveEntryName(jarPath, classPath);
        if (entryName == null) {
            return null;
        }

        // 2. 从JAR中提取class字节到临时文件
        Path tempFile = null;
        try {
            byte[] classBytes = extractClassBytes(jarPath, entryName);
            if (classBytes == null) {
                log.warn("无法提取class字节: {} from {}", entryName, jarPath);
                return null;
            }

            tempFile = Files.createTempFile("cfr-", ".class");
            Files.write(tempFile, classBytes);

            // 3. 用CFR反编译临时文件
            String source = decompileFile(tempFile.toString());
            return source;

        } catch (Exception e) {
            log.warn("反编译失败: {} in {} - {}", classPath, jarPath, e.getMessage());
            return null;
        } finally {
            if (tempFile != null) {
                try {
                    Files.deleteIfExists(tempFile);
                } catch (Exception ignored) {}
            }
        }
    }

    /**
     * 从JAR中提取class文件的字节
     */
    private byte[] extractClassBytes(String jarPath, String entryName) {
        try (JarFile jar = new JarFile(jarPath)) {
            JarEntry entry = jar.getJarEntry(entryName);
            if (entry == null) {
                return null;
            }
            try (InputStream is = jar.getInputStream(entry)) {
                return is.readAllBytes();
            }
        } catch (IOException e) {
            log.warn("读取JAR条目失败: {} in {} - {}", entryName, jarPath, e.getMessage());
            return null;
        }
    }

    /**
     * 用CFR反编译一个class文件
     */
    private String decompileFile(String classFilePath) {
        StringBuilder output = new StringBuilder();

        OutputSinkFactory sinkFactory = new OutputSinkFactory() {
            @Override
            public List<SinkClass> getSupportedSinks(SinkType sinkType, Collection<SinkClass> available) {
                return Collections.singletonList(SinkClass.STRING);
            }

            @Override
            public <T> Sink<T> getSink(SinkType sinkType, SinkClass sinkClass) {
                if (sinkType == SinkType.JAVA) {
                    return t -> output.append(t);
                }
                return t -> {};
            }
        };

        Map<String, String> options = new HashMap<>();
        options.put("showversion", "false");
        options.put("removeboilerplate", "true");
        options.put("decodestringswitch", "true");
        options.put("sugarenums", "true");
        options.put("decodelambdas", "true");
        options.put("aexagg", "false");

        CfrDriver driver = new CfrDriver.Builder()
                .withOutputSink(sinkFactory)
                .withOptions(options)
                .build();

        driver.analyse(Collections.singletonList(classFilePath));

        String source = output.toString().trim();
        if (source.isEmpty()) {
            return null;
        }
        return source;
    }

    /**
     * 在JAR中解析class条目的实际路径
     * 支持原始路径和规范化路径（BOOT-INF/classes前缀）
     */
    private String resolveEntryName(String jarPath, String classPath) {
        try (JarFile jar = new JarFile(jarPath)) {
            // 1. 尝试原始路径
            if (jar.getEntry(classPath) != null) {
                return classPath;
            }

            // 2. 尝试添加 BOOT-INF/classes 前缀
            String bootPath = "BOOT-INF/classes/" + classPath;
            if (jar.getEntry(bootPath) != null) {
                return bootPath;
            }

            // 3. 尝试添加 WEB-INF/classes 前缀
            String webPath = "WEB-INF/classes/" + classPath;
            if (jar.getEntry(webPath) != null) {
                return webPath;
            }

            // 4. 如果原始路径已有 BOOT-INF/classes 前缀，尝试去掉
            if (classPath.startsWith("BOOT-INF/classes/")) {
                String stripped = classPath.substring("BOOT-INF/classes/".length());
                if (jar.getEntry(stripped) != null) {
                    return stripped;
                }
            }

            // 5. 如果原始路径已有 WEB-INF/classes 前缀，尝试去掉
            if (classPath.startsWith("WEB-INF/classes/")) {
                String stripped = classPath.substring("WEB-INF/classes/".length());
                if (jar.getEntry(stripped) != null) {
                    return stripped;
                }
            }

            // 6. 模糊搜索：按文件名后缀匹配
            String suffix = classPath.contains("/")
                    ? classPath.substring(classPath.lastIndexOf('/'))
                    : classPath;
            Enumeration<JarEntry> entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (entry.getName().endsWith(suffix) && !entry.isDirectory()) {
                    return entry.getName();
                }
            }

            log.debug("在JAR中未找到条目: {} (tried raw, BOOT-INF, WEB-INF, fuzzy)", classPath);
            return null;

        } catch (IOException e) {
            log.warn("解析JAR条目失败: {} in {} - {}", classPath, jarPath, e.getMessage());
            return null;
        }
    }
}
