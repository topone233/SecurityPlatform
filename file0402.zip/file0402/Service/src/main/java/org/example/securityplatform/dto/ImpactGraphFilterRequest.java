package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 影响图谱过滤条件DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ImpactGraphFilterRequest {
    private List<String> riskLevels; // ["HIGH", "MEDIUM", "LOW"]
    private List<String> changeTypes; // ["ADDED", "MODIFIED", "DELETED"]
}