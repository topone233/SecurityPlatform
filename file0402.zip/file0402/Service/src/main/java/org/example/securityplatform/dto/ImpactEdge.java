package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 影响边DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ImpactEdge {
    private Long id;
    private Long sourceId; // 影响源ID
    private Long targetId; // 受影响目标ID
}