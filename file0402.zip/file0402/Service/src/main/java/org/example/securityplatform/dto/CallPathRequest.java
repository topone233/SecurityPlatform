package org.example.securityplatform.dto;

import lombok.Data;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * 调用路径查询请求
 */
@Data
public class CallPathRequest {

    /**
     * 制品ID
     */
    @NotNull(message = "制品ID不能为空")
    private Long artifactId;

    /**
     * 起点类名（完整类名）
     */
    @NotBlank(message = "起点类名不能为空")
    private String startClass;

    /**
     * 起点方法名
     */
    @NotBlank(message = "起点方法名不能为空")
    private String startMethod;

    /**
     * 终点类名（完整类名）
     */
    @NotBlank(message = "终点类名不能为空")
    private String endClass;

    /**
     * 终点方法名
     */
    @NotBlank(message = "终点方法名不能为空")
    private String endMethod;

    /**
     * 是否查找所有路径
     */
    private Boolean findAllPaths = false;

    /**
     * 最大路径数量（findAllPaths=true时有效）
     */
    private Integer maxPaths = 10;

    /**
     * 最大搜索深度
     */
    private Integer maxDepth = 20;
}