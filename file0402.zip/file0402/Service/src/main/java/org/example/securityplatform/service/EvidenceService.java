package org.example.securityplatform.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.config.FileUploadConfig;
import org.example.securityplatform.dto.EvidenceFileResponse;
import org.example.securityplatform.entity.TestExecution;
import org.example.securityplatform.repository.TestExecutionRepository;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 证据文件服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EvidenceService {

    private final FileUploadConfig fileUploadConfig;
    private final TestExecutionRepository executionRepository;
    private final ObjectMapper objectMapper;

    /**
     * 上传单个证据文件
     */
    @Transactional
    public EvidenceFileResponse uploadEvidence(Long executionId, MultipartFile file) {
        TestExecution execution = executionRepository.findById(executionId)
                .orElseThrow(() -> new RuntimeException("执行记录不存在: " + executionId));

        // 生成文件存储路径
        String datePath = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
        String fileName = generateFileName(file.getOriginalFilename());
        Path filePath = Paths.get(fileUploadConfig.getUploadDir(), "evidence",
                String.valueOf(executionId), datePath, fileName);

        // 创建目录
        try {
            Files.createDirectories(filePath.getParent());
        } catch (IOException e) {
            throw new RuntimeException("创建目录失败: " + e.getMessage());
        }

        // 保存文件
        try {
            file.transferTo(filePath.toFile());
        } catch (IOException e) {
            throw new RuntimeException("文件保存失败: " + e.getMessage());
        }

        // 构建响应
        Long fileId = System.currentTimeMillis();
        EvidenceFileResponse response = EvidenceFileResponse.builder()
                .id(fileId)
                .executionId(executionId)
                .fileName(file.getOriginalFilename())
                .filePath(filePath.toString())
                .fileUrl("/api/evidence/download/" + fileId)
                .fileSize(file.getSize())
                .contentType(file.getContentType())
                .uploadedAt(LocalDateTime.now())
                .build();

        // 更新执行记录的evidenceFiles字段
        updateEvidenceFilesJson(execution, response);

        return response;
    }

    /**
     * 批量上传证据文件
     */
    @Transactional
    public List<EvidenceFileResponse> uploadEvidenceBatch(Long executionId, List<MultipartFile> files) {
        List<EvidenceFileResponse> responses = new ArrayList<>();
        for (MultipartFile file : files) {
            responses.add(uploadEvidence(executionId, file));
        }
        return responses;
    }

    /**
     * 下载证据文件
     */
    public Resource downloadEvidence(Long fileId) {
        // 简化实现：从所有执行记录中查找包含该fileId的证据文件
        // 实际生产环境建议使用专门的文件索引表
        List<TestExecution> executions = executionRepository.findAll();
        for (TestExecution execution : executions) {
            if (execution.getEvidenceFiles() != null && !execution.getEvidenceFiles().isEmpty()) {
                try {
                    List<EvidenceFileResponse> files = objectMapper.readValue(
                            execution.getEvidenceFiles(),
                            new TypeReference<List<EvidenceFileResponse>>() {}
                    );
                    for (EvidenceFileResponse file : files) {
                        if (file.getId().equals(fileId)) {
                            Path filePath = Paths.get(file.getFilePath());
                            Resource resource = new UrlResource(filePath.toUri());
                            if (resource.exists() && resource.isReadable()) {
                                return resource;
                            }
                        }
                    }
                } catch (IOException e) {
                    log.error("解析证据文件JSON失败", e);
                }
            }
        }
        throw new RuntimeException("文件不存在: " + fileId);
    }

    /**
     * 删除证据文件
     */
    @Transactional
    public void deleteEvidence(Long fileId) {
        // 从所有执行记录中查找并删除该文件
        List<TestExecution> executions = executionRepository.findAll();
        for (TestExecution execution : executions) {
            if (execution.getEvidenceFiles() != null && !execution.getEvidenceFiles().isEmpty()) {
                try {
                    List<EvidenceFileResponse> files = objectMapper.readValue(
                            execution.getEvidenceFiles(),
                            new TypeReference<List<EvidenceFileResponse>>() {}
                    );
                    for (int i = 0; i < files.size(); i++) {
                        if (files.get(i).getId().equals(fileId)) {
                            // 删除物理文件
                            Path filePath = Paths.get(files.get(i).getFilePath());
                            try {
                                Files.deleteIfExists(filePath);
                            } catch (IOException e) {
                                log.error("文件删除失败: {}", filePath, e);
                            }
                            // 从列表中移除
                            files.remove(i);
                            // 更新JSON
                            execution.setEvidenceFiles(objectMapper.writeValueAsString(files));
                            executionRepository.save(execution);
                            return;
                        }
                    }
                } catch (IOException e) {
                    log.error("处理证据文件失败", e);
                }
            }
        }
    }

    /**
     * 根据执行ID删除所有证据文件
     */
    @Transactional
    public void deleteEvidenceByExecution(Long executionId) {
        TestExecution execution = executionRepository.findById(executionId).orElse(null);
        if (execution != null && execution.getEvidenceFiles() != null) {
            try {
                List<EvidenceFileResponse> files = objectMapper.readValue(
                        execution.getEvidenceFiles(),
                        new TypeReference<List<EvidenceFileResponse>>() {}
                );
                // 删除所有物理文件
                for (EvidenceFileResponse file : files) {
                    try {
                        Files.deleteIfExists(Paths.get(file.getFilePath()));
                    } catch (IOException e) {
                        log.error("文件删除失败: {}", file.getFilePath(), e);
                    }
                }
            } catch (IOException e) {
                log.error("解析证据文件JSON失败", e);
            }
        }
    }

    /**
     * 获取执行的所有证据文件
     */
    public List<EvidenceFileResponse> getEvidenceList(Long executionId) {
        TestExecution execution = executionRepository.findById(executionId)
                .orElseThrow(() -> new RuntimeException("执行记录不存在: " + executionId));

        if (execution.getEvidenceFiles() != null && !execution.getEvidenceFiles().isEmpty()) {
            try {
                return objectMapper.readValue(
                        execution.getEvidenceFiles(),
                        new TypeReference<List<EvidenceFileResponse>>() {}
                );
            } catch (IOException e) {
                log.error("解析证据文件JSON失败", e);
            }
        }

        return new ArrayList<>();
    }

    /**
     * 获取文件名
     */
    public String getFileName(Long fileId) {
        // 从JSON中解析文件名
        List<TestExecution> executions = executionRepository.findAll();
        for (TestExecution execution : executions) {
            if (execution.getEvidenceFiles() != null && !execution.getEvidenceFiles().isEmpty()) {
                try {
                    List<EvidenceFileResponse> files = objectMapper.readValue(
                            execution.getEvidenceFiles(),
                            new TypeReference<List<EvidenceFileResponse>>() {}
                    );
                    for (EvidenceFileResponse file : files) {
                        if (file.getId().equals(fileId)) {
                            return file.getFileName();
                        }
                    }
                } catch (IOException e) {
                    log.error("解析证据文件JSON失败", e);
                }
            }
        }
        return "evidence_" + fileId;
    }

    /**
     * 生成唯一文件名
     */
    private String generateFileName(String originalFilename) {
        String extension = "";
        if (originalFilename != null && originalFilename.contains(".")) {
            extension = originalFilename.substring(originalFilename.lastIndexOf("."));
        }
        return UUID.randomUUID().toString() + extension;
    }

    /**
     * 更新执行记录的evidenceFiles JSON
     */
    private void updateEvidenceFilesJson(TestExecution execution, EvidenceFileResponse newFile) {
        List<EvidenceFileResponse> files = new ArrayList<>();

        // 解析现有JSON
        if (execution.getEvidenceFiles() != null && !execution.getEvidenceFiles().isEmpty()) {
            try {
                files = objectMapper.readValue(
                        execution.getEvidenceFiles(),
                        new TypeReference<List<EvidenceFileResponse>>() {}
                );
            } catch (IOException e) {
                log.error("解析现有证据文件JSON失败，将覆盖", e);
            }
        }

        // 添加新文件
        files.add(newFile);

        // 序列化回JSON
        try {
            execution.setEvidenceFiles(objectMapper.writeValueAsString(files));
            executionRepository.save(execution);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("序列化证据文件JSON失败: " + e.getMessage());
        }
    }
}