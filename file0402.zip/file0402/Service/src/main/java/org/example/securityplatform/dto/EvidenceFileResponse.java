package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 证据文件响应DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EvidenceFileResponse {
    private Long id;
    private Long executionId;
    private String fileName;
    private String filePath;
    private String fileUrl;
    private Long fileSize;
    private String contentType;
    private LocalDateTime uploadedAt;
}