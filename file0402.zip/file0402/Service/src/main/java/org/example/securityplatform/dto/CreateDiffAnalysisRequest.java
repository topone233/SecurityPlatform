package org.example.securityplatform.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 创建差异分析请求
 */
@Data
public class CreateDiffAnalysisRequest {
    @NotNull(message = "项目ID不能为空")
    private Long projectId;

    @NotNull(message = "基线制品ID不能为空")
    private Long baselineArtifactId;

    @NotNull(message = "目标制品ID不能为空")
    private Long targetArtifactId;

    private String createdBy;
}
