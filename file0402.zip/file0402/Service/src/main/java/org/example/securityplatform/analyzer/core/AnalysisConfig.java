package org.example.securityplatform.analyzer.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 分析配置类
 * 集中管理深度限制、框架包列表、Controller关键词等可配置参数
 */
public class AnalysisConfig {

    /** 追溯深度限制 */
    private int maxTraceDepth = 20;

    /** 框架包前缀列表 */
    private List<String> frameworkPackages = new ArrayList<>(Arrays.asList(
            "org/springframework/",
            "org/apache/",
            "com/fasterxml/",
            "java/",
            "javax/",
            "jakarta/",
            "org/slf4j/",
            "ch/qos/logback/",
            "org/eclipse/",
            "io/netty/",
            "com/google/",
            "org/projectlombok/",
            "com/fasterxml/"
    ));

    /** Controller识别关键词 */
    private List<String> controllerKeywords = new ArrayList<>(Arrays.asList(
            "Api",
            "Controller",
            "Resource"
    ));

    /** Service识别关键词 */
    private List<String> serviceKeywords = new ArrayList<>(Arrays.asList(
            "Service",
            "ServiceImpl"
    ));

    public int getMaxTraceDepth() {
        return maxTraceDepth;
    }

    public void setMaxTraceDepth(int maxTraceDepth) {
        this.maxTraceDepth = maxTraceDepth;
    }

    public List<String> getFrameworkPackages() {
        return frameworkPackages;
    }

    public void setFrameworkPackages(List<String> frameworkPackages) {
        this.frameworkPackages = frameworkPackages;
    }

    public List<String> getControllerKeywords() {
        return controllerKeywords;
    }

    public void setControllerKeywords(List<String> controllerKeywords) {
        this.controllerKeywords = controllerKeywords;
    }

    public List<String> getServiceKeywords() {
        return serviceKeywords;
    }

    public void setServiceKeywords(List<String> serviceKeywords) {
        this.serviceKeywords = serviceKeywords;
    }

    /**
     * 创建默认配置
     */
    public static AnalysisConfig defaultConfig() {
        return new AnalysisConfig();
    }
}
