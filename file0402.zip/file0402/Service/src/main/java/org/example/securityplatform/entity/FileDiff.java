package org.example.securityplatform.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

/**
 * 文件差异实体
 */
@Data
@Entity
@Table(name = "file_diff")
public class FileDiff {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "diff_task_id", nullable = false)
    private Long diffTaskId;

    @Column(name = "file_path", nullable = false, length = 500)
    private String filePath;

    @Column(name = "source_file_path", length = 500)
    private String sourceFilePath;

    @Column(name = "diff_type", nullable = false, length = 20)
    private String diffType; // ADDED, MODIFIED, DELETED

    @Column(name = "baseline_lines")
    private Integer baselineLines = 0;

    @Column(name = "target_lines")
    private Integer targetLines = 0;

    @Column(name = "added_lines")
    private Integer addedLines = 0;

    @Column(name = "deleted_lines")
    private Integer deletedLines = 0;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "changed_line_ranges", columnDefinition = "TEXT")
    private String changedLineRanges;

    @Column(name = "methods_added")
    private Integer methodsAdded = 0;

    @Column(name = "methods_deleted")
    private Integer methodsDeleted = 0;

    @Column(name = "methods_modified")
    private Integer methodsModified = 0;
}
