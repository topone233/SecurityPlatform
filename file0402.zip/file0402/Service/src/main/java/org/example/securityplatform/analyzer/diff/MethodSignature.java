package org.example.securityplatform.analyzer.diff;

import lombok.Data;
import org.objectweb.asm.Opcodes;

/**
 * 方法签名模型
 */
@Data
public class MethodSignature {
    private String className;
    private String methodName;
    private String descriptor;
    private int access;

    /**
     * 生成唯一标识
     */
    public String getKey() {
        return className + "#" + methodName;
    }

    /**
     * 是否为构造方法
     */
    public boolean isConstructor() {
        return "<init>".equals(methodName) || "<clinit>".equals(methodName);
    }

    /**
     * 是否为静态方法
     */
    public boolean isStatic() {
        return (access & Opcodes.ACC_STATIC) != 0;
    }

    /**
     * 是否为私有方法
     */
    public boolean isPrivate() {
        return (access & Opcodes.ACC_PRIVATE) != 0;
    }

    /**
     * 是否为public方法
     */
    public boolean isPublic() {
        return (access & Opcodes.ACC_PUBLIC) != 0;
    }

    /**
     * 获取简单类名（不含包名）
     */
    public String getSimpleClassName() {
        int lastDot = className.lastIndexOf('.');
        return lastDot >= 0 ? className.substring(lastDot + 1) : className;
    }
}
