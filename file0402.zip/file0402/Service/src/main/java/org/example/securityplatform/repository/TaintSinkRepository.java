package org.example.securityplatform.repository;

import org.example.securityplatform.entity.TaintSink;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 污点Sink数据访问接口
 */
@Repository
public interface TaintSinkRepository extends JpaRepository<TaintSink, Long> {

    List<TaintSink> findByArtifactId(Long artifactId);

    List<TaintSink> findByArtifactIdAndVulnerabilityType(Long artifactId, String vulnerabilityType);

    List<TaintSink> findByVulnerabilityType(String vulnerabilityType);

    List<TaintSink> findByRiskLevel(String riskLevel);

    List<TaintSink> findByArtifactIdAndRiskLevel(Long artifactId, String riskLevel);

    @Modifying(clearAutomatically = true)
    void deleteByArtifactId(Long artifactId);
}