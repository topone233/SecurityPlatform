package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.EvidenceFileResponse;
import org.example.securityplatform.service.EvidenceService;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 证据文件控制器
 */
@Tag(name = "证据文件", description = "测试执行证据文件的上传和下载")
@RestController
@RequestMapping("/api/evidence")
@RequiredArgsConstructor
public class EvidenceController {

    private final EvidenceService evidenceService;

    /**
     * 上传证据文件
     */
    @Operation(summary = "上传证据文件", description = "为测试执行上传证据文件")
    @PostMapping("/upload/{executionId}")
    public Result<EvidenceFileResponse> uploadEvidence(
            @Parameter(description = "执行记录ID") @PathVariable Long executionId,
            @RequestParam("file") MultipartFile file) {
        EvidenceFileResponse response = evidenceService.uploadEvidence(executionId, file);
        return Result.success(response);
    }

    /**
     * 批量上传证据文件
     */
    @Operation(summary = "批量上传", description = "批量上传证据文件")
    @PostMapping("/upload-batch/{executionId}")
    public Result<List<EvidenceFileResponse>> uploadEvidenceBatch(
            @Parameter(description = "执行记录ID") @PathVariable Long executionId,
            @RequestParam("files") List<MultipartFile> files) {
        List<EvidenceFileResponse> responses = evidenceService.uploadEvidenceBatch(executionId, files);
        return Result.success(responses);
    }

    /**
     * 下载证据文件
     */
    @Operation(summary = "下载证据文件", description = "下载指定的证据文件")
    @GetMapping("/download/{fileId}")
    public ResponseEntity<Resource> downloadEvidence(
            @Parameter(description = "文件ID") @PathVariable Long fileId) {
        Resource resource = evidenceService.downloadEvidence(fileId);
        String filename = evidenceService.getFileName(fileId);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .body(resource);
    }

    /**
     * 删除证据文件
     */
    @Operation(summary = "删除证据文件", description = "删除指定的证据文件")
    @DeleteMapping("/{fileId}")
    public Result<Void> deleteEvidence(
            @Parameter(description = "文件ID") @PathVariable Long fileId) {
        evidenceService.deleteEvidence(fileId);
        return Result.success(null);
    }

    /**
     * 获取执行的所有证据文件
     */
    @Operation(summary = "获取证据文件列表", description = "获取执行记录的所有证据文件")
    @GetMapping("/list/{executionId}")
    public Result<List<EvidenceFileResponse>> getEvidenceList(
            @Parameter(description = "执行记录ID") @PathVariable Long executionId) {
        List<EvidenceFileResponse> responses = evidenceService.getEvidenceList(executionId);
        return Result.success(responses);
    }
}