package org.example.securityplatform.repository;

import org.example.securityplatform.entity.DangerFunctionRule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 危险函数规则 Repository
 */
@Repository
public interface DangerFunctionRuleRepository extends JpaRepository<DangerFunctionRule, Long> {

    List<DangerFunctionRule> findByEnabledTrue();

    List<DangerFunctionRule> findByFunctionType(String functionType);

    List<DangerFunctionRule> findByFunctionTypeAndEnabledTrue(String functionType);

    List<DangerFunctionRule> findByRiskLevel(String riskLevel);

    @Query("SELECT DISTINCT dfr.functionType FROM DangerFunctionRule dfr WHERE dfr.enabled = true ORDER BY dfr.functionType")
    List<String> findAllFunctionTypes();

    @Query("SELECT dfr FROM DangerFunctionRule dfr WHERE dfr.enabled = true ORDER BY dfr.functionType, dfr.riskLevel")
    List<DangerFunctionRule> findAllEnabledOrderByPriority();
}
