package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.*;
import org.example.securityplatform.service.BaselineSelectorService;
import org.example.securityplatform.service.DiffAnalysisService;
import org.example.securityplatform.service.DiffReportExporter;
import org.example.securityplatform.service.RecommendationService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * 差异分析 API 控制器
 */
@Tag(name = "差异分析", description = "版本差异对比、API变更追踪、报告导出")
@Slf4j
@RestController
@RequestMapping("/api/diff-analysis")
@RequiredArgsConstructor
public class DiffAnalysisController {

    private final DiffAnalysisService diffAnalysisService;
    private final BaselineSelectorService baselineSelectorService;
    private final DiffReportExporter diffReportExporter;
    private final RecommendationService recommendationService;

    /**
     * 获取项目的基线推荐
     */
    @Operation(summary = "获取基线推荐", description = "根据项目历史分析推荐最佳基线版本")
    @GetMapping("/baseline/{projectId}")
    public Result<BaselineRecommendationResponse> getBaselineRecommendation(
            @Parameter(description = "项目ID") @PathVariable Long projectId) {
        log.info("获取基线推荐: projectId={}", projectId);
        BaselineRecommendationResponse response = baselineSelectorService.getBaselineRecommendation(projectId);
        return Result.success(response);
    }

    /**
     * 创建差异分析任务
     */
    @Operation(summary = "创建差异分析任务", description = "创建基线与目标版本的差异分析任务")
    @PostMapping("/create")
    public Result<Long> createDiffAnalysis(@RequestBody CreateDiffAnalysisRequest request) {
        log.info("创建差异分析任务: projectId={}, baselineId={}, targetId={}",
                request.getProjectId(), request.getBaselineArtifactId(), request.getTargetArtifactId());

        Long taskId = diffAnalysisService.createDiffAnalysisTask(request);

        // 异步执行分析
        diffAnalysisService.executeDiffAnalysisAsync(taskId);

        return Result.success(taskId);
    }

    /**
     * 获取差异分析进度
     */
    @Operation(summary = "获取分析进度", description = "获取差异分析任务的执行进度")
    @GetMapping("/{taskId}/progress")
    public Result<DiffAnalysisProgressResponse> getProgress(
            @Parameter(description = "任务ID") @PathVariable Long taskId) {
        DiffAnalysisProgressResponse response = diffAnalysisService.getProgress(taskId);
        return Result.success(response);
    }

    /**
     * 获取差异分析结果
     */
    @Operation(summary = "获取分析结果", description = "获取差异分析的完整结果")
    @GetMapping("/{taskId}")
    public Result<DiffAnalysisResultResponse> getDiffResult(
            @Parameter(description = "任务ID") @PathVariable Long taskId) {
        log.info("获取差异分析结果: taskId={}", taskId);
        DiffAnalysisResultResponse response = diffAnalysisService.getDiffResult(taskId);
        return Result.success(response);
    }

    /**
     * 导出差异分析报告
     */
    @Operation(summary = "导出分析报告", description = "导出差异分析报告为Excel文件")
    @GetMapping("/{taskId}/export")
    public ResponseEntity<byte[]> exportReport(
            @Parameter(description = "任务ID") @PathVariable Long taskId) {
        log.info("导出差异分析报告: taskId={}", taskId);

        byte[] content = diffAnalysisService.exportReport(taskId);
        String fileName = diffReportExporter.generateFileName(taskId);

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + URLEncoder.encode(fileName, StandardCharsets.UTF_8) + "\"")
                .body(content);
    }

    /**
     * 按变更类型筛选API
     */
    @Operation(summary = "按变更类型筛选API", description = "根据变更类型筛选API差异")
    @GetMapping("/{taskId}/apis")
    public Result<DiffAnalysisResultResponse> getApisByChangeType(
            @Parameter(description = "任务ID") @PathVariable Long taskId,
            @Parameter(description = "变更类型: NEW_API, MODIFIED_API, AFFECTED_API, DELETED_API") @RequestParam(required = false) String changeType) {
        log.info("筛选API变更: taskId={}, changeType={}", taskId, changeType);

        DiffAnalysisResultResponse response = diffAnalysisService.getDiffResult(taskId);

        // 如果指定了变更类型，进行筛选
        if (changeType != null && !changeType.isEmpty()) {
            response.setApiDiffs(
                    response.getApiDiffs().stream()
                            .filter(api -> changeType.equals(api.getChangeType()))
                            .toList()
            );
        }

        return Result.success(response);
    }

    /**
     * 按风险等级筛选API
     */
    @Operation(summary = "按风险等级筛选API", description = "根据风险等级筛选API差异")
    @GetMapping("/{taskId}/risks")
    public Result<DiffAnalysisResultResponse> getApisByRiskLevel(
            @Parameter(description = "任务ID") @PathVariable Long taskId,
            @Parameter(description = "风险等级: HIGH, MEDIUM, LOW") @RequestParam(required = false) String riskLevel) {
        log.info("筛选API风险: taskId={}, riskLevel={}", taskId, riskLevel);

        DiffAnalysisResultResponse response = diffAnalysisService.getDiffResult(taskId);

        // 如果指定了风险等级，进行筛选
        if (riskLevel != null && !riskLevel.isEmpty()) {
            response.setApiDiffs(
                    response.getApiDiffs().stream()
                            .filter(api -> riskLevel.equals(api.getRiskLevel()))
                            .toList()
            );
        }

        return Result.success(response);
    }

    /**
     * 获取变更影响图谱
     */
    @Operation(summary = "获取变更影响图谱", description = "获取差异分析的变更影响图谱数据")
    @GetMapping("/{taskId}/impact-graph")
    public Result<ImpactGraphResponse> getImpactGraph(
            @Parameter(description = "任务ID") @PathVariable Long taskId,
            @Parameter(description = "过滤条件") ImpactGraphFilterRequest filter) {
        log.info("获取变更影响图谱: taskId={}, filter={}", taskId, filter);
        ImpactGraphResponse response = diffAnalysisService.getImpactGraph(taskId, filter);
        return Result.success(response);
    }

    /**
     * 获取智能推荐
     */
    @Operation(summary = "获取智能推荐", description = "获取差异分析的智能测试推荐和风险预警")
    @GetMapping("/{taskId}/recommendations")
    public Result<RecommendationResponse> getRecommendations(
            @Parameter(description = "任务ID") @PathVariable Long taskId) {
        log.info("获取智能推荐: taskId={}", taskId);
        RecommendationResponse response = recommendationService.generateRecommendations(taskId);
        return Result.success(response);
    }
}