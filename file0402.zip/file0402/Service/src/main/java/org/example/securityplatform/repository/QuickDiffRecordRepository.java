package org.example.securityplatform.repository;

import org.example.securityplatform.entity.QuickDiffRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 快速差异对比记录数据访问接口
 */
@Repository
public interface QuickDiffRecordRepository extends JpaRepository<QuickDiffRecord, Long> {
    List<QuickDiffRecord> findAllByOrderByCreatedAtDesc();
}
