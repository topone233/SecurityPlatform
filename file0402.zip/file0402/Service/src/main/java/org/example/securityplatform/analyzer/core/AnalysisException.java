package org.example.securityplatform.analyzer.core;

/**
 * 分析异常基类
 * 统一所有分析相关模块的异常体系
 */
public class AnalysisException extends RuntimeException {

    private final AnalysisErrorCode errorCode;

    public AnalysisException(AnalysisErrorCode errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public AnalysisException(AnalysisErrorCode errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
    }

    public AnalysisErrorCode getErrorCode() {
        return errorCode;
    }

    @Override
    public String toString() {
        return "AnalysisException{" +
                "errorCode=" + errorCode +
                ", message='" + getMessage() + '\'' +
                '}';
    }
}
