package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.CreateTaskRequest;
import org.example.securityplatform.dto.TaskResponse;
import org.example.securityplatform.service.TaskService;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 任务管理API控制器
 */
@Tag(name = "任务管理", description = "测试任务的创建、查询、状态更新等操作")
@RestController
@RequestMapping("/api/tasks")
@RequiredArgsConstructor
public class TaskController {

    private final TaskService taskService;

    /**
     * 创建任务
     */
    @Operation(summary = "创建任务", description = "在指定项目下创建新的测试任务")
    @PostMapping
    public Result<TaskResponse> createTask(@Validated @RequestBody CreateTaskRequest request) {
        return Result.success(taskService.createTask(request));
    }

    /**
     * 根据ID查询任务
     */
    @Operation(summary = "根据ID查询任务", description = "根据任务ID获取任务详情")
    @GetMapping("/{id}")
    public Result<TaskResponse> getTaskById(
            @Parameter(description = "任务ID") @PathVariable Long id) {
        return Result.success(taskService.getTaskById(id));
    }

    /**
     * 根据项目ID查询任务列表
     */
    @Operation(summary = "根据项目ID查询任务", description = "获取指定项目下的所有任务")
    @GetMapping("/project/{projectId}")
    public Result<List<TaskResponse>> getTasksByProjectId(
            @Parameter(description = "项目ID") @PathVariable Long projectId) {
        return Result.success(taskService.getTasksByProjectId(projectId));
    }

    /**
     * 根据状态查询任务列表
     */
    @Operation(summary = "根据状态查询任务", description = "获取指定状态的所有任务")
    @GetMapping("/status/{status}")
    public Result<List<TaskResponse>> getTasksByStatus(
            @Parameter(description = "任务状态: PENDING, RUNNING, COMPLETED, FAILED") @PathVariable String status) {
        return Result.success(taskService.getTasksByStatus(status));
    }

    /**
     * 查询所有任务
     */
    @Operation(summary = "查询所有任务", description = "获取所有任务列表")
    @GetMapping
    public Result<List<TaskResponse>> getAllTasks() {
        return Result.success(taskService.getAllTasks());
    }

    /**
     * 更新任务状态
     */
    @Operation(summary = "更新任务状态", description = "更新指定任务的状态")
    @PutMapping("/{id}/status")
    public Result<TaskResponse> updateTaskStatus(
            @Parameter(description = "任务ID") @PathVariable Long id,
            @Parameter(description = "新状态: PENDING, RUNNING, COMPLETED, FAILED") @RequestParam String status) {
        return Result.success(taskService.updateTaskStatus(id, status));
    }

    /**
     * 删除任务
     */
    @Operation(summary = "删除任务", description = "根据ID删除任务")
    @DeleteMapping("/{id}")
    public Result<Void> deleteTask(
            @Parameter(description = "任务ID") @PathVariable Long id) {
        taskService.deleteTask(id);
        return Result.success(null);
    }
}