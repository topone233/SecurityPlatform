package org.example.securityplatform.dto;

import lombok.Data;

/**
 * 调用链节点
 */
@Data
public class CallNode {

    /**
     * 类名
     */
    private String className;

    /**
     * 方法名
     */
    private String methodName;

    /**
     * 方法描述符
     */
    private String descriptor;

    /**
     * 调用行号
     */
    private Integer lineNumber;

    /**
     * 所在JAR名称（可选）
     */
    private String jarName;
}