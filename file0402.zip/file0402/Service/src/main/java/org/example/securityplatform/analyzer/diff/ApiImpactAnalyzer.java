package org.example.securityplatform.analyzer.diff;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.core.InterfaceMapper;
import org.example.securityplatform.entity.ApiInfo;
import org.example.securityplatform.entity.MethodCallEdge;

import java.util.*;
import java.util.stream.Collectors;

/**
 * API影响追溯分析器 - 从变更方法反向追溯到API
 * 核心功能：构建调用链，找出受影响的API
 */
@Slf4j
public class ApiImpactAnalyzer {

    // 调用图（按被调用者索引，便于反向追溯）
    private final Map<String, List<MethodCallEdge>> callGraphByCallee;

    // API列表（Controller方法）
    private final List<ApiInfo> apis;

    // 变更的方法列表
    private final Set<String> changedMethods;

    // 接口映射器
    private final InterfaceMapper interfaceMapper;

    // 所有类名集合
    private final Set<String> classNames;

    // 追溯深度限制
    private static final int MAX_TRACE_DEPTH = 10;

    public ApiImpactAnalyzer(List<MethodCallEdge> callEdges, List<ApiInfo> apis, Set<String> changedMethods) {
        this.apis = apis;
        this.changedMethods = changedMethods;

        // 从调用边提取所有类名，构建接口映射
        this.classNames = new HashSet<>();
        for (MethodCallEdge edge : callEdges) {
            classNames.add(edge.getCallerClass());
            classNames.add(edge.getCalleeClass());
        }
        this.interfaceMapper = new InterfaceMapper();
        Map<String, Set<String>> interfaceToImpl = interfaceMapper.buildInterfaceToImplMap(classNames);

        // 构建按被调用者索引的调用图（含接口映射）
        this.callGraphByCallee = new HashMap<>();
        for (MethodCallEdge edge : callEdges) {
            String calleeKey = edge.getCalleeClass() + "#" + edge.getCalleeMethod();
            callGraphByCallee.computeIfAbsent(calleeKey, k -> new ArrayList<>()).add(edge);

            // 如果被调用者是接口，为实现类也添加索引
            Set<String> impls = interfaceToImpl.get(edge.getCalleeClass());
            if (impls != null) {
                for (String impl : impls) {
                    String implCalleeKey = impl + "#" + edge.getCalleeMethod();
                    callGraphByCallee.computeIfAbsent(implCalleeKey, k -> new ArrayList<>()).add(edge);
                }
            }
        }

        log.info("========== ApiImpactAnalyzer初始化 ==========");
        log.info("输入数据: 调用边 {} 条, API {} 个, 变更方法 {} 个",
                callEdges.size(), apis.size(), changedMethods.size());
        log.info("调用图索引完成: {} 个被调用者", callGraphByCallee.size());
        log.info("接口映射统计: {} 个接口有实现类", interfaceToImpl.size());

        // 显示调用图样例（前5个）
        int sampleCount = 0;
        for (Map.Entry<String, List<MethodCallEdge>> entry : callGraphByCallee.entrySet()) {
            if (sampleCount++ < 5) {
                String calleeSimpleName = entry.getKey().substring(entry.getKey().lastIndexOf('.') + 1);
                log.info("  被调用者 #{}: {} (有 {} 个调用者)",
                        sampleCount, calleeSimpleName, entry.getValue().size());
            }
        }
    }

    /**
     * 分析API变更
     */
    public List<ApiChangeModel> analyze() {
        log.info("========== 开始API影响追溯分析 ==========");

        List<ApiChangeModel> apiChanges = new ArrayList<>();

        // 1. 识别新增和删除的API
        apiChanges.addAll(detectNewAndDeletedApis());

        // 2. 识别受影响的API（通过调用链追溯）
        apiChanges.addAll(traceAffectedApis());

        // 3. 计算风险等级
        calculateRiskLevels(apiChanges);

        log.info("API影响追溯分析完成: 共 {} 个API变更", apiChanges.size());
        return apiChanges;
    }

    /**
     * 检测新增和删除的API
     */
    private List<ApiChangeModel> detectNewAndDeletedApis() {
        List<ApiChangeModel> changes = new ArrayList<>();

        // 获取所有变更方法中的Controller方法
        Set<String> apiMethods = apis.stream()
                .map(api -> api.getControllerClass() + "#" + api.getMethodName())
                .collect(Collectors.toSet());

        for (String changedMethod : changedMethods) {
            if (apiMethods.contains(changedMethod)) {
                // 变更的方法是Controller方法
                ApiInfo api = apis.stream()
                        .filter(a -> (a.getControllerClass() + "#" + a.getMethodName()).equals(changedMethod))
                        .findFirst()
                        .orElse(null);

                if (api != null) {
                    ApiChangeModel change = new ApiChangeModel();
                    change.setApiUrl(api.getUrl());
                    change.setHttpMethod(api.getHttpMethod());
                    change.setControllerClass(api.getControllerClass());
                    change.setMethodName(api.getMethodName());
                    change.setParameters(api.getParameters());
                    change.setFramework(api.getFramework());
                    change.setChangeType("MODIFIED_API");
                    change.setChangeReason("API端点方法存在变更");

                    // 构建调用链
                    List<ApiChangeModel.CallChainNode> chain = new ArrayList<>();
                    chain.add(new ApiChangeModel.CallChainNode(api.getControllerClass(), api.getMethodName(), 0));
                    change.setCallChain(chain);

                    changes.add(change);
                }
            }
        }

        return changes;
    }

    /**
     * 追溯受影响的API
     */
    private List<ApiChangeModel> traceAffectedApis() {
        List<ApiChangeModel> affectedApis = new ArrayList<>();
        Set<String> tracedMethods = new HashSet<>(); // 避免重复追溯

        for (String changedMethod : changedMethods) {
            // 从变更方法出发，反向追溯所有调用者
            List<TraceResult> traceResults = traceCallers(changedMethod, new ArrayList<>(), 0, tracedMethods);

            for (TraceResult result : traceResults) {
                // 检查追溯结果是否到达了Controller
                ApiInfo api = findApiByControllerMethod(result.methodClass, result.methodName);
                if (api != null) {
                    // 找到了受影响的API
                    ApiChangeModel change = createAffectedApiChange(api, changedMethod, result.callChain);
                    affectedApis.add(change);

                    log.info("  ✓ 追溯到受影响API: {} {} - 调用链长度: {}",
                            api.getHttpMethod(), api.getUrl(), result.callChain.size() + 1);
                }
            }
        }

        // 去重（同一个API可能被多个变更方法影响）
        return deduplicateApiChanges(affectedApis);
    }

    /**
     * 反向追溯调用者
     */
    private List<TraceResult> traceCallers(String methodKey,
                                            List<ApiChangeModel.CallChainNode> currentChain,
                                            int depth,
                                            Set<String> tracedMethods) {
        List<TraceResult> results = new ArrayList<>();

        // 深度限制
        if (depth >= MAX_TRACE_DEPTH) {
            return results;
        }

        // 避免循环
        if (tracedMethods.contains(methodKey)) {
            return results;
        }
        tracedMethods.add(methodKey);

        // 查找调用者
        List<MethodCallEdge> callers = callGraphByCallee.get(methodKey);
        if (callers == null || callers.isEmpty()) {
            return results;
        }

        log.info("  方法 {} 找到 {} 个调用者", methodKey.substring(methodKey.lastIndexOf('.') + 1), callers.size());

        for (MethodCallEdge caller : callers) {
            String callerKey = caller.getCallerClass() + "#" + caller.getCallerMethod();

            // 构建调用链
            List<ApiChangeModel.CallChainNode> newChain = new ArrayList<>(currentChain);
            newChain.add(new ApiChangeModel.CallChainNode(caller.getCallerClass(), caller.getCallerMethod(), depth));

            // 记录结果
            TraceResult result = new TraceResult();
            result.methodClass = caller.getCallerClass();
            result.methodName = caller.getCallerMethod();
            result.callChain = newChain;
            results.add(result);

            // 继续向上追溯
            results.addAll(traceCallers(callerKey, newChain, depth + 1, tracedMethods));
        }

        return results;
    }

    /**
     * 根据Controller类和方法查找API
     */
    private ApiInfo findApiByControllerMethod(String className, String methodName) {
        for (ApiInfo api : apis) {
            if (api.getControllerClass().equals(className) && api.getMethodName().equals(methodName)) {
                return api;
            }
        }
        return null;
    }

    /**
     * 创建受影响API的变更模型
     */
    private ApiChangeModel createAffectedApiChange(ApiInfo api, String changedMethod,
                                                    List<ApiChangeModel.CallChainNode> callChain) {
        ApiChangeModel change = new ApiChangeModel();
        change.setApiUrl(api.getUrl());
        change.setHttpMethod(api.getHttpMethod());
        change.setControllerClass(api.getControllerClass());
        change.setMethodName(api.getMethodName());
        change.setParameters(api.getParameters());
        change.setFramework(api.getFramework());
        change.setChangeType("AFFECTED_API");

        // 解析变更方法
        String[] parts = changedMethod.split("#");
        String changedClass = parts.length > 0 ? parts[0] : "";
        String changedMethodName = parts.length > 1 ? parts[1] : "";
        change.setChangeReason("下游方法 " + changedClass + "." + changedMethodName + " 存在变更");

        // 反转调用链（从API到变更点）
        List<ApiChangeModel.CallChainNode> reversedChain = new ArrayList<>();
        reversedChain.add(new ApiChangeModel.CallChainNode(api.getControllerClass(), api.getMethodName(), 0));
        for (int i = callChain.size() - 1; i >= 0; i--) {
            ApiChangeModel.CallChainNode node = callChain.get(i);
            reversedChain.add(new ApiChangeModel.CallChainNode(node.getClassName(), node.getMethodName(), reversedChain.size()));
        }
        change.setCallChain(reversedChain);

        return change;
    }

    /**
     * 去重API变更，优先级：NEW_API/DELETED_API > MODIFIED_API > AFFECTED_API
     */
    private List<ApiChangeModel> deduplicateApiChanges(List<ApiChangeModel> changes) {
        Map<String, ApiChangeModel> uniqueChanges = new LinkedHashMap<>();

        for (ApiChangeModel change : changes) {
            String apiKey = change.getApiKey();
            String changeType = change.getChangeType();

            ApiChangeModel existing = uniqueChanges.get(apiKey);

            if (existing == null) {
                // 第一次遇到该 API
                uniqueChanges.put(apiKey, change);
            } else {
                // 已存在，根据优先级决定是否替换
                String existingType = existing.getChangeType();

                // 优先级判断
                if (shouldReplaceChangeType(existingType, changeType)) {
                    // 新的变更类型优先级更高，替换
                    uniqueChanges.put(apiKey, change);
                    log.info("API {} 变更类型升级: {} -> {}", apiKey, existingType, changeType);
                } else if (existingType.equals(changeType)) {
                    // 相同变更类型，合并调用链
                    existing.getCallChain().addAll(change.getCallChain());
                    log.info("API {} 合并调用链", apiKey);
                } else {
                    // 旧的变更类型优先级更高，保留旧的，丢弃新的
                    log.info("API {} 保留高优先级变更类型: {} (丢弃: {})", apiKey, existingType, changeType);
                }
            }
        }

        return new ArrayList<>(uniqueChanges.values());
    }

    /**
     * 判断是否应该替换变更类型
     * 优先级：NEW_API/DELETED_API (优先级最高) > MODIFIED_API > AFFECTED_API
     */
    private boolean shouldReplaceChangeType(String existingType, String newType) {
        int existingPriority = getChangeTypePriority(existingType);
        int newPriority = getChangeTypePriority(newType);

        return newPriority > existingPriority;
    }

    /**
     * 获取变更类型优先级（数值越大优先级越高）
     */
    private int getChangeTypePriority(String changeType) {
        if ("NEW_API".equals(changeType) || "DELETED_API".equals(changeType)) {
            return 3; // 最高优先级
        } else if ("MODIFIED_API".equals(changeType)) {
            return 2;
        } else if ("AFFECTED_API".equals(changeType)) {
            return 1; // 最低优先级
        }
        return 0;
    }

    /**
     * 计算风险等级
     */
    private void calculateRiskLevels(List<ApiChangeModel> changes) {
        for (ApiChangeModel change : changes) {
            String riskLevel = "MEDIUM";

            // 新增API风险较高
            if ("NEW_API".equals(change.getChangeType())) {
                riskLevel = "HIGH";
            }
            // 修改API风险较高
            else if ("MODIFIED_API".equals(change.getChangeType())) {
                riskLevel = "HIGH";
            }
            // 受影响API根据调用链深度评估
            else if ("AFFECTED_API".equals(change.getChangeType())) {
                int depth = change.getCallChain().size();
                if (depth <= 2) {
                    riskLevel = "MEDIUM"; // 直接调用
                } else {
                    riskLevel = "LOW"; // 间接调用
                }
            }

            // 如果关联危险函数，提升风险等级
            if (!change.getDangerFunctions().isEmpty()) {
                riskLevel = "HIGH";
            }

            change.setRiskLevel(riskLevel);
        }
    }

    /**
     * 追溯结果内部类
     */
    private static class TraceResult {
        String methodClass;
        String methodName;
        List<ApiChangeModel.CallChainNode> callChain;
    }
}