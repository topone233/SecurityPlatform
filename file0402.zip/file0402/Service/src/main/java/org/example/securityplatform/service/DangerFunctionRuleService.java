package org.example.securityplatform.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.dto.DangerFunctionRuleRequest;
import org.example.securityplatform.dto.DangerFunctionRuleResponse;
import org.example.securityplatform.entity.DangerFunctionRule;
import org.example.securityplatform.repository.DangerFunctionRuleRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 危险函数规则服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DangerFunctionRuleService {

    private final DangerFunctionRuleRepository ruleRepository;

    public List<DangerFunctionRuleResponse> getAllRules() {
        return ruleRepository.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    public List<DangerFunctionRuleResponse> getAllEnabledRules() {
        return ruleRepository.findByEnabledTrue().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    public DangerFunctionRuleResponse getRuleById(Long id) {
        DangerFunctionRule rule = ruleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("规则不存在: " + id));
        return toResponse(rule);
    }

    public List<DangerFunctionRuleResponse> getRulesByFunctionType(String functionType) {
        return ruleRepository.findByFunctionTypeAndEnabledTrue(functionType).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public DangerFunctionRuleResponse createRule(DangerFunctionRuleRequest request) {
        DangerFunctionRule rule = new DangerFunctionRule();
        updateRuleFromRequest(rule, request);
        if (rule.getEnabled() == null) {
            rule.setEnabled(true);
        }
        DangerFunctionRule saved = ruleRepository.save(rule);
        log.info("创建危险函数规则: {}", saved.getRuleName());
        return toResponse(saved);
    }

    @Transactional
    public DangerFunctionRuleResponse updateRule(Long id, DangerFunctionRuleRequest request) {
        DangerFunctionRule rule = ruleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("规则不存在: " + id));
        updateRuleFromRequest(rule, request);
        DangerFunctionRule saved = ruleRepository.save(rule);
        log.info("更新危险函数规则: {}", saved.getRuleName());
        return toResponse(saved);
    }

    @Transactional
    public void deleteRule(Long id) {
        if (!ruleRepository.existsById(id)) {
            throw new RuntimeException("规则不存在: " + id);
        }
        ruleRepository.deleteById(id);
        log.info("删除危险函数规则: {}", id);
    }

    @Transactional
    public DangerFunctionRuleResponse toggleRule(Long id, boolean enabled) {
        DangerFunctionRule rule = ruleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("规则不存在: " + id));
        rule.setEnabled(enabled);
        DangerFunctionRule saved = ruleRepository.save(rule);
        log.info("{}危险函数规则: {}", enabled ? "启用" : "禁用", saved.getRuleName());
        return toResponse(saved);
    }

    public List<String> getAllFunctionTypes() {
        return ruleRepository.findAllFunctionTypes();
    }

    /**
     * 检查类名和方法名是否匹配规则
     */
    public boolean matchesRule(String className, String methodName, DangerFunctionRule rule) {
        return matchesPattern(className, rule.getClassPattern()) &&
               matchesPattern(methodName, rule.getMethodPattern());
    }

    /**
     * 模式匹配（支持通配符 *）
     */
    private boolean matchesPattern(String value, String pattern) {
        if (pattern == null || pattern.isEmpty() || "*".equals(pattern)) {
            return true;
        }
        if (value == null) {
            return false;
        }

        // 支持前缀通配符 *xxx
        if (pattern.startsWith("*") && !pattern.endsWith("*")) {
            return value.contains(pattern.substring(1));
        }
        // 支持后缀通配符 xxx*
        if (pattern.endsWith("*") && !pattern.startsWith("*")) {
            return value.startsWith(pattern.substring(0, pattern.length() - 1));
        }
        // 支持前后通配符 *xxx*
        if (pattern.startsWith("*") && pattern.endsWith("*")) {
            return value.contains(pattern.substring(1, pattern.length() - 1));
        }
        // 精确匹配
        return value.equals(pattern);
    }

    private void updateRuleFromRequest(DangerFunctionRule rule, DangerFunctionRuleRequest request) {
        rule.setRuleName(request.getRuleName());
        rule.setFunctionType(request.getFunctionType());
        rule.setClassPattern(request.getClassPattern());
        rule.setMethodPattern(request.getMethodPattern());
        rule.setDescription(request.getDescription());
        rule.setRiskLevel(request.getRiskLevel());
        rule.setSecurityImpact(request.getSecurityImpact());
        rule.setRemediation(request.getRemediation());
        rule.setCweId(request.getCweId());
        rule.setReferences(request.getReferences());
        if (request.getEnabled() != null) {
            rule.setEnabled(request.getEnabled());
        }
    }

    private DangerFunctionRuleResponse toResponse(DangerFunctionRule rule) {
        return DangerFunctionRuleResponse.builder()
                .id(rule.getId())
                .ruleName(rule.getRuleName())
                .functionType(rule.getFunctionType())
                .classPattern(rule.getClassPattern())
                .methodPattern(rule.getMethodPattern())
                .description(rule.getDescription())
                .riskLevel(rule.getRiskLevel())
                .securityImpact(rule.getSecurityImpact())
                .remediation(rule.getRemediation())
                .cweId(rule.getCweId())
                .references(rule.getReferences())
                .enabled(rule.getEnabled())
                .createdAt(rule.getCreatedAt())
                .updatedAt(rule.getUpdatedAt())
                .build();
    }
}
