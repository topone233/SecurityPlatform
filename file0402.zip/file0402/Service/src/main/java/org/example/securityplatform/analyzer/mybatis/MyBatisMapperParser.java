package org.example.securityplatform.analyzer.mybatis;

import lombok.extern.slf4j.Slf4j;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * MyBatis Mapper XML解析器
 * 从JAR包中提取并解析Mapper XML文件，检测${}占位符注入风险
 */
@Slf4j
public class MyBatisMapperParser {

    private static final Pattern DOLLAR_PARAM_PATTERN = Pattern.compile("\\$\\{([^}]+)\\}");

    /**
     * 解析JAR包中的MyBatis Mapper文件
     *
     * @param jarPath JAR包路径
     * @return Mapper模型列表
     */
    public List<MyBatisMapperModel> parse(String jarPath) throws IOException {
        List<MyBatisMapperModel> mappers = new ArrayList<>();

        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> entries = jarFile.entries();

            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (isMapperXml(entry.getName())) {
                    try (InputStream is = jarFile.getInputStream(entry)) {
                        MyBatisMapperModel mapper = parseMapperXml(is, entry.getName());
                        if (mapper != null && !mapper.getStatements().isEmpty()) {
                            mappers.add(mapper);
                        }
                    } catch (Exception e) {
                        log.warn("解析Mapper XML失败: {}", entry.getName(), e);
                    }
                }
            }
        }

        log.info("从JAR包中解析到 {} 个Mapper文件", mappers.size());
        return mappers;
    }

    /**
     * 判断是否是Mapper XML文件
     */
    private boolean isMapperXml(String fileName) {
        String lowerName = fileName.toLowerCase();
        return lowerName.endsWith(".xml") &&
                (lowerName.contains("mapper") ||
                        lowerName.contains("mybatis") ||
                        lowerName.contains("dao"));
    }

    /**
     * 解析单个Mapper XML文件
     */
    private MyBatisMapperModel parseMapperXml(InputStream is, String filePath) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        // 安全配置：防止XXE攻击，但允许DOCTYPE（MyBatis Mapper必须有DOCTYPE）
        try {
            // 禁止使用外部实体
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            // 禁止外部DTD
            factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            // 不处理XInclude
            factory.setXIncludeAware(false);
            // 不展开实体引用
            factory.setExpandEntityReferences(false);
        } catch (Exception e) {
            log.warn("设置XML解析安全特性失败", e);
        }

        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(is);

        Element root = document.getDocumentElement();
        String namespace = root.getAttribute("namespace");

        MyBatisMapperModel mapper = new MyBatisMapperModel();
        mapper.setNamespace(namespace);
        mapper.setFilePath(filePath);

        // 第一步：收集所有SQL片段
        collectSqlFragments(root, mapper);

        // 第二步：解析各种SQL语句
        parseStatements(root, mapper, "select");
        parseStatements(root, mapper, "insert");
        parseStatements(root, mapper, "update");
        parseStatements(root, mapper, "delete");

        return mapper;
    }

    /**
     * 解析指定类型的SQL语句
     */
    private void parseStatements(Element root, MyBatisMapperModel mapper, String tagName) {
        NodeList nodes = root.getElementsByTagName(tagName);
        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                MyBatisMapperModel.SqlStatement stmt = new MyBatisMapperModel.SqlStatement();

                stmt.setId(element.getAttribute("id"));
                stmt.setType(tagName.toUpperCase());
                stmt.setSql(extractSql(element, mapper));

                // 检测${}占位符
                List<String> dollarParams = extractDollarParams(stmt.getSql());
                stmt.setDollarParams(dollarParams);

                // 只有包含${}占位符的才记录
                if (!dollarParams.isEmpty()) {
                    mapper.getStatements().add(stmt);
                }
            }
        }
    }

    /**
     * 收集所有SQL片段（<sql id="...">...</sql>）
     */
    private void collectSqlFragments(Element root, MyBatisMapperModel mapper) {
        // 先收集所有片段的DOM元素
        Map<String, Element> fragmentElements = new HashMap<>();
        NodeList sqlNodes = root.getElementsByTagName("sql");
        for (int i = 0; i < sqlNodes.getLength(); i++) {
            Node node = sqlNodes.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                String id = element.getAttribute("id");
                if (id != null && !id.isEmpty()) {
                    fragmentElements.put(id, element);
                }
            }
        }

        // 展开每个片段（处理嵌套include）
        for (Map.Entry<String, Element> entry : fragmentElements.entrySet()) {
            String id = entry.getKey();
            Element element = entry.getValue();
            Set<String> expanding = new HashSet<>();
            String expandedSql = expandFragmentRecursive(element, fragmentElements, expanding, id);
            mapper.getSqlFragments().put(id, expandedSql);
        }

        log.debug("收集到 {} 个SQL片段", mapper.getSqlFragments().size());
    }

    /**
     * 递归展开SQL片段
     */
    private String expandFragmentRecursive(Element element, Map<String, Element> fragmentElements,
                                          Set<String> expanding, String currentFragmentId) {
        StringBuilder sql = new StringBuilder();
        NodeList children = element.getChildNodes();

        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == Node.TEXT_NODE) {
                String text = child.getTextContent().trim();
                if (!text.isEmpty()) {
                    sql.append(text).append(" ");
                }
            } else if (child.getNodeType() == Node.ELEMENT_NODE) {
                Element childElement = (Element) child;
                String tagName = childElement.getTagName();

                // 处理嵌套的 <include>
                if ("include".equals(tagName)) {
                    String refid = childElement.getAttribute("refid");
                    if (refid != null && !refid.isEmpty()) {
                        // 检测循环引用
                        if (expanding.contains(refid)) {
                            log.warn("SQL片段循环引用检测: {} -> {}", currentFragmentId, refid);
                            continue;
                        }

                        Element refElement = fragmentElements.get(refid);
                        if (refElement != null) {
                            expanding.add(refid);
                            String nestedSql = expandFragmentRecursive(refElement, fragmentElements, expanding, currentFragmentId);
                            sql.append(nestedSql).append(" ");
                            expanding.remove(refid);
                        } else {
                            log.warn("SQL片段引用不存在: {}", refid);
                        }
                    }
                }
                // 处理动态SQL标签
                else if ("if".equals(tagName) || "where".equals(tagName) ||
                        "set".equals(tagName) || "trim".equals(tagName) ||
                        "foreach".equals(tagName) || "choose".equals(tagName) ||
                        "when".equals(tagName) || "otherwise".equals(tagName)) {
                    String nestedSql = expandFragmentRecursive(childElement, fragmentElements, expanding, currentFragmentId);
                    sql.append(nestedSql).append(" ");
                }
            }
        }

        return sql.toString().trim().replaceAll("\\s+", " ");
    }

    /**
     * 从元素中提取SQL文本（包括处理动态SQL标签和include引用）
     */
    private String extractSql(Element element, MyBatisMapperModel mapper) {
        StringBuilder sql = new StringBuilder();
        Set<String> expandedFragments = new HashSet<>(); // 防止循环引用
        extractTextRecursive(element, sql, mapper, expandedFragments);
        return sql.toString().trim().replaceAll("\\s+", " ");
    }

    /**
     * 递归提取文本内容
     */
    private void extractTextRecursive(Element element, StringBuilder sql, MyBatisMapperModel mapper, Set<String> expandedFragments) {
        NodeList children = element.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == Node.TEXT_NODE) {
                String text = child.getTextContent().trim();
                if (!text.isEmpty()) {
                    sql.append(text).append(" ");
                }
            } else if (child.getNodeType() == Node.ELEMENT_NODE) {
                Element childElement = (Element) child;
                String tagName = childElement.getTagName();

                // 处理 <include refid="..."/>
                if ("include".equals(tagName)) {
                    String refid = childElement.getAttribute("refid");
                    if (refid != null && !refid.isEmpty()) {
                        expandSqlFragment(refid, sql, mapper, expandedFragments);
                    }
                }
                // 处理动态SQL标签，提取其中的内容
                else if ("if".equals(tagName) || "where".equals(tagName) ||
                        "set".equals(tagName) || "trim".equals(tagName) ||
                        "foreach".equals(tagName) || "choose".equals(tagName) ||
                        "when".equals(tagName) || "otherwise".equals(tagName)) {
                    extractTextRecursive(childElement, sql, mapper, expandedFragments);
                }
            }
        }
    }

    /**
     * 展开SQL片段引用
     */
    private void expandSqlFragment(String refid, StringBuilder sql, MyBatisMapperModel mapper, Set<String> expandedFragments) {
        // 检测循环引用
        if (expandedFragments.contains(refid)) {
            log.warn("检测到循环引用: {}, 跳过展开", refid);
            return;
        }

        // 查找SQL片段（已经在收集阶段展开完成）
        String fragmentSql = mapper.getSqlFragments().get(refid);
        if (fragmentSql == null) {
            log.warn("SQL片段不存在: {}", refid);
            return;
        }

        // 标记为已展开
        expandedFragments.add(refid);

        // 追加片段内容
        sql.append(fragmentSql).append(" ");

        // 移除展开标记（允许其他地方引用同一个片段）
        expandedFragments.remove(refid);
    }

    /**
     * 检测SQL中的${}占位符
     *
     * @param sql SQL文本
     * @return 参数名列表
     */
    public List<String> extractDollarParams(String sql) {
        List<String> params = new ArrayList<>();
        if (sql == null) {
            return params;
        }

        Matcher matcher = DOLLAR_PARAM_PATTERN.matcher(sql);
        while (matcher.find()) {
            String param = matcher.group(1).trim();
            if (!params.contains(param)) {
                params.add(param);
            }
        }
        return params;
    }
}