package org.example.securityplatform.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 危险函数规则实体
 * 用于存储危险函数检测规则，替代硬编码的扫描规则
 */
@Data
@Entity
@Table(name = "danger_function_rule")
public class DangerFunctionRule {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "rule_name", nullable = false, length = 255)
    private String ruleName;

    @Column(name = "function_type", nullable = false, length = 100)
    private String functionType;

    @Column(name = "class_pattern", nullable = false, length = 500)
    private String classPattern;

    @Column(name = "method_pattern", nullable = false, length = 255)
    private String methodPattern;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "risk_level", nullable = false, length = 20)
    private String riskLevel;

    @Column(name = "security_impact", columnDefinition = "TEXT")
    private String securityImpact;

    @Column(name = "remediation", columnDefinition = "TEXT")
    private String remediation;

    @Column(name = "cwe_id", length = 50)
    private String cweId;

    @Column(name = "references", columnDefinition = "TEXT")
    private String references;

    @Column(name = "enabled", nullable = false)
    private Boolean enabled = true;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
