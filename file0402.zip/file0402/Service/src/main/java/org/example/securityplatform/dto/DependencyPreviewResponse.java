package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 依赖预览响应 - 返回JAR包中的依赖JAR列表和业务包名列表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DependencyPreviewResponse {

    /**
     * 依赖JAR名称列表（从BOOT-INF/lib和WEB-INF/lib扫描）
     */
    private List<String> dependencyJars;

    /**
     * 业务包名列表（从class文件路径提取，排除框架包）
     */
    private List<String> packages;

    /**
     * 总依赖数量
     */
    private Integer totalDependencies;

    /**
     * 是否为多模块项目（父JAR无业务代码）
     */
    private Boolean isMultiModule;
}