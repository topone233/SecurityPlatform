package org.example.securityplatform.entity;

import jakarta.persistence.*;
import lombok.Data;

/**
 * 方法调用关系实体 - 用于存储调用图
 */
@Data
@Entity
@Table(name = "method_call_edge")
public class MethodCallEdge {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "artifact_id", nullable = false)
    private Long artifactId;

    @Column(name = "caller_class", nullable = false, length = 255)
    private String callerClass;

    @Column(name = "caller_method", nullable = false, length = 255)
    private String callerMethod;

    @Column(name = "caller_descriptor", length = 500)
    private String callerDescriptor;

    @Column(name = "callee_class", nullable = false, length = 255)
    private String calleeClass;

    @Column(name = "callee_method", nullable = false, length = 255)
    private String calleeMethod;

    @Column(name = "callee_descriptor", length = 500)
    private String calleeDescriptor;

    @Column(name = "call_line")
    private Integer callLine;

    @Column(name = "call_type", length = 20)
    private String callType; // VIRTUAL, STATIC, SPECIAL, INTERFACE
}
