package org.example.securityplatform.repository;

import org.example.securityplatform.entity.DiffAnalysisTask;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 差异分析任务数据访问接口
 */
@Repository
public interface DiffAnalysisTaskRepository extends JpaRepository<DiffAnalysisTask, Long> {
    List<DiffAnalysisTask> findByProjectId(Long projectId);
    List<DiffAnalysisTask> findByProjectIdOrderByCreatedAtDesc(Long projectId);
    List<DiffAnalysisTask> findByStatus(String status);
    List<DiffAnalysisTask> findByBaselineArtifactId(Long baselineArtifactId);
    List<DiffAnalysisTask> findByTargetArtifactId(Long targetArtifactId);

    /**
     * 根据baseline制品ID删除差异分析任务
     * 用于制品删除时的级联清理
     */
    @Modifying(clearAutomatically = true)
    void deleteByBaselineArtifactId(Long baselineArtifactId);

    /**
     * 根据target制品ID删除差异分析任务
     * 用于制品删除时的级联清理
     */
    @Modifying(clearAutomatically = true)
    void deleteByTargetArtifactId(Long targetArtifactId);
}
