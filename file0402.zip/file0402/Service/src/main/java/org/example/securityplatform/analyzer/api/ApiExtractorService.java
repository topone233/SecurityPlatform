package org.example.securityplatform.analyzer.api;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.jar.DependencyScanner;
import org.example.securityplatform.analyzer.jar.JarInfo;
import org.example.securityplatform.config.TempDirConfig;
import org.example.securityplatform.entity.ApiInfo;
import org.example.securityplatform.repository.ApiInfoRepository;
import org.example.securityplatform.util.FileUtil;
import org.example.securityplatform.util.JarUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * API提取服务
 */
@Slf4j
@Service
public class ApiExtractorService {

    @Autowired
    private ApiInfoRepository apiInfoRepository;

    @Autowired
    private TempDirConfig tempDirConfig;

    @Autowired
    private DependencyScanner dependencyScanner;

    private final List<ApiExtractorStrategy> strategies = new ArrayList<>();

    public ApiExtractorService() {
        // 源代码提取器
        strategies.add(new SpringMvcApiExtractor());
        strategies.add(new JaxRsApiExtractor());
        // 字节码提取器
        strategies.add(new BytecodeApiExtractorStrategy());
    }

    /**
     * 分析制品并提取API（支持多模块）
     *
     * @param artifactId 制品ID
     * @param jars       JAR信息列表（包含主JAR和依赖JAR）
     */
    public void analyzeArtifacts(Long artifactId, List<JarInfo> jars) {
        try {
            log.info("开始分析制品API（多模块模式）: artifactId={}, jarsCount={}", artifactId, jars.size());

            List<ApiModel> allApis = new ArrayList<>();

            // 遍历所有JAR（主JAR + 依赖JAR）
            for (JarInfo jar : jars) {
                log.info("扫描JAR: {} ({})", jar.getShortName(), jar.getType());
                List<ApiModel> apis = analyzeSingleJar(artifactId, jar);
                allApis.addAll(apis);
                log.info("从 {} 提取到 {} 个API", jar.getShortName(), apis.size());
            }

            log.info("提取到 {} 个API（总计）", allApis.size());

            // 保存API信息
            for (ApiModel model : allApis) {
                ApiInfo info = new ApiInfo();
                info.setArtifactId(artifactId);
                info.setUrl(model.getUrl());
                info.setHttpMethod(model.getHttpMethod());
                info.setControllerClass(model.getControllerClass());
                info.setMethodName(model.getMethodName());
                info.setParameters(model.getParameters());
                info.setFramework(model.getFramework());
                apiInfoRepository.save(info);
            }

            log.info("API分析完成: artifactId={}, API数量={}", artifactId, allApis.size());

        } catch (Exception e) {
            log.error("API分析失败: artifactId={}", artifactId, e);
            throw new RuntimeException("API分析失败", e);
        }
    }

    /**
     * 分析单个JAR文件提取API（内部方法）
     *
     * @param artifactId 制品ID
     * @param jar        JAR信息
     * @return 提取的API列表
     */
    private List<ApiModel> analyzeSingleJar(Long artifactId, JarInfo jar) {
        try {
            // 解压到临时目录（每个JAR使用独立目录避免冲突）
            String tempDir = tempDirConfig.getExtractDir(artifactId) + "_" +
                    jar.getName().replace(".jar", "").replaceAll("[^a-zA-Z0-9_-]", "");
            FileUtil.createDirectoryIfNotExists(tempDir);

            JarUtil.extractJar(jar.getJarPath(), tempDir);

            // 获取所有Java源文件和字节码文件
            List<Path> javaFiles = FileUtil.listFilesByExtension(tempDir, "java");
            List<Path> classFiles = FileUtil.listFilesByExtension(tempDir, "class");

            // 处理 Spring Boot Fat JAR 结构：检查 BOOT-INF/classes 目录
            String bootInfClassesDir = tempDir + "/BOOT-INF/classes";
            java.io.File bootInfDir = new java.io.File(bootInfClassesDir);
            if (bootInfDir.exists() && bootInfDir.isDirectory()) {
                log.info("检测到 Spring Boot Fat JAR 结构，扫描 BOOT-INF/classes 目录");
                List<Path> bootInfClassFiles = FileUtil.listFilesByExtension(bootInfClassesDir, "class");
                List<Path> bootInfJavaFiles = FileUtil.listFilesByExtension(bootInfClassesDir, "java");
                classFiles.addAll(bootInfClassFiles);
                javaFiles.addAll(bootInfJavaFiles);
                log.info("从 BOOT-INF/classes 找到 {} 个 class 文件, {} 个 java 文件",
                        bootInfClassFiles.size(), bootInfJavaFiles.size());
            }

            log.info("扫描到 {} 个Java源文件, {} 个class字节码文件", javaFiles.size(), classFiles.size());

            // 合并所有文件
            List<Path> allFiles = new ArrayList<>();
            allFiles.addAll(javaFiles);
            allFiles.addAll(classFiles);

            // 提取API
            List<ApiModel> apis = new ArrayList<>();
            for (Path file : allFiles) {
                for (ApiExtractorStrategy strategy : strategies) {
                    if (strategy.supports(file.toString())) {
                        List<ApiModel> extractedApis = strategy.extract(file.toString());
                        apis.addAll(extractedApis);
                    }
                }
            }

            return apis;

        } catch (IOException e) {
            log.warn("分析JAR失败: {}, 错误: {}", jar.getShortName(), e.getMessage());
            return new ArrayList<>(); // 单个JAR失败不影响整体
        }
    }

    /**
     * 分析制品并提取API（向后兼容，单JAR模式）
     *
     * @param artifactId 制品ID
     * @param jarPath    Jar包路径
     */
    public void analyzeArtifact(Long artifactId, String jarPath) {
        // 转换为单JAR列表模式，保持向后兼容
        JarInfo singleJar = new JarInfo(jarPath, JarInfo.JarType.MAIN, "MAIN");
        analyzeArtifacts(artifactId, List.of(singleJar));
    }

    /**
     * 获取制品的API列表
     *
     * @param artifactId 制品ID
     * @return API列表
     */
    public List<ApiInfo> getApisByArtifactId(Long artifactId) {
        return apiInfoRepository.findByArtifactId(artifactId);
    }
}