package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 测试建议DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TestSuggestion {
    private List<String> caseTypes;
    private String focusPoints;
    private String estimatedEffort;
}