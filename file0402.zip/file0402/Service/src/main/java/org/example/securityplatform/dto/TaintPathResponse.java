package org.example.securityplatform.dto;

import lombok.Data;

import java.util.List;

/**
 * 污点路径响应
 */
@Data
public class TaintPathResponse {
    /**
     * 路径ID
     */
    private Long id;

    /**
     * 污点源类名（Controller类）
     */
    private String sourceClass;

    /**
     * 污点源方法名（Controller方法）
     */
    private String sourceMethod;

    /**
     * 污点参数名
     */
    private String sourceParam;

    /**
     * 调用链
     */
    private List<CallChainNodeResponse> callChain;

    /**
     * 调用深度
     */
    private Integer depth;

    /**
     * 是否可达
     */
    private Boolean isReachable;

    /**
     * 调用链节点响应
     */
    @Data
    public static class CallChainNodeResponse {
        private String className;
        private String methodName;
        private Integer lineNumber;
    }
}