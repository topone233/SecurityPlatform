package org.example.securityplatform.service;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.core.InterfaceMapper;
import org.example.securityplatform.analyzer.diff.CallGraphBuilder;
import org.example.securityplatform.analyzer.diff.MethodCallModel;
import org.example.securityplatform.analyzer.jar.DependencyAnalysisConfig;
import org.example.securityplatform.analyzer.jar.DependencyScanner;
import org.example.securityplatform.analyzer.jar.JarInfo;
import org.example.securityplatform.dto.CallNode;
import org.example.securityplatform.dto.CallPath;
import org.example.securityplatform.dto.CallPathRequest;
import org.example.securityplatform.dto.CallPathResponse;
import org.example.securityplatform.dto.MethodSuggestion;
import org.example.securityplatform.entity.Artifact;
import org.example.securityplatform.repository.ArtifactRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * 调用路径分析服务
 */
@Slf4j
@Service
public class CallPathService {

    @Autowired
    private ArtifactRepository artifactRepository;

    private final InterfaceMapper interfaceMapper = new InterfaceMapper();

    @Autowired
    private DependencyScanner dependencyScanner;

    /**
     * 调用图缓存：artifactId -> List<MethodCallModel>
     */
    private final Map<Long, List<MethodCallModel>> callGraphCache = new ConcurrentHashMap<>();

    /**
     * 方法索引缓存：artifactId -> MethodIndex
     */
    private final Map<Long, MethodIndex> methodIndexCache = new ConcurrentHashMap<>();

    /**
     * 查找调用路径
     *
     * @param request 查询请求
     * @return 调用路径响应
     */
    public CallPathResponse findPaths(CallPathRequest request) {
        log.info("开始查找调用路径: {}#{} -> {}#{}",
                request.getStartClass(), request.getStartMethod(),
                request.getEndClass(), request.getEndMethod());

        // 1. 获取或构建调用图
        List<MethodCallModel> callGraph = getOrBuildCallGraph(request.getArtifactId());

        // 2. 构建邻接表（正向调用关系）
        Map<String, List<MethodCallModel>> adjacencyList = buildAdjacencyList(callGraph);

        log.info("调用图总大小: {} 个调用关系", callGraph.size());
        log.info("邻接表大小: {} 个调用者", adjacencyList.size());

        // 3. 验证起点和终点是否存在
        String startKey = request.getStartClass() + "#" + request.getStartMethod();
        String endKey = request.getEndClass() + "#" + request.getEndMethod();

        log.info("查找路径: {} -> {}", startKey, endKey);

        // 检查起点是否存在
        boolean startExists = adjacencyList.containsKey(startKey);
        boolean startAsCallee = isCalleeInGraph(callGraph, startKey);
        log.info("起点是否存在: 作为调用者={}, 作为被调用者={}", startExists, startAsCallee);

        // 检查终点是否存在
        boolean endExists = isCalleeInGraph(callGraph, endKey);
        log.info("终点是否存在: {}", endExists);

        // 打印起点调用了哪些方法
        if (startExists) {
            List<MethodCallModel> startCalls = adjacencyList.get(startKey);
            log.info("起点调用了 {} 个方法:", startCalls.size());
            startCalls.stream().limit(10).forEach(call ->
                    log.info("  -> {}#{}", call.getCalleeClass(), call.getCalleeMethod()));
        }

        // 打印谁调用了终点
        log.info("调用终点的方法:");
        callGraph.stream()
                .filter(call -> call.getCalleeKey().equals(endKey))
                .limit(10)
                .forEach(call ->
                        log.info("  {}#{} -> 终点", call.getCallerClass(), call.getCallerMethod()));

        // 打印匹配的方法（模糊匹配）
        if (!startExists || !endExists) {
            log.warn("未找到精确匹配，尝试模糊查找:");
            printMatchingMethods(callGraph, startKey.split("#")[0], startKey.split("#")[1]);
            printMatchingMethods(callGraph, endKey.split("#")[0], endKey.split("#")[1]);
        }

        if (!startExists && !startAsCallee) {
            throw new IllegalArgumentException("起点方法不存在: " + startKey);
        }

        if (!endExists) {
            throw new IllegalArgumentException("终点方法不存在: " + endKey);
        }

        // 4. 构建接口/实现类映射
        Map<String, Set<String>> interfaceToImpl = buildInterfaceImplementationMap(callGraph);
        log.info("接口/实现类映射: {} 个接口", interfaceToImpl.size());

        // 打印与UserService相关的映射
        if (startKey.contains("UserService") || endKey.contains("UserService")) {
            log.info("UserService相关接口映射:");
            interfaceToImpl.entrySet().stream()
                    .filter(e -> e.getKey().contains("UserService") || e.getValue().stream().anyMatch(v -> v.contains("UserService")))
                    .forEach(e -> log.info("  {} -> {}", e.getKey(), e.getValue()));
        }

        // 5. 执行路径搜索
        List<List<CallNode>> paths = new ArrayList<>();
        if (Boolean.TRUE.equals(request.getFindAllPaths())) {
            paths = findAllPaths(adjacencyList, interfaceToImpl, startKey, endKey,
                    request.getMaxDepth(), request.getMaxPaths());
        } else {
            List<CallNode> singlePath = findShortestPath(adjacencyList, interfaceToImpl, startKey, endKey,
                    request.getMaxDepth());
            if (singlePath != null) {
                paths.add(singlePath);
            }
        }

        log.info("找到 {} 条调用路径", paths.size());

        // 5. 构建响应
        return buildResponse(request, paths);
    }

    /**
     * 搜索方法（自动补全）
     *
     * @param artifactId 制品ID
     * @param keyword    关键字
     * @param limit      返回数量限制
     * @return 方法建议列表
     */
    public List<MethodSuggestion> searchMethods(Long artifactId, String keyword, Integer limit) {
        log.info("搜索方法: artifactId={}, keyword={}, limit={}", artifactId, keyword, limit);

        // 获取或构建方法索引
        MethodIndex index = getOrBuildMethodIndex(artifactId);

        log.info("方法索引总大小: {} 个方法", index.size());

        // 执行搜索
        List<MethodSuggestion> results = index.search(keyword, limit != null ? limit : 20);

        log.info("搜索结果: {} 个方法", results.size());
        if (!results.isEmpty()) {
            log.info("前3个结果: {}", results.subList(0, Math.min(3, results.size())));
        }

        return results;
    }

    /**
     * 获取或构建调用图（带缓存）
     * 支持 Spring Boot Fat JAR 和依赖分析
     *
     * @param artifactId 制品ID
     * @return 调用图
     */
    private List<MethodCallModel> getOrBuildCallGraph(Long artifactId) {
        return callGraphCache.computeIfAbsent(artifactId, id -> {
            try {
                Artifact artifact = artifactRepository.findById(id)
                        .orElseThrow(() -> new IllegalArgumentException("制品不存在: " + id));

                log.info("构建调用图: artifactId={}, filePath={}", id, artifact.getFilePath());

                // 扫描依赖（支持 Spring Boot Fat JAR）
                // 调用链路分析默认启用依赖分析，以获取完整的跨模块调用链
                DependencyAnalysisConfig config = DependencyAnalysisConfig.withDependencies(null, null);
                List<JarInfo> jars = dependencyScanner.scanDependencies(artifact.getFilePath(), config);

                log.info("扫描到 {} 个JAR文件（1个主JAR + {}个依赖）", jars.size(), jars.size() - 1);

                // 使用多JAR模式构建调用图
                CallGraphBuilder builder = new CallGraphBuilder(jars);
                List<MethodCallModel> callGraph = builder.build();

                log.info("调用图构建完成: {} 个调用关系", callGraph.size());
                return callGraph;
            } catch (IOException e) {
                log.error("构建调用图失败", e);
                throw new RuntimeException("构建调用图失败: " + e.getMessage(), e);
            }
        });
    }

    /**
     * 构建邻接表（正向调用关系）
     *
     * @param callGraph 调用图
     * @return 邻接表
     */
    private Map<String, List<MethodCallModel>> buildAdjacencyList(List<MethodCallModel> callGraph) {
        Map<String, List<MethodCallModel>> adjacencyList = new HashMap<>();

        for (MethodCallModel call : callGraph) {
            String callerKey = call.getCallerKey();
            adjacencyList.computeIfAbsent(callerKey, k -> new ArrayList<>()).add(call);
        }

        return adjacencyList;
    }

    /**
     * 构建接口/实现类映射关系
     * 从调用图中提取接口与其实现类的关系
     *
     * @param callGraph 调用图
     * @return 接口 -> 实现类集合 的映射
     */
    private Map<String, Set<String>> buildInterfaceImplementationMap(List<MethodCallModel> callGraph) {
        Set<String> classNames = new HashSet<>();
        for (MethodCallModel call : callGraph) {
            classNames.add(call.getCallerClass());
            classNames.add(call.getCalleeClass());
        }
        return interfaceMapper.buildInterfaceToImplMap(classNames);
    }

    /**
     * 检查方法是否作为被调用者存在于调用图中
     *
     * @param callGraph 调用图
     * @param methodKey 方法key（className#methodName）
     * @return 是否存在
     */
    private boolean isCalleeInGraph(List<MethodCallModel> callGraph, String methodKey) {
        return callGraph.stream()
                .anyMatch(call -> call.getCalleeKey().equals(methodKey));
    }

    /**
     * 打印匹配的方法（模糊匹配）
     *
     * @param callGraph  调用图
     * @param className  类名关键字
     * @param methodName 方法名关键字
     */
    private void printMatchingMethods(List<MethodCallModel> callGraph, String className, String methodName) {
        log.warn("查找包含 className='{}', methodName='{}' 的方法:", className, methodName);

        Set<String> matchedMethods = new HashSet<>();
        String lowerClass = className.toLowerCase();
        String lowerMethod = methodName.toLowerCase();

        for (MethodCallModel call : callGraph) {
            // 检查调用者
            if (call.getCallerClass().toLowerCase().contains(lowerClass) &&
                    call.getCallerMethod().toLowerCase().contains(lowerMethod)) {
                matchedMethods.add("调用者: " + call.getCallerKey());
            }
            // 检查被调用者
            if (call.getCalleeClass().toLowerCase().contains(lowerClass) &&
                    call.getCalleeMethod().toLowerCase().contains(lowerMethod)) {
                matchedMethods.add("被调用者: " + call.getCalleeKey());
            }

            // 限制输出数量
            if (matchedMethods.size() >= 10) {
                break;
            }
        }

        if (matchedMethods.isEmpty()) {
            log.warn("  未找到匹配的方法");
        } else {
            matchedMethods.forEach(m -> log.warn("  {}", m));
        }
    }

    /**
     * BFS查找最短路径（支持接口/实现类映射）
     *
     * @param adjacencyList    邻接表
     * @param interfaceToImpl  接口到实现类的映射
     * @param startKey         起点key
     * @param endKey           终点key
     * @param maxDepth         最大深度
     * @return 最短路径节点列表，如果未找到返回null
     */
    private List<CallNode> findShortestPath(
            Map<String, List<MethodCallModel>> adjacencyList,
            Map<String, Set<String>> interfaceToImpl,
            String startKey, String endKey, int maxDepth) {

        // BFS队列：<当前路径>
        Queue<List<CallNode>> queue = new LinkedList<>();
        Set<String> visited = new HashSet<>();

        // 初始节点
        CallNode startNode = parseKeyToNode(startKey);
        queue.offer(List.of(startNode));
        visited.add(startKey);

        while (!queue.isEmpty()) {
            List<CallNode> currentPath = queue.poll();

            // 深度限制
            if (currentPath.size() > maxDepth) {
                continue;
            }

            // 获取当前节点
            CallNode currentNode = currentPath.get(currentPath.size() - 1);
            String currentKey = currentNode.getClassName() + "#" + currentNode.getMethodName();

            // 找到终点
            if (currentKey.equals(endKey)) {
                log.info("找到最短路径，深度: {}", currentPath.size() - 1);
                return currentPath;
            }

            // 获取当前节点的所有可能形式（类本身 + 接口/实现类）
            Set<String> currentKeys = getAllPossibleKeys(currentKey, interfaceToImpl);

            // 调试日志：打印当前节点和所有可能的形式
            if (currentKey.contains("UserService")) {
                log.info("当前节点: {}, 所有可能形式: {}", currentKey, currentKeys);
            }

            // 扩展邻居节点
            for (String key : currentKeys) {
                List<MethodCallModel> calls = adjacencyList.get(key);
                if (calls != null) {
                    // 调试日志
                    if (currentKey.contains("UserService") && calls.stream().anyMatch(c -> c.getCalleeMethod().contains("find"))) {
                        log.info("从 {} 找到 {} 个调用，其中包含find方法", key, calls.size());
                    }

                    for (MethodCallModel call : calls) {
                        String calleeKey = call.getCalleeKey();

                        if (!visited.contains(calleeKey)) {
                            visited.add(calleeKey);

                            CallNode nextNode = new CallNode();
                            nextNode.setClassName(call.getCalleeClass());
                            nextNode.setMethodName(call.getCalleeMethod());
                            nextNode.setDescriptor(call.getCalleeDescriptor());
                            nextNode.setLineNumber(call.getCallLine());
                            nextNode.setJarName(call.getCalleeJar());

                            List<CallNode> newPath = new ArrayList<>(currentPath);
                            newPath.add(nextNode);
                            queue.offer(newPath);
                        }
                    }
                }
            }
        }

        log.info("未找到从 {} 到 {} 的路径", startKey, endKey);
        return null;
    }

    /**
     * 获取节点的所有可能形式（类本身 + 接口对应的实现类 + 实现类对应的接口）
     *
     * @param methodKey       方法key
     * @param interfaceToImpl 接口到实现类的映射
     * @return 所有可能的key
     */
    private Set<String> getAllPossibleKeys(String methodKey, Map<String, Set<String>> interfaceToImpl) {
        Set<String> keys = new HashSet<>();
        keys.add(methodKey);

        String className = methodKey.split("#")[0];
        String methodName = methodKey.contains("#") ? methodKey.substring(methodKey.indexOf("#")) : "";

        // 1. 如果是接口，添加所有实现类
        if (interfaceToImpl.containsKey(className)) {
            for (String implClass : interfaceToImpl.get(className)) {
                keys.add(implClass + methodName);
            }
        }

        // 2. 如果是实现类，添加对应的接口（反向查找）
        for (Map.Entry<String, Set<String>> entry : interfaceToImpl.entrySet()) {
            if (entry.getValue().contains(className)) {
                keys.add(entry.getKey() + methodName);
            }
        }

        return keys;
    }

    /**
     * DFS查找所有路径（带回溯，支持接口/实现类映射）
     *
     * @param adjacencyList    邻接表
     * @param interfaceToImpl  接口到实现类的映射
     * @param startKey         起点key
     * @param endKey           终点key
     * @param maxDepth         最大深度
     * @param maxPaths         最大路径数量
     * @return 所有路径列表
     */
    private List<List<CallNode>> findAllPaths(
            Map<String, List<MethodCallModel>> adjacencyList,
            Map<String, Set<String>> interfaceToImpl,
            String startKey, String endKey, int maxDepth, int maxPaths) {

        List<List<CallNode>> allPaths = new ArrayList<>();

        // DFS搜索所有路径（使用回溯）
        Set<String> currentPath = new HashSet<>();
        List<CallNode> path = new ArrayList<>();

        dfsFindAllPaths(adjacencyList, interfaceToImpl, startKey, endKey, maxDepth, maxPaths,
                currentPath, path, allPaths);

        log.info("DFS找到 {} 条路径", allPaths.size());
        return allPaths;
    }

    /**
     * DFS查找所有路径（回溯算法，支持接口/实现类映射）
     *
     * @param adjacencyList    邻接表
     * @param interfaceToImpl  接口到实现类的映射
     * @param currentKey       当前节点key
     * @param endKey           终点key
     * @param maxDepth         最大深度
     * @param maxPaths         最大路径数量
     * @param currentPath      当前路径集合（用于环路检测）
     * @param path             当前路径列表
     * @param allPaths         所有路径结果
     */
    private void dfsFindAllPaths(
            Map<String, List<MethodCallModel>> adjacencyList,
            Map<String, Set<String>> interfaceToImpl,
            String currentKey, String endKey, int maxDepth, int maxPaths,
            Set<String> currentPath, List<CallNode> path,
            List<List<CallNode>> allPaths) {

        // 已达到最大路径数
        if (allPaths.size() >= maxPaths) {
            return;
        }

        // 深度限制
        if (path.size() > maxDepth) {
            return;
        }

        // 环路检测
        if (currentPath.contains(currentKey)) {
            return;
        }

        // 添加到当前路径
        currentPath.add(currentKey);
        CallNode currentNode = parseKeyToNode(currentKey);
        path.add(currentNode);

        // 找到终点
        if (currentKey.equals(endKey)) {
            allPaths.add(new ArrayList<>(path));
            // 回溯
            currentPath.remove(currentKey);
            path.remove(path.size() - 1);
            return;
        }

        // 获取当前节点的所有可能形式（类本身 + 接口/实现类）
        Set<String> currentKeys = getAllPossibleKeys(currentKey, interfaceToImpl);

        // 扩展邻居节点
        for (String key : currentKeys) {
            List<MethodCallModel> calls = adjacencyList.get(key);
            if (calls != null) {
                for (MethodCallModel call : calls) {
                    String calleeKey = call.getCalleeKey();

                    // 递归搜索
                    dfsFindAllPaths(adjacencyList, interfaceToImpl, calleeKey, endKey, maxDepth, maxPaths,
                            currentPath, path, allPaths);

                    // 已达到最大路径数，提前退出
                    if (allPaths.size() >= maxPaths) {
                        break;
                    }
                }
            }

            if (allPaths.size() >= maxPaths) {
                break;
            }
        }

        // 回溯
        currentPath.remove(currentKey);
        path.remove(path.size() - 1);
    }

    /**
     * 获取或构建方法索引
     *
     * @param artifactId 制品ID
     * @return 方法索引
     */
    private MethodIndex getOrBuildMethodIndex(Long artifactId) {
        return methodIndexCache.computeIfAbsent(artifactId, id -> {
            List<MethodCallModel> callGraph = getOrBuildCallGraph(id);
            return new MethodIndex(callGraph);
        });
    }

    /**
     * 解析方法Key为CallNode
     *
     * @param key 方法key（className#methodName）
     * @return CallNode
     */
    private CallNode parseKeyToNode(String key) {
        String[] parts = key.split("#");
        CallNode node = new CallNode();
        node.setClassName(parts[0]);
        node.setMethodName(parts.length > 1 ? parts[1] : "");
        return node;
    }

    /**
     * 构建响应
     *
     * @param request 请求
     * @param paths   路径列表
     * @return 响应
     */
    private CallPathResponse buildResponse(CallPathRequest request, List<List<CallNode>> paths) {
        CallPathResponse response = new CallPathResponse();
        response.setStartClass(request.getStartClass());
        response.setStartMethod(request.getStartMethod());
        response.setEndClass(request.getEndClass());
        response.setEndMethod(request.getEndMethod());
        response.setTotalPaths(paths.size());

        List<CallPath> callPaths = paths.stream()
                .map(nodes -> {
                    CallPath path = new CallPath();
                    path.setNodes(nodes);
                    path.setDepth(nodes.size() - 1);
                    return path;
                })
                .collect(Collectors.toList());

        response.setPaths(callPaths);
        response.setTruncated(Boolean.TRUE.equals(request.getFindAllPaths())
                && paths.size() >= request.getMaxPaths());

        return response;
    }

    /**
     * 方法索引内部类（用于自动补全）
     */
    private static class MethodIndex {
        private final List<MethodSuggestion> allMethods;

        public MethodIndex(List<MethodCallModel> callGraph) {
            // 从调用图中提取所有唯一的方法
            Set<String> methodKeys = new HashSet<>();
            this.allMethods = new ArrayList<>();

            for (MethodCallModel call : callGraph) {
                // 添加调用者方法
                addMethodIfNew(call.getCallerClass(), call.getCallerMethod(),
                        call.getCallerDescriptor(), methodKeys);

                // 添加被调用者方法
                addMethodIfNew(call.getCalleeClass(), call.getCalleeMethod(),
                        call.getCalleeDescriptor(), methodKeys);
            }

            log.info("MethodIndex构建完成: 从 {} 个调用关系中提取了 {} 个唯一方法",
                    callGraph.size(), allMethods.size());

            // 打印前10个方法样本，用于调试
            if (!allMethods.isEmpty()) {
                log.info("前10个方法样本:");
                for (int i = 0; i < Math.min(10, allMethods.size()); i++) {
                    MethodSuggestion m = allMethods.get(i);
                    log.info("  [{}] {}#{} -> displayName={}",
                            i, m.getClassName(), m.getMethodName(), m.getDisplayName());
                }
            }
        }

        private void addMethodIfNew(String className, String methodName,
                                    String descriptor, Set<String> methodKeys) {
            String key = className + "#" + methodName;
            if (!methodKeys.contains(key)) {
                methodKeys.add(key);

                MethodSuggestion suggestion = new MethodSuggestion();
                suggestion.setClassName(className);
                suggestion.setSimpleClassName(getSimpleClassName(className));
                suggestion.setMethodName(methodName);
                suggestion.setDescriptor(descriptor);
                suggestion.setDisplayName(suggestion.getSimpleClassName() + "." + methodName + "()");

                allMethods.add(suggestion);
            }
        }

        /**
         * 获取方法总数
         */
        public int size() {
            return allMethods.size();
        }

        /**
         * 关键字搜索（支持多关键字，用空格或点号分隔）
         * 例如：
         * - "user" 匹配包含user的类名或方法名
         * - "userapi getuser" 同时匹配UserApi类和getUser方法
         * - "userapi.getuser" 同上（点号会自动拆分）
         *
         * @param keyword 关键字
         * @param limit   返回数量限制
         * @return 匹配的方法建议列表
         */
        public List<MethodSuggestion> search(String keyword, int limit) {
            // 将关键字按空格或点号分割成多个关键字
            String[] keywords = keyword.toLowerCase().split("[\\s.]+");

            // 过滤掉空关键字
            List<String> validKeywords = Arrays.stream(keywords)
                    .filter(k -> !k.isEmpty())
                    .collect(Collectors.toList());

            if (validKeywords.isEmpty()) {
                return new ArrayList<>();
            }

            log.info("搜索关键字: {}, 拆分为: {}", keyword, validKeywords);

            // 所有关键字都必须匹配（AND逻辑）
            List<MethodSuggestion> results = allMethods.stream()
                    .filter(m -> {
                        String className = m.getClassName().toLowerCase();
                        String simpleClassName = m.getSimpleClassName().toLowerCase();
                        String methodName = m.getMethodName().toLowerCase();

                        // 每个关键字都要匹配至少一个字段
                        return validKeywords.stream().allMatch(kw ->
                                className.contains(kw) ||
                                simpleClassName.contains(kw) ||
                                methodName.contains(kw)
                        );
                    })
                    .limit(limit)
                    .collect(Collectors.toList());

            log.info("搜索结果: {} 个匹配", results.size());

            // 如果没有结果，打印前几个方法帮助调试
            if (results.isEmpty() && !allMethods.isEmpty()) {
                log.warn("未找到匹配的方法，前5个方法样本:");
                for (int i = 0; i < Math.min(5, allMethods.size()); i++) {
                    MethodSuggestion m = allMethods.get(i);
                    log.warn("  [{}] className='{}', simpleClassName='{}', methodName='{}'",
                            i, m.getClassName(), m.getSimpleClassName(), m.getMethodName());
                }
            }

            return results;
        }

        private String getSimpleClassName(String className) {
            int lastDot = className.lastIndexOf('.');
            return lastDot >= 0 ? className.substring(lastDot + 1) : className;
        }
    }
}