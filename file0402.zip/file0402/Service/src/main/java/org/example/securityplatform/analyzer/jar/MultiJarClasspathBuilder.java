package org.example.securityplatform.analyzer.jar;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 多JAR类路径构建器 - 合并主JAR和依赖JAR的类文件，构建统一类路径
 */
@Slf4j
public class MultiJarClasspathBuilder {

    private final List<JarInfo> jars;

    /**
     * 类路径映射：class文件路径 -> 类位置信息
     */
    private final Map<String, ClassLocation> classMap = new LinkedHashMap<>();

    public MultiJarClasspathBuilder(List<JarInfo> jars) {
        this.jars = jars;
        buildClasspath();
    }

    /**
     * 构建类路径索引
     */
    private void buildClasspath() {
        log.info("Building classpath from {} JARs", jars.size());

        int priority = 0;
        for (JarInfo jar : jars) {
            addJar(jar, priority++);
        }

        // 统计信息
        long mainClasses = classMap.values().stream()
                .filter(loc -> loc.getJar().isMain()).count();
        long depClasses = classMap.size() - mainClasses;

        log.info("Classpath built: {} total classes ({} from main JAR, {} from dependencies)",
                classMap.size(), mainClasses, depClasses);
    }

    /**
     * 添加单个JAR的类到类路径
     */
    private void addJar(JarInfo jar, int priority) {
        try (JarFile jarFile = new JarFile(jar.getJarPath())) {
            Enumeration<JarEntry> entries = jarFile.entries();
            int added = 0;

            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();

                if (name.endsWith(".class") && !entry.isDirectory()) {
                    // 规范化类路径（处理BOOT-INF/classes前缀）
                    String normalizedPath = normalizeClassPath(name);

                    ClassLocation existing = classMap.get(normalizedPath);

                    if (existing != null) {
                        // 类冲突：优先级低的JAR中的类会被忽略
                        if (priority < existing.getPriority()) {
                            log.warn("Class conflict: {} found in {} (priority {}) and {} (priority {}). " +
                                            "Using higher priority JAR: {}",
                                    normalizedPath, existing.getJar().getName(), existing.getPriority(),
                                    jar.getName(), priority, existing.getJar().getName());
                            classMap.put(normalizedPath,
                                    new ClassLocation(jar, priority, entry, normalizedPath));
                        } else {
                            log.debug("Class conflict: {} in {} ignored (lower priority than {})",
                                    normalizedPath, jar.getName(), existing.getJar().getName());
                        }
                    } else {
                        classMap.put(normalizedPath,
                                new ClassLocation(jar, priority, entry, normalizedPath));
                        added++;
                    }
                }
            }

            log.info("  Added {} classes from {} (priority {})",
                    added, jar.getShortName(), priority);

        } catch (IOException e) {
            log.error("Failed to read JAR: {}", jar.getJarPath(), e);
        }
    }

    /**
     * 规范化类路径 - 处理Spring Boot Fat JAR结构
     */
    private String normalizeClassPath(String path) {
        // BOOT-INF/classes/org/example/User.class -> org/example/User.class
        if (path.startsWith("BOOT-INF/classes/")) {
            return path.substring("BOOT-INF/classes/".length());
        }
        // WEB-INF/classes/org/example/User.class -> org/example/User.class
        if (path.startsWith("WEB-INF/classes/")) {
            return path.substring("WEB-INF/classes/".length());
        }
        return path;
    }

    /**
     * 获取所有类路径
     */
    public Set<String> getAllClassPaths() {
        return Collections.unmodifiableSet(classMap.keySet());
    }

    /**
     * 获取类位置信息
     */
    public ClassLocation getClassLocation(String classPath) {
        return classMap.get(classPath);
    }

    /**
     * 获取类的输入流
     * 返回的InputStream会自动关闭关联的JarFile
     */
    public InputStream getClassInputStream(String classPath) throws IOException {
        ClassLocation location = classMap.get(classPath);
        if (location == null) {
            return null;
        }

        JarFile jarFile = new JarFile(location.getJar().getJarPath());
        InputStream entryStream = jarFile.getInputStream(location.getEntry());
        return new JarFileInputStream(jarFile, entryStream);
    }

    /**
     * 包装InputStream，在关闭时同时关闭关联的JarFile
     */
    private static class JarFileInputStream extends InputStream {
        private final JarFile jarFile;
        private final InputStream delegate;
        private boolean closed = false;

        public JarFileInputStream(JarFile jarFile, InputStream delegate) {
            this.jarFile = jarFile;
            this.delegate = delegate;
        }

        @Override
        public int read() throws IOException {
            return delegate.read();
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            return delegate.read(b, off, len);
        }

        @Override
        public void close() throws IOException {
            if (!closed) {
                closed = true;
                try {
                    delegate.close();
                } finally {
                    jarFile.close();
                }
            }
        }

        @Override
        public int available() throws IOException {
            return delegate.available();
        }
    }

    /**
     * 获取类路径映射
     */
    public Map<String, ClassLocation> getClassMap() {
        return Collections.unmodifiableMap(classMap);
    }

    /**
     * 按JAR分组统计类数量
     */
    public Map<String, Integer> getClassesByJar() {
        Map<String, Integer> stats = new LinkedHashMap<>();
        for (ClassLocation loc : classMap.values()) {
            String jarName = loc.getJar().getShortName();
            stats.merge(jarName, 1, Integer::sum);
        }
        return stats;
    }

    /**
     * 类位置信息
     */
    @Data
    @AllArgsConstructor
    public static class ClassLocation {
        /**
         * 来源JAR
         */
        private JarInfo jar;

        /**
         * 优先级（数字越小优先级越高）
         */
        private int priority;

        /**
         * JAR条目
         */
        private JarEntry entry;

        /**
         * 规范化后的类路径
         */
        private String normalizedPath;
    }
}
