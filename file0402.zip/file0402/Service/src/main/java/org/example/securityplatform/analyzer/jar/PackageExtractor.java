package org.example.securityplatform.analyzer.jar;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 包名提取器
 * 统一从类路径中提取包名
 */
public class PackageExtractor {

    /**
     * 从类路径提取包名
     * 例如: com/example/module/service/MyService.class -> com.example.module.service
     *
     * @param classPath 类路径
     * @return 包名
     */
    public String extractPackageName(String classPath) {
        if (classPath == null || classPath.isEmpty()) {
            return null;
        }

        // 移除.class后缀
        String path = classPath;
        if (path.endsWith(".class")) {
            path = path.substring(0, path.length() - 6);
        }

        // 移除BOOT-INF/classes/前缀
        if (path.startsWith("BOOT-INF/classes/")) {
            path = path.substring("BOOT-INF/classes/".length());
        }

        // 移除WEB-INF/classes/前缀
        if (path.startsWith("WEB-INF/classes/")) {
            path = path.substring("WEB-INF/classes/".length());
        }

        // 找到最后一个斜杠的位置，提取包路径
        int lastSlash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        if (lastSlash > 0) {
            String packagePath = path.substring(0, lastSlash);
            return packagePath.replace('/', '.').replace('\\', '.');
        }

        return null;
    }

    /**
     * 从类路径列表提取业务包名列表（去重）
     *
     * @param classPaths 类路径列表
     * @param filter     框架包过滤器
     * @return 去重后的业务包名列表
     */
    public List<String> extractBusinessPackages(Collection<String> classPaths, FrameworkPackageFilter filter) {
        return classPaths.stream()
                .filter(path -> path.endsWith(".class"))
                .filter(path -> !filter.isFrameworkPackage(path))
                .map(this::extractPackageName)
                .filter(Objects::nonNull)
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }

    /**
     * 从类路径提取简单类名
     * 例如: com/example/service/MyService.class -> MyService
     *
     * @param classPath 类路径
     * @return 简单类名
     */
    public String extractSimpleClassName(String classPath) {
        if (classPath == null || classPath.isEmpty()) {
            return null;
        }

        String path = classPath;
        if (path.endsWith(".class")) {
            path = path.substring(0, path.length() - 6);
        }

        int lastSlash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        if (lastSlash >= 0) {
            return path.substring(lastSlash + 1);
        }

        return path;
    }

    /**
     * 从类路径提取完整类名
     * 例如: com/example/service/MyService.class -> com.example.service.MyService
     *
     * @param classPath 类路径
     * @return 完整类名
     */
    public String extractFullClassName(String classPath) {
        if (classPath == null || classPath.isEmpty()) {
            return null;
        }

        String path = classPath;
        if (path.endsWith(".class")) {
            path = path.substring(0, path.length() - 6);
        }

        return path.replace('/', '.').replace('\\', '.');
    }
}
