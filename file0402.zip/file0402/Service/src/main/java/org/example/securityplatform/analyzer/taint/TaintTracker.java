package org.example.securityplatform.analyzer.taint;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.core.InterfaceMapper;
import org.example.securityplatform.analyzer.diff.CallGraphBuilder;
import org.example.securityplatform.analyzer.diff.MethodCallModel;
import org.example.securityplatform.analyzer.jar.JarInfo;
import org.example.securityplatform.analyzer.jar.MultiJarClasspathBuilder;
import org.example.securityplatform.entity.TaintPath;
import org.example.securityplatform.entity.TaintSink;
import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 污点追踪器
 * 基于调用图进行数据流分析，追踪从污点源到Sink的传播路径
 */
@Slf4j
public class TaintTracker {

    private static final int MAX_TRACE_DEPTH = 20; // 最大追踪深度，防止无限循环

    private static final Set<String> CONTROLLER_ANNOTATIONS = Set.of(
            "Lorg/springframework/web/bind/annotation/RequestMapping;",
            "Lorg/springframework/web/bind/annotation/GetMapping;",
            "Lorg/springframework/web/bind/annotation/PostMapping;",
            "Lorg/springframework/web/bind/annotation/PutMapping;",
            "Lorg/springframework/web/bind/annotation/DeleteMapping;",
            "Lorg/springframework/web/bind/annotation/PatchMapping;",
            "Ljavax/ws/rs/Path;",
            "Ljakarta/ws/rs/Path;"
    );

    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 存储类是否为Controller的缓存
     */
    private final Map<String, Boolean> controllerClassCache = new HashMap<>();

    /**
     * 存储带有HTTP方法注解的方法集合
     */
    private final Set<String> controllerMethods = new HashSet<>();

    /** 接口映射器 */
    private final InterfaceMapper interfaceMapper = new InterfaceMapper();

    /**
     * 对所有Sink点执行污点追踪（单JAR模式）
     *
     * @param sinks     Sink点列表
     * @param jarPath   JAR包路径（用于识别Controller）
     * @param callGraph 调用图
     * @return 污点路径列表
     */
    public List<TaintPath> traceAll(List<TaintSink> sinks, String jarPath, List<MethodCallModel> callGraph) throws IOException {
        List<JarInfo> jars = Collections.singletonList(new JarInfo(jarPath, JarInfo.JarType.MAIN, "MAIN"));
        return traceAllMultiJar(sinks, jars, callGraph);
    }

    /**
     * 对所有Sink点执行污点追踪（多JAR模式）
     *
     * @param sinks     Sink点列表
     * @param jars      JAR信息列表
     * @param callGraph 调用图
     * @return 污点路径列表
     */
    public List<TaintPath> traceAllMultiJar(List<TaintSink> sinks, List<JarInfo> jars, List<MethodCallModel> callGraph) throws IOException {
        List<TaintPath> paths = new ArrayList<>();

        // 预先扫描所有JAR包识别Controller类和方法
        scanControllerClassesMultiJar(jars);
        log.info("识别到 {} 个Controller方法", controllerMethods.size());

        // 构建反向调用图（被调用者 -> 调用者列表）
        Map<String, List<MethodCallModel>> reverseCallGraph = buildReverseCallGraph(callGraph);
        log.info("构建反向调用图完成，包含 {} 个方法节点", reverseCallGraph.size());

        // 对每个Sink进行追踪
        for (TaintSink sink : sinks) {
            List<TaintPath> sinkPaths = traceSink(sink, reverseCallGraph);
            paths.addAll(sinkPaths);
        }

        log.info("污点追踪完成，共追踪到 {} 条路径", paths.size());
        return paths;
    }

    /**
     * 扫描JAR包识别Controller类和方法（单JAR模式）
     */
    private void scanControllerClasses(String jarPath) throws IOException {
        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> entries = jarFile.entries();

            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (entry.getName().endsWith(".class") && !entry.isDirectory()) {
                    try (InputStream is = jarFile.getInputStream(entry)) {
                        ClassReader reader = new ClassReader(is);
                        ControllerScanVisitor visitor = new ControllerScanVisitor();
                        reader.accept(visitor, ClassReader.SKIP_DEBUG | ClassReader.SKIP_CODE | ClassReader.SKIP_FRAMES);
                    } catch (Exception e) {
                        log.debug("扫描Controller时解析class文件失败: {}", entry.getName());
                    }
                }
            }
        }
    }

    /**
     * 扫描多个JAR包识别Controller类和方法（多JAR模式）
     */
    private void scanControllerClassesMultiJar(List<JarInfo> jars) throws IOException {
        MultiJarClasspathBuilder classpathBuilder = new MultiJarClasspathBuilder(jars);

        for (String classPath : classpathBuilder.getAllClassPaths()) {
            MultiJarClasspathBuilder.ClassLocation location = classpathBuilder.getClassLocation(classPath);
            if (location == null) {
                continue;
            }

            try (JarFile jarFile = new JarFile(location.getJar().getJarPath());
                 InputStream is = jarFile.getInputStream(location.getEntry())) {

                ClassReader reader = new ClassReader(is);
                ControllerScanVisitor visitor = new ControllerScanVisitor();
                reader.accept(visitor, ClassReader.SKIP_DEBUG | ClassReader.SKIP_CODE | ClassReader.SKIP_FRAMES);

            } catch (Exception e) {
                log.debug("扫描Controller时解析class文件失败: {}", classPath);
            }
        }
    }

    /**
     * 构建反向调用图
     */
    private Map<String, List<MethodCallModel>> buildReverseCallGraph(List<MethodCallModel> callGraph) {
        Map<String, List<MethodCallModel>> reverseGraph = new HashMap<>();

        for (MethodCallModel call : callGraph) {
            String calleeKey = call.getCalleeKey();
            reverseGraph.computeIfAbsent(calleeKey, k -> new ArrayList<>()).add(call);
        }

        return reverseGraph;
    }

    /**
     * 从反向调用图中查找调用者
     * 使用InterfaceMapper统一处理接口/实现类映射
     */
    private List<MethodCallModel> findCallers(String methodKey, Map<String, List<MethodCallModel>> reverseCallGraph) {
        // 先尝试精确匹配
        List<MethodCallModel> callers = reverseCallGraph.get(methodKey);
        if (callers != null) {
            return callers;
        }

        // 通过接口映射查找（从反向调用图中提取类名集合）
        Set<String> classNames = new HashSet<>();
        for (List<MethodCallModel> edges : reverseCallGraph.values()) {
            for (MethodCallModel edge : edges) {
                String callerKey = edge.getCallerKey();
                int idx = callerKey.indexOf('#');
                if (idx > 0) {
                    classNames.add(callerKey.substring(0, idx));
                }
            }
        }

        List<String> interfaceKeys = interfaceMapper.findInterfaceMethodKeys(methodKey, classNames);
        for (String interfaceKey : interfaceKeys) {
            callers = reverseCallGraph.get(interfaceKey);
            if (callers != null) {
                log.info("通过接口映射找到调用者: {} -> {}", methodKey, interfaceKey);
                return callers;
            }
        }

        return null;
    }

    /**
     * 对单个Sink进行污点追踪
     */
    private List<TaintPath> traceSink(TaintSink sink, Map<String, List<MethodCallModel>> reverseCallGraph) {
        List<TaintPath> paths = new ArrayList<>();

        String sinkMethodKey = sink.getSinkClass() + "#" + sink.getSinkMethod();
        log.info("开始追踪Sink点: {}, sinkClass={}, sinkMethod={}", sinkMethodKey, sink.getSinkClass(), sink.getSinkMethod());

        // 调试：检查反向调用图中是否有该Sink点
        List<MethodCallModel> initialCallers = findCallers(sinkMethodKey, reverseCallGraph);
        if (initialCallers == null || initialCallers.isEmpty()) {
            log.warn("反向调用图中未找到Sink点: {}", sinkMethodKey);
            // 调试：打印所有可用的key（前10个）
            log.info("反向调用图中的方法节点（前10个）: {}",
                reverseCallGraph.keySet().stream().limit(10).collect(java.util.stream.Collectors.toList()));
        } else {
            log.info("找到Sink点的调用者数量: {}", initialCallers.size());
        }

        // BFS向上追溯
        Queue<TraceState> queue = new LinkedList<>();
        Set<String> visited = new HashSet<>();

        // 初始状态：从Sink点开始
        queue.offer(new TraceState(sinkMethodKey, new ArrayList<>()));

        int stepCount = 0;
        while (!queue.isEmpty()) {
            TraceState state = queue.poll();
            stepCount++;

            if (stepCount <= 10) {  // 只打印前10步的详细信息
                log.info("追踪步骤 {}: methodKey={}, callChain.size={}", stepCount, state.methodKey, state.callChain.size());
            }

            if (visited.contains(state.methodKey)) {
                if (stepCount <= 10) {
                    log.info("  跳过已访问节点");
                }
                continue;
            }
            visited.add(state.methodKey);

            // 检查深度限制
            if (state.callChain.size() >= MAX_TRACE_DEPTH) {
                if (stepCount <= 10) {
                    log.info("  达到最大深度限制: {}", MAX_TRACE_DEPTH);
                }
                continue;
            }

            // 检查是否是Controller方法
            if (isControllerMethod(state.methodKey)) {
                if (stepCount <= 10) {
                    log.info("  找到Controller方法: {}", state.methodKey);
                }
                // 找到污点源，创建路径
                TaintPath path = createPath(sink, state);
                if (path != null) {
                    paths.add(path);
                }
                continue;
            } else if (stepCount <= 10) {
                log.info("  不是Controller方法，继续向上追溯");
            }

            // 继续向上追溯
            List<MethodCallModel> callers = findCallers(state.methodKey, reverseCallGraph);
            if (callers != null) {
                if (stepCount <= 10) {
                    log.info("  找到 {} 个调用者", callers.size());
                    for (MethodCallModel caller : callers) {
                        log.info("    调用者: {}", caller.getCallerKey());
                    }
                }
                for (MethodCallModel caller : callers) {
                    List<CallChainNode> newChain = new ArrayList<>(state.callChain);
                    newChain.add(0, new CallChainNode(
                            caller.getCallerClass(),
                            caller.getCallerMethod(),
                            caller.getCallLine()
                    ));

                    queue.offer(new TraceState(caller.getCallerKey(), newChain));
                }
            } else if (stepCount <= 10) {
                log.info("  未找到调用者，终止追踪");
            }
        }

        // 如果没有找到Controller，标记为不可达
        if (paths.isEmpty()) {
            log.debug("Sink点 {} 无法追溯到Controller", sinkMethodKey);
        }

        return paths;
    }

    /**
     * 检查方法是否是Controller方法
     */
    private boolean isControllerMethod(String methodKey) {
        return controllerMethods.contains(methodKey);
    }

    /**
     * 创建污点路径实体
     */
    private TaintPath createPath(TaintSink sink, TraceState state) {
        TaintPath path = new TaintPath();
        path.setSinkId(sink.getId());

        // 从调用链中提取Controller信息
        if (!state.callChain.isEmpty()) {
            CallChainNode sourceNode = state.callChain.get(0);
            path.setSourceClass(sourceNode.className);
            path.setSourceMethod(sourceNode.methodName);
        }

        path.setDepth(state.callChain.size());
        path.setIsReachable(true);

        // 序列化调用链
        try {
            path.setCallChain(objectMapper.writeValueAsString(state.callChain));
        } catch (JsonProcessingException e) {
            log.warn("序列化调用链失败", e);
        }

        return path;
    }

    /**
     * 追踪状态
     */
    private static class TraceState {
        String methodKey;
        List<CallChainNode> callChain;

        TraceState(String methodKey, List<CallChainNode> callChain) {
            this.methodKey = methodKey;
            this.callChain = callChain;
        }
    }

    /**
     * 调用链节点
     */
    public static class CallChainNode {
        public String className;
        public String methodName;
        public Integer lineNumber;

        public CallChainNode() {}

        public CallChainNode(String className, String methodName, Integer lineNumber) {
            this.className = className;
            this.methodName = methodName;
            this.lineNumber = lineNumber;
        }

        public String getClassName() { return className; }
        public void setClassName(String className) { this.className = className; }
        public String getMethodName() { return methodName; }
        public void setMethodName(String methodName) { this.methodName = methodName; }
        public Integer getLineNumber() { return lineNumber; }
        public void setLineNumber(Integer lineNumber) { this.lineNumber = lineNumber; }
    }

    /**
     * ASM Visitor - 扫描Controller类和方法
     */
    private class ControllerScanVisitor extends ClassVisitor {
        private String className;
        private boolean isControllerClass = false;

        public ControllerScanVisitor() {
            super(Opcodes.ASM9);
        }

        @Override
        public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
            this.className = name.replace('/', '.');
            super.visit(version, access, name, signature, superName, interfaces);
        }

        @Override
        public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
            // 检查类级别的Controller注解
            if (CONTROLLER_ANNOTATIONS.contains(descriptor)) {
                isControllerClass = true;
            }
            // 检查@RestController和@Controller注解
            if ("Lorg/springframework/web/bind/annotation/RestController;".equals(descriptor) ||
                    "Lorg/springframework/stereotype/Controller;".equals(descriptor)) {
                isControllerClass = true;
            }
            return super.visitAnnotation(descriptor, visible);
        }

        @Override
        public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
            return new MethodScanVisitor(className, isControllerClass, name);
        }
    }

    /**
     * ASM MethodVisitor - 扫描方法上的HTTP方法注解
     */
    private class MethodScanVisitor extends MethodVisitor {
        private final String className;
        private final boolean isControllerClass;
        private final String methodName;

        public MethodScanVisitor(String className, boolean isControllerClass, String methodName) {
            super(Opcodes.ASM9);
            this.className = className;
            this.isControllerClass = isControllerClass;
            this.methodName = methodName;
        }

        @Override
        public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
            // 检查方法级别的HTTP方法注解
            if (CONTROLLER_ANNOTATIONS.contains(descriptor)) {
                String methodKey = className + "#" + methodName;
                controllerMethods.add(methodKey);
            }
            return super.visitAnnotation(descriptor, visible);
        }
    }
}