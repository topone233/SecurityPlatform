package org.example.securityplatform.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.securityplatform.dto.ApiDiffSummary;
import org.example.securityplatform.dto.DiffAnalysisResultResponse;
import org.example.securityplatform.dto.FileDiffSummary;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 差异分析报告导出服务
 */
@Slf4j
@Service
public class DiffReportExporter {

    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 导出Excel报告
     */
    public byte[] exportToExcel(DiffAnalysisResultResponse result) throws IOException {
        log.info("开始导出差异分析报告: diffTaskId={}", result.getDiffTaskId());

        try (XSSFWorkbook workbook = new XSSFWorkbook();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            // 创建概览Sheet
            createSummarySheet(workbook, result);

            // 创建文件差异Sheet
            createFileDiffSheet(workbook, result.getFileDiffs());

            // 创建API变更Sheet
            createApiDiffSheet(workbook, result.getApiDiffs());

            workbook.write(out);
            log.info("差异分析报告导出完成: size={} bytes", out.size());
            return out.toByteArray();
        }
    }

    /**
     * 创建概览Sheet
     */
    private void createSummarySheet(XSSFWorkbook workbook, DiffAnalysisResultResponse result) {
        Sheet sheet = workbook.createSheet("概览");

        // 标题样式
        CellStyle titleStyle = workbook.createCellStyle();
        titleStyle.setFont(workbook.createFont());

        // 表头样式
        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setFont(workbook.createFont());
        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        int rowNum = 0;

        // 标题
        Row titleRow = sheet.createRow(rowNum++);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue("差异分析报告");
        titleCell.setCellStyle(titleStyle);

        rowNum++; // 空行

        // 基本信息
        Row infoRow = sheet.createRow(rowNum++);
        infoRow.createCell(0).setCellValue("分析任务ID:");
        infoRow.createCell(1).setCellValue(result.getDiffTaskId());

        infoRow = sheet.createRow(rowNum++);
        infoRow.createCell(0).setCellValue("导出时间:");
        infoRow.createCell(1).setCellValue(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

        infoRow = sheet.createRow(rowNum++);
        infoRow.createCell(0).setCellValue("状态:");
        infoRow.createCell(1).setCellValue(result.getStatus());

        if (result.getBaseline() != null) {
            infoRow = sheet.createRow(rowNum++);
            infoRow.createCell(0).setCellValue("基线制品:");
            infoRow.createCell(1).setCellValue(result.getBaseline().getArtifactName());
        }

        if (result.getTarget() != null) {
            infoRow = sheet.createRow(rowNum++);
            infoRow.createCell(0).setCellValue("目标制品:");
            infoRow.createCell(1).setCellValue(result.getTarget().getArtifactName());
        }

        rowNum += 2; // 空行

        // 差异统计
        Row statsTitleRow = sheet.createRow(rowNum++);
        Cell statsTitleCell = statsTitleRow.createCell(0);
        statsTitleCell.setCellValue("差异统计");
        statsTitleCell.setCellStyle(headerStyle);

        if (result.getSummary() != null) {
            DiffAnalysisResultResponse.DiffSummary summary = result.getSummary();

            Row statsRow = sheet.createRow(rowNum++);
            statsRow.createCell(0).setCellValue("新增文件:");
            statsRow.createCell(1).setCellValue(summary.getAddedFiles());

            statsRow = sheet.createRow(rowNum++);
            statsRow.createCell(0).setCellValue("修改文件:");
            statsRow.createCell(1).setCellValue(summary.getModifiedFiles());

            statsRow = sheet.createRow(rowNum++);
            statsRow.createCell(0).setCellValue("删除文件:");
            statsRow.createCell(1).setCellValue(summary.getDeletedFiles());

            statsRow = sheet.createRow(rowNum++);
            statsRow.createCell(0).setCellValue("新增API:");
            statsRow.createCell(1).setCellValue(summary.getNewApis());

            statsRow = sheet.createRow(rowNum++);
            statsRow.createCell(0).setCellValue("修改API:");
            statsRow.createCell(1).setCellValue(summary.getModifiedApis());

            statsRow = sheet.createRow(rowNum++);
            statsRow.createCell(0).setCellValue("受影响API:");
            statsRow.createCell(1).setCellValue(summary.getAffectedApis());

            statsRow = sheet.createRow(rowNum++);
            statsRow.createCell(0).setCellValue("删除API:");
            statsRow.createCell(1).setCellValue(summary.getDeletedApis());

            statsRow = sheet.createRow(rowNum++);
            statsRow.createCell(0).setCellValue("高危API:");
            statsRow.createCell(1).setCellValue(summary.getHighRiskApis());

            statsRow = sheet.createRow(rowNum++);
            statsRow.createCell(0).setCellValue("中危API:");
            statsRow.createCell(1).setCellValue(summary.getMediumRiskApis());

            statsRow = sheet.createRow(rowNum++);
            statsRow.createCell(0).setCellValue("低危API:");
            statsRow.createCell(1).setCellValue(summary.getLowRiskApis());
        }

        // 自动调整列宽
        sheet.autoSizeColumn(0);
        sheet.autoSizeColumn(1);
    }

    /**
     * 创建文件差异Sheet
     */
    private void createFileDiffSheet(XSSFWorkbook workbook, List<FileDiffSummary> fileDiffs) {
        Sheet sheet = workbook.createSheet("文件差异");

        // 表头
        Row headerRow = sheet.createRow(0);
        String[] headers = {"文件路径", "源文件路径", "变更类型", "基线行数", "目标行数", "新增行数", "删除行数", "新增方法", "删除方法", "修改方法"};
        for (int i = 0; i < headers.length; i++) {
            headerRow.createCell(i).setCellValue(headers[i]);
        }

        // 数据
        if (fileDiffs != null) {
            int rowNum = 1;
            for (FileDiffSummary diff : fileDiffs) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(diff.getFilePath());
                row.createCell(1).setCellValue(diff.getSourceFilePath() != null ? diff.getSourceFilePath() : "");
                row.createCell(2).setCellValue(diff.getDiffType());
                row.createCell(3).setCellValue(diff.getBaselineLines() != null ? diff.getBaselineLines() : 0);
                row.createCell(4).setCellValue(diff.getTargetLines() != null ? diff.getTargetLines() : 0);
                row.createCell(5).setCellValue(diff.getAddedLines() != null ? diff.getAddedLines() : 0);
                row.createCell(6).setCellValue(diff.getDeletedLines() != null ? diff.getDeletedLines() : 0);
                row.createCell(7).setCellValue(diff.getMethodsAdded() != null ? diff.getMethodsAdded() : 0);
                row.createCell(8).setCellValue(diff.getMethodsDeleted() != null ? diff.getMethodsDeleted() : 0);
                row.createCell(9).setCellValue(diff.getMethodsModified() != null ? diff.getMethodsModified() : 0);
            }
        }

        // 自动调整列宽
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }
    }

    /**
     * 创建API变更Sheet
     */
    private void createApiDiffSheet(XSSFWorkbook workbook, List<ApiDiffSummary> apiDiffs) {
        Sheet sheet = workbook.createSheet("API变更");

        // 表头
        Row headerRow = sheet.createRow(0);
        String[] headers = {"API路径", "HTTP方法", "控制器", "方法名", "变更类型", "变更原因", "风险等级", "调用链"};
        for (int i = 0; i < headers.length; i++) {
            headerRow.createCell(i).setCellValue(headers[i]);
        }

        // 数据
        if (apiDiffs != null) {
            int rowNum = 1;
            for (ApiDiffSummary diff : apiDiffs) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(diff.getApiUrl());
                row.createCell(1).setCellValue(diff.getHttpMethod());
                row.createCell(2).setCellValue(diff.getControllerClass() != null ? diff.getControllerClass() : "");
                row.createCell(3).setCellValue(diff.getMethodName() != null ? diff.getMethodName() : "");
                row.createCell(4).setCellValue(diff.getChangeType());
                row.createCell(5).setCellValue(diff.getChangeReason() != null ? diff.getChangeReason() : "");
                row.createCell(6).setCellValue(diff.getRiskLevel() != null ? diff.getRiskLevel() : "");

                // 调用链
                String callChainStr = formatCallChain(diff.getCallChain());
                row.createCell(7).setCellValue(callChainStr);
            }
        }

        // 自动调整列宽
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }
    }

    /**
     * 格式化调用链
     */
    private String formatCallChain(List<ApiDiffSummary.CallChainNode> callChain) {
        if (callChain == null || callChain.isEmpty()) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < callChain.size(); i++) {
            ApiDiffSummary.CallChainNode node = callChain.get(i);
            if (i > 0) {
                sb.append(" -> ");
            }
            sb.append(node.getClassName()).append(".").append(node.getMethodName());
        }
        return sb.toString();
    }

    /**
     * 生成文件名
     */
    public String generateFileName(Long diffTaskId) {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        return "diff_analysis_" + diffTaskId + "_" + timestamp + ".xlsx";
    }
}