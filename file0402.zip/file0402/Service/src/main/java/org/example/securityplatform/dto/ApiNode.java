package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * API节点DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApiNode {
    private Long id;
    private String apiUrl;
    private String httpMethod;
    private String controllerClass;
    private String methodName;
    private String changeType; // NEW_API | MODIFIED_API | DELETED_API | AFFECTED_API
    private String riskLevel; // HIGH | MEDIUM | LOW
}