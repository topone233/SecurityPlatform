package org.example.securityplatform.analyzer.jar;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * 依赖分析配置
 */
@Data
public class DependencyAnalysisConfig {
    /**
     * 是否分析依赖JAR包
     */
    private boolean analyzeDependencies = false;

    /**
     * 包含的包名模式列表
     * 例如：["com.mycompany.*", "org.myapp.*"]
     */
    private List<String> includePackages = new ArrayList<>();

    /**
     * 包含的JAR名称模式列表
     * 例如：["myproject-*", "*-service-*"]
     */
    private List<String> includeJarNames = new ArrayList<>();

    /**
     * 是否有包名过滤规则
     */
    public boolean hasPackagePatterns() {
        return includePackages != null && !includePackages.isEmpty();
    }

    /**
     * 是否有JAR名称过滤规则
     */
    public boolean hasJarNamePatterns() {
        return includeJarNames != null && !includeJarNames.isEmpty();
    }

    /**
     * 是否有任何过滤规则
     */
    public boolean hasAnyFilters() {
        return hasPackagePatterns() || hasJarNamePatterns();
    }

    /**
     * 创建默认配置（不分析依赖）
     */
    public static DependencyAnalysisConfig defaultConfig() {
        return new DependencyAnalysisConfig();
    }

    /**
     * 创建启用依赖分析的配置
     */
    public static DependencyAnalysisConfig withDependencies(List<String> includePackages, List<String> includeJarNames) {
        DependencyAnalysisConfig config = new DependencyAnalysisConfig();
        config.setAnalyzeDependencies(true);
        if (includePackages != null) {
            config.setIncludePackages(includePackages);
        }
        if (includeJarNames != null) {
            config.setIncludeJarNames(includeJarNames);
        }
        return config;
    }
}
