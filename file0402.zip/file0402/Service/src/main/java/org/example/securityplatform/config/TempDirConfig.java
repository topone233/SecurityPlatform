package org.example.securityplatform.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import jakarta.annotation.PostConstruct;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * 临时目录配置类
 * 统一管理所有临时文件的存储路径，避免使用系统临时目录
 */
@Configuration
public class TempDirConfig {

    @Value("${file.temp.dir:./temp}")
    private String tempBaseDir;

    @PostConstruct
    public void init() {
        // 创建基础临时目录
        File baseDir = new File(tempBaseDir);
        if (!baseDir.exists()) {
            baseDir.mkdirs();
        }

        // 创建子目录
        createSubDir("quick_diff");
        createSubDir("dep_scan");
        createSubDir("extract");
    }

    private void createSubDir(String subDir) {
        File dir = new File(tempBaseDir, subDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    public String getTempBaseDir() {
        return tempBaseDir;
    }

    /**
     * 获取快速差异对比临时目录
     */
    public String getQuickDiffDir() {
        return tempBaseDir + "/quick_diff";
    }

    /**
     * 获取依赖扫描临时目录
     */
    public String getDepScanDir() {
        return tempBaseDir + "/dep_scan";
    }

    /**
     * 获取JAR解压临时目录
     */
    public String getExtractDir() {
        return tempBaseDir + "/extract";
    }

    /**
     * 获取指定制品的解压临时目录
     */
    public String getExtractDir(Long artifactId) {
        return tempBaseDir + "/extract/" + artifactId;
    }

    /**
     * 获取指定制品的解压临时目录
     */
    public String getExtractDir(String artifactId) {
        return tempBaseDir + "/extract/" + artifactId;
    }

    /**
     * 在指定目录下创建唯一的临时子目录
     */
    public Path createUniqueTempDir(String parentDir, String prefix) {
        String baseDir = tempBaseDir + "/" + parentDir;
        File dir = new File(baseDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        // 创建唯一目录
        long timestamp = System.currentTimeMillis();
        int counter = 0;
        File uniqueDir;
        do {
            uniqueDir = new File(baseDir, prefix + "_" + timestamp + "_" + counter);
            counter++;
        } while (uniqueDir.exists());

        uniqueDir.mkdirs();
        return uniqueDir.toPath();
    }

    /**
     * 清理指定目录下的临时文件（可选实现）
     */
    public void cleanupTempDir(String subDir) {
        File dir = new File(tempBaseDir, subDir);
        if (dir.exists() && dir.isDirectory()) {
            deleteDirectory(dir);
        }
    }

    private void deleteDirectory(File directory) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteDirectory(file);
                } else {
                    file.delete();
                }
            }
        }
        directory.delete();
    }
}