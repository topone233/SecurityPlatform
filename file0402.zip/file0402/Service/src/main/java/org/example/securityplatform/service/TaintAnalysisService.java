package org.example.securityplatform.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.diff.CallGraphBuilder;
import org.example.securityplatform.analyzer.diff.MethodCallModel;
import org.example.securityplatform.analyzer.jar.DependencyAnalysisConfig;
import org.example.securityplatform.analyzer.jar.DependencyScanner;
import org.example.securityplatform.analyzer.jar.FrameworkPackageFilter;
import org.example.securityplatform.analyzer.jar.JarInfo;
import org.example.securityplatform.analyzer.jar.PackageExtractor;
import org.example.securityplatform.analyzer.taint.SinkDetector;
import org.example.securityplatform.analyzer.taint.TaintTracker;
import org.example.securityplatform.dto.DependencyPreviewResponse;
import org.example.securityplatform.dto.TaintAnalysisResultResponse;
import org.example.securityplatform.dto.TaintPathResponse;
import org.example.securityplatform.dto.TaintSinkResponse;
import org.example.securityplatform.entity.Artifact;
import org.example.securityplatform.entity.TaintPath;
import org.example.securityplatform.entity.TaintSink;
import org.example.securityplatform.repository.ArtifactRepository;
import org.example.securityplatform.repository.TaintPathRepository;
import org.example.securityplatform.repository.TaintSinkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Collectors;

/**
 * 污点分析服务
 * 协调Sink检测、调用图构建、污点追踪等组件
 */
@Slf4j
@Service
public class TaintAnalysisService {

    @Autowired
    private ArtifactRepository artifactRepository;

    @Autowired
    private TaintSinkRepository taintSinkRepository;

    @Autowired
    private TaintPathRepository taintPathRepository;

    @Autowired
    private List<SinkDetector> sinkDetectors;

    @Autowired
    private DependencyScanner dependencyScanner;

    private final ObjectMapper objectMapper = new ObjectMapper();

    private final FrameworkPackageFilter frameworkFilter = new FrameworkPackageFilter();
    private final PackageExtractor packageExtractor = new PackageExtractor();

    /**
     * 执行污点分析（向后兼容，单JAR模式）
     *
     * @param artifactId     制品ID
     * @param vulnerabilityType 漏洞类型（SQL_INJECTION, COMMAND_INJECTION, SSRF）
     * @return 分析结果
     */
    @Transactional
    public TaintAnalysisResultResponse analyze(Long artifactId, String vulnerabilityType) throws IOException {
        return analyze(artifactId, vulnerabilityType, DependencyAnalysisConfig.defaultConfig());
    }

    /**
     * 执行污点分析（支持多模块配置）
     *
     * @param artifactId     制品ID
     * @param vulnerabilityType 漏洞类型（SQL_INJECTION, COMMAND_INJECTION, SSRF）
     * @param depConfig      依赖分析配置
     * @return 分析结果
     */
    @Transactional
    public TaintAnalysisResultResponse analyze(Long artifactId, String vulnerabilityType,
                                                DependencyAnalysisConfig depConfig) throws IOException {
        log.info("开始污点分析: artifactId={}, vulnerabilityType={}, analyzeDependencies={}",
                artifactId, vulnerabilityType, depConfig.isAnalyzeDependencies());

        // 1. 获取制品信息
        Artifact artifact = artifactRepository.findById(artifactId)
                .orElseThrow(() -> new IllegalArgumentException("制品不存在: " + artifactId));

        String mainJarPath = artifact.getFilePath();
        if (mainJarPath == null || mainJarPath.isEmpty()) {
            throw new IllegalStateException("制品文件路径为空");
        }

        // 2. 清理旧的分析结果
        cleanupOldResults(artifactId, vulnerabilityType);

        // 3. 选择合适的Sink检测器
        SinkDetector detector = selectDetector(vulnerabilityType);
        if (detector == null) {
            throw new IllegalArgumentException("不支持的漏洞类型: " + vulnerabilityType);
        }

        // 4. 扫描依赖模块（如果启用）
        List<JarInfo> jars;
        if (depConfig.isAnalyzeDependencies()) {
            jars = dependencyScanner.scanDependencies(mainJarPath, depConfig);
            log.info("多模块分析: 共 {} 个JAR", jars.size());
        } else {
            jars = List.of(new JarInfo(mainJarPath, JarInfo.JarType.MAIN, "MAIN"));
        }

        try {
            // 5. 执行Sink检测（多JAR模式）
            List<TaintSink> sinks = detector.detectAll(jars, artifactId);

            // 6. 保存Sink点
            sinks = taintSinkRepository.saveAll(sinks);
            log.info("检测到 {} 个Sink点", sinks.size());

            // 7. 构建调用图（多JAR模式）
            log.info("开始构建调用图...");
            CallGraphBuilder callGraphBuilder = new CallGraphBuilder(jars);
            List<MethodCallModel> callGraph = callGraphBuilder.build();
            log.info("调用图构建完成，共 {} 条调用关系", callGraph.size());

            // 8. 执行污点追踪（多JAR模式）
            TaintTracker tracker = new TaintTracker();
            List<TaintPath> paths = tracker.traceAllMultiJar(sinks, jars, callGraph);

            // 9. 保存污点路径
            paths = taintPathRepository.saveAll(paths);

            // 10. 构建响应
            TaintAnalysisResultResponse response = buildResponse(artifactId, vulnerabilityType, sinks, paths);

            log.info("污点分析完成: artifactId={}, sinks={}, paths={}",
                    artifactId, response.getTotalSinks(), response.getTracedPaths());

            return response;

        } finally {
            // 清理临时依赖JAR文件
            if (depConfig.isAnalyzeDependencies()) {
                dependencyScanner.cleanupDependencies(jars);
            }
        }
    }

    /**
     * 获取污点分析结果
     */
    public TaintAnalysisResultResponse getResult(Long artifactId, String vulnerabilityType) {
        List<TaintSink> sinks = taintSinkRepository.findByArtifactIdAndVulnerabilityType(
                artifactId, vulnerabilityType);

        if (sinks.isEmpty()) {
            TaintAnalysisResultResponse response = new TaintAnalysisResultResponse();
            response.setArtifactId(artifactId);
            response.setVulnerabilityType(vulnerabilityType);
            response.setTotalSinks(0);
            response.setTracedPaths(0);
            response.setReachablePaths(0);
            response.setSinks(new ArrayList<>());
            return response;
        }

        // 加载每个Sink的路径
        List<TaintPath> allPaths = new ArrayList<>();
        for (TaintSink sink : sinks) {
            List<TaintPath> paths = taintPathRepository.findBySinkId(sink.getId());
            allPaths.addAll(paths);
        }

        return buildResponse(artifactId, vulnerabilityType, sinks, allPaths);
    }

    /**
     * 获取单个Sink的详情（包含所有路径）
     */
    public TaintSinkResponse getSinkDetail(Long sinkId) {
        TaintSink sink = taintSinkRepository.findById(sinkId)
                .orElseThrow(() -> new IllegalArgumentException("Sink不存在: " + sinkId));

        List<TaintPath> paths = taintPathRepository.findBySinkId(sinkId);

        return convertToSinkResponse(sink, paths);
    }

    /**
     * 清理旧的分析结果
     */
    private void cleanupOldResults(Long artifactId, String vulnerabilityType) {
        List<TaintSink> oldSinks = taintSinkRepository
                .findByArtifactIdAndVulnerabilityType(artifactId, vulnerabilityType);

        if (!oldSinks.isEmpty()) {
            List<Long> sinkIds = oldSinks.stream().map(TaintSink::getId).collect(Collectors.toList());
            taintPathRepository.deleteBySinkIdIn(sinkIds);
            taintSinkRepository.deleteAll(oldSinks);
            log.info("清理旧的污点分析结果: {} 个Sink", oldSinks.size());
        }
    }

    /**
     * 选择Sink检测器
     */
    private SinkDetector selectDetector(String vulnerabilityType) {
        if (sinkDetectors == null) {
            return null;
        }
        return sinkDetectors.stream()
                .filter(d -> d.getVulnerabilityType().equals(vulnerabilityType))
                .findFirst()
                .orElse(null);
    }

    /**
     * 构建响应
     */
    private TaintAnalysisResultResponse buildResponse(Long artifactId, String vulnerabilityType,
                                                       List<TaintSink> sinks, List<TaintPath> paths) {
        TaintAnalysisResultResponse response = new TaintAnalysisResultResponse();
        response.setArtifactId(artifactId);
        response.setVulnerabilityType(vulnerabilityType);
        response.setTotalSinks(sinks.size());
        response.setTracedPaths(paths.size());

        // 计算可达路径数
        long reachableCount = paths.stream().filter(TaintPath::getIsReachable).count();
        response.setReachablePaths((int) reachableCount);

        // 按Sink ID分组路径
        Map<Long, List<TaintPath>> pathMap = paths.stream()
                .collect(Collectors.groupingBy(TaintPath::getSinkId));

        // 转换Sink响应
        List<TaintSinkResponse> sinkResponses = sinks.stream()
                .map(sink -> convertToSinkResponse(sink, pathMap.getOrDefault(sink.getId(), new ArrayList<>())))
                .collect(Collectors.toList());

        response.setSinks(sinkResponses);
        return response;
    }

    /**
     * 转换Sink实体为响应DTO
     */
    private TaintSinkResponse convertToSinkResponse(TaintSink sink, List<TaintPath> paths) {
        TaintSinkResponse response = new TaintSinkResponse();
        response.setId(sink.getId());
        response.setVulnerabilityType(sink.getVulnerabilityType());
        response.setSinkType(sink.getSinkType());
        response.setSinkClass(sink.getSinkClass());
        response.setSinkMethod(sink.getSinkMethod());
        response.setVulnerableParams(parseJsonArray(sink.getVulnerableParams()));
        response.setFilePath(sink.getFilePath());
        response.setSqlSnippet(sink.getSqlSnippet());
        response.setRiskLevel(sink.getRiskLevel());
        response.setLineNumber(sink.getLineNumber());

        // 转换路径
        List<TaintPathResponse> pathResponses = paths.stream()
                .map(this::convertToPathResponse)
                .collect(Collectors.toList());
        response.setPaths(pathResponses);

        return response;
    }

    /**
     * 转换路径实体为响应DTO
     */
    private TaintPathResponse convertToPathResponse(TaintPath path) {
        TaintPathResponse response = new TaintPathResponse();
        response.setId(path.getId());
        response.setSourceClass(path.getSourceClass());
        response.setSourceMethod(path.getSourceMethod());
        response.setSourceParam(path.getSourceParam());
        response.setDepth(path.getDepth());
        response.setIsReachable(path.getIsReachable());

        // 解析调用链
        if (path.getCallChain() != null && !path.getCallChain().isEmpty()) {
            try {
                List<TaintPathResponse.CallChainNodeResponse> nodes = objectMapper.readValue(
                        path.getCallChain(),
                        new TypeReference<List<TaintPathResponse.CallChainNodeResponse>>() {}
                );
                response.setCallChain(nodes);
            } catch (JsonProcessingException e) {
                log.warn("解析调用链JSON失败", e);
                response.setCallChain(new ArrayList<>());
            }
        } else {
            response.setCallChain(new ArrayList<>());
        }

        return response;
    }

    /**
     * 解析JSON数组字符串
     */
    private List<String> parseJsonArray(String json) {
        if (json == null || json.isEmpty()) {
            return new ArrayList<>();
        }
        try {
            return objectMapper.readValue(json, new TypeReference<List<String>>() {});
        } catch (JsonProcessingException e) {
            log.warn("解析JSON数组失败: {}", json);
            return new ArrayList<>();
        }
    }

    /**
     * 预览制品中的依赖信息
     * 用于前端下拉选择，自动列举依赖JAR和业务包名
     *
     * @param artifactId 制品ID
     * @return 依赖预览响应
     */
    public DependencyPreviewResponse previewDependencies(Long artifactId) {
        log.info("开始预览依赖: artifactId={}", artifactId);

        // 获取制品信息
        Artifact artifact = artifactRepository.findById(artifactId)
                .orElseThrow(() -> new IllegalArgumentException("制品不存在: " + artifactId));

        String jarPath = artifact.getFilePath();
        if (jarPath == null || jarPath.isEmpty()) {
            throw new IllegalStateException("制品文件路径为空");
        }

        try {
            // 收集依赖JAR列表
            List<String> dependencyJars = new ArrayList<>();
            try (JarFile jarFile = new JarFile(jarPath)) {
                Enumeration<JarEntry> entries = jarFile.entries();

                while (entries.hasMoreElements()) {
                    JarEntry entry = entries.nextElement();
                    String name = entry.getName();

                    // 扫描 BOOT-INF/lib 和 WEB-INF/lib
                    if ((name.startsWith("BOOT-INF/lib/") || name.startsWith("WEB-INF/lib/"))
                            && name.endsWith(".jar") && !entry.isDirectory()) {
                        // 提取JAR文件名
                        int lastSlash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
                        String jarName = lastSlash >= 0 ? name.substring(lastSlash + 1) : name;
                        dependencyJars.add(jarName);
                    }
                }
            }

            log.info("找到 {} 个依赖JAR", dependencyJars.size());

            // 收集业务包名
            TreeSet<String> packages = new TreeSet<>();
            try (JarFile jarFile = new JarFile(jarPath)) {
                Enumeration<JarEntry> entries = jarFile.entries();

                while (entries.hasMoreElements()) {
                    JarEntry entry = entries.nextElement();
                    String name = entry.getName();

                    // 扫描 BOOT-INF/classes 和 根目录下的class文件
                    String classPath = null;
                    if (name.startsWith("BOOT-INF/classes/") && name.endsWith(".class") && !entry.isDirectory()) {
                        classPath = name.substring("BOOT-INF/classes/".length());
                    } else if (name.endsWith(".class") && !entry.isDirectory() && !name.contains("/")) {
                        // 根目录下的class文件
                        classPath = name;
                    }

                    if (classPath != null) {
                        // 排除框架包
                        if (isFrameworkPackage(classPath)) {
                            continue;
                        }

                        // 提取包名
                        String packageName = extractPackageName(classPath);
                        if (packageName != null && !packageName.isEmpty()) {
                            packages.add(packageName);
                        }
                    }
                }
            }

            log.info("找到 {} 个业务包", packages.size());

            // 检测是否为多模块项目
            boolean isMultiModule = false;
            try {
                isMultiModule = dependencyScanner.isMultiModuleParent(jarPath);
            } catch (Exception e) {
                log.warn("检测多模块项目失败", e);
            }

            // 排序依赖JAR列表
            dependencyJars.sort(String::compareTo);

            return new DependencyPreviewResponse(
                    dependencyJars,
                    new ArrayList<>(packages),
                    dependencyJars.size(),
                    isMultiModule
            );

        } catch (Exception e) {
            log.error("预览依赖失败", e);
            throw new RuntimeException("预览依赖失败: " + e.getMessage(), e);
        }
    }

    /**
     * 判断是否为框架包（需要排除）
     */
    private boolean isFrameworkPackage(String classPath) {
        return frameworkFilter.isFrameworkPackage(classPath);
    }

    /**
     * 从class文件路径提取包名
     * 例如: com/example/module/service/MyService.class -> com.example.module
     */
    private String extractPackageName(String classPath) {
        return packageExtractor.extractPackageName(classPath);
    }
}