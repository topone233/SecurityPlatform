<template>
  <div class="quick-diff">
    <!-- 上传区域 -->
    <el-card shadow="never" v-if="!result">
      <template #header>
        <div class="card-header">
          <span>快速差异对比</span>
          <el-tag type="info">无需创建项目，直接上传对比</el-tag>
        </div>
      </template>

      <el-alert
        title="使用说明"
        type="info"
        :closable="false"
        show-icon
        style="margin-bottom: 20px;"
      >
        <template #default>
          <div style="line-height: 1.6;">
            <p><strong>快速差异对比</strong> - 直接上传两个 JAR/WAR 文件进行差异分析，无需预先创建项目。</p>
            <p><strong>适用场景：</strong></p>
            <ul style="margin: 5px 0; padding-left: 20px;">
              <li>单模块项目：直接上传 JAR 即可</li>
              <li>多模块项目：启用"高级设置 → 多模块依赖分析"，扫描子模块JAR</li>
              <li>Spring Boot Fat JAR：自动识别 BOOT-INF/lib 中的依赖</li>
              <li>WAR 文件：自动识别 WEB-INF/lib 中的依赖</li>
            </ul>
          </div>
        </template>
      </el-alert>

      <el-form label-width="120px">
        <el-form-item label="基线文件">
          <el-upload
            :auto-upload="false"
            :on-change="onBaselineChange"
            :show-file-list="false"
            accept=".jar,.war"
            drag
          >
            <el-icon class="el-icon--upload"><upload-filled /></el-icon>
            <div class="el-upload__text">
              拖拽文件到此处，或 <em>点击选择</em>
            </div>
            <template #tip>
              <div class="el-upload__tip">上传基线版本 JAR/WAR 文件</div>
            </template>
          </el-upload>
          <div v-if="baselineFile" class="file-info">
            <el-icon><Document /></el-icon>
            <span>{{ baselineFile.name }}</span>
            <span class="file-size">({{ formatSize(baselineFile.size) }})</span>
          </div>
        </el-form-item>

        <el-form-item label="目标文件">
          <el-upload
            :auto-upload="false"
            :on-change="onTargetChange"
            :show-file-list="false"
            accept=".jar,.war"
            drag
          >
            <el-icon class="el-icon--upload"><upload-filled /></el-icon>
            <div class="el-upload__text">
              拖拽文件到此处，或 <em>点击选择</em>
            </div>
            <template #tip>
              <div class="el-upload__tip">上传目标版本 JAR/WAR 文件</div>
            </template>
          </el-upload>
          <div v-if="targetFile" class="file-info">
            <el-icon><Document /></el-icon>
            <span>{{ targetFile.name }}</span>
            <span class="file-size">({{ formatSize(targetFile.size) }})</span>
          </div>
        </el-form-item>

        <!-- 高级设置：多模块分析 -->
        <el-divider>
          <el-icon><Setting /></el-icon>
          高级设置
        </el-divider>

        <el-form-item>
          <el-collapse>
            <el-collapse-item title="多模块依赖分析" name="dependency">
              <el-form-item label="分析依赖模块">
                <el-switch
                  v-model="depConfig.analyzeDependencies"
                  @change="onAnalyzeDependenciesChange"
                />
                <div class="help-text">启用后将扫描 BOOT-INF/lib 或 WEB-INF/lib 中的依赖JAR。适用于多模块项目（父JAR无业务代码，子模块在lib目录）。</div>
              </el-form-item>

              <template v-if="depConfig.analyzeDependencies">
                <!-- 包名规则 -->
                <el-form-item label="业务包名">
                  <el-select
                    v-model="depConfig.includePackages"
                    multiple
                    filterable
                    placeholder="选择业务包名"
                    style="width: 100%"
                    :loading="dependencyOptions.loading"
                  >
                    <el-option
                      v-for="pkg in dependencyOptions.packages"
                      :key="pkg"
                      :label="pkg"
                      :value="pkg"
                    />
                  </el-select>
                  <div class="help-text">
                    只分析包含这些包名的JAR（推荐）。留空则分析所有依赖JAR。
                    <span v-if="dependencyOptions.packages.length > 0" style="color: #409EFF;">
                      已扫描到 {{ dependencyOptions.packages.length }} 个业务包
                    </span>
                  </div>
                </el-form-item>

                <!-- JAR名称规则 -->
                <el-form-item label="JAR名称模式">
                  <el-select
                    v-model="depConfig.includeJarNames"
                    multiple
                    filterable
                    placeholder="选择JAR名称"
                    style="width: 100%"
                    :loading="dependencyOptions.loading"
                  >
                    <el-option
                      v-for="jar in dependencyOptions.jars"
                      :key="jar"
                      :label="jar"
                      :value="jar"
                    />
                  </el-select>
                  <div class="help-text">
                    根据JAR文件名匹配。留空则不按名称过滤。
                    <span v-if="dependencyOptions.jars.length > 0" style="color: #409EFF;">
                      已扫描到 {{ dependencyOptions.jars.length }} 个依赖JAR
                    </span>
                  </div>
                </el-form-item>

                <!-- 配置提示 -->
                <el-alert
                  v-if="depConfig.includePackages.length > 0 || depConfig.includeJarNames.length > 0"
                  type="success"
                  :closable="false"
                  show-icon
                >
                  <template #title>
                    将分析匹配这些规则的依赖JAR包
                  </template>
                  <template #default v-if="depConfig.includePackages.length > 0">
                    <div style="font-size: 12px; margin-top: 5px;">
                      包名规则: {{ depConfig.includePackages.join(', ') }}
                    </div>
                  </template>
                </el-alert>

                <el-alert
                  v-else
                  type="info"
                  :closable="false"
                  show-icon
                  title="将扫描所有依赖JAR"
                >
                  <template #default>
                    <div style="font-size: 12px;">
                      未配置过滤规则时，将分析所有依赖JAR包。对于大型项目建议配置过滤规则以提升性能。
                    </div>
                  </template>
                </el-alert>
              </template>
            </el-collapse-item>
          </el-collapse>
        </el-form-item>
      </el-form>

      <div class="actions">
        <el-button
          type="primary"
          size="large"
          @click="startAnalysis"
          :loading="analyzing"
          :disabled="!baselineFile || !targetFile"
        >
          {{ analyzing ? '分析中...' : '开始对比分析' }}
        </el-button>
      </div>
    </el-card>

    <!-- 分析进度 -->
    <el-card shadow="never" v-if="analyzing">
      <template #header>
        <span>正在分析</span>
      </template>
      <div class="progress-container">
        <el-progress
          :percentage="progress"
          :stroke-width="20"
          :indeterminate="true"
        />
        <p class="progress-text">{{ progressText }}</p>
      </div>
    </el-card>

    <!-- 分析结果 -->
    <el-card shadow="never" v-if="result && !analyzing">
      <template #header>
        <div class="card-header">
          <span>对比结果</span>
          <div>
            <el-tag v-if="result.duration" type="info">
              耗时: {{ (result.duration / 1000).toFixed(2) }}s
            </el-tag>
            <el-button
              v-if="!saved"
              type="success"
              @click="showSaveDialog"
              style="margin-left: 10px;"
            >
              保存结果
            </el-button>
            <el-tag v-else type="success" style="margin-left: 10px;">
              已保存
            </el-tag>
            <el-button type="primary" @click="resetAnalysis" style="margin-left: 10px;">
              重新对比
            </el-button>
          </div>
        </div>
      </template>

      <!-- 分析警告 -->
      <el-alert
        v-if="result.warnings && result.warnings.length > 0"
        type="warning"
        :closable="false"
        show-icon
        style="margin-bottom: 20px;"
      >
        <template #title>
          <strong>分析建议</strong>
        </template>
        <template #default>
          <div v-for="(warning, index) in result.warnings" :key="index" style="margin-top: 5px;">
            {{ warning }}
          </div>
        </template>
      </el-alert>

      <!-- 文件差异统计 -->
      <div class="summary-section">
        <h3>文件变更统计</h3>
        <el-row :gutter="20">
          <el-col :span="6">
            <el-statistic title="新增文件" :value="result.fileSummary?.addedFiles || 0">
              <template #suffix>
                <el-icon color="#67C23A"><DocumentAdd /></el-icon>
              </template>
            </el-statistic>
          </el-col>
          <el-col :span="6">
            <el-statistic title="修改文件" :value="result.fileSummary?.modifiedFiles || 0">
              <template #suffix>
                <el-icon color="#E6A23C"><Edit /></el-icon>
              </template>
            </el-statistic>
          </el-col>
          <el-col :span="6">
            <el-statistic title="删除文件" :value="result.fileSummary?.deletedFiles || 0">
              <template #suffix>
                <el-icon color="#F56C6C"><Delete /></el-icon>
              </template>
            </el-statistic>
          </el-col>
          <el-col :span="6">
            <el-statistic title="方法变更" :value="totalMethodChanges">
              <template #suffix>
                <el-icon color="#409EFF"><Operation /></el-icon>
              </template>
            </el-statistic>
          </el-col>
        </el-row>
      </div>

      <el-divider />

      <!-- 依赖分析摘要 -->
      <div class="summary-section" v-if="result.dependencySummary?.enabled">
        <h3>依赖分析</h3>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-statistic title="Baseline依赖数" :value="result.dependencySummary?.baselineDependencyCount || 0">
              <template #suffix>
                <span style="font-size: 14px;">个JAR</span>
              </template>
            </el-statistic>
          </el-col>
          <el-col :span="8">
            <el-statistic title="Target依赖数" :value="result.dependencySummary?.targetDependencyCount || 0">
              <template #suffix>
                <span style="font-size: 14px;">个JAR</span>
              </template>
            </el-statistic>
          </el-col>
          <el-col :span="8">
            <el-popover
              placement="bottom"
              :width="400"
              trigger="click"
              v-if="result.dependencySummary?.analyzedDependencies?.length > 0"
            >
              <template #reference>
                <el-button type="primary" link>
                  查看分析的依赖 ({{ result.dependencySummary.analyzedDependencies.length }}个)
                </el-button>
              </template>
              <div class="dep-list">
                <div class="dep-list-header">分析的依赖JAR</div>
                <div
                  v-for="(dep, index) in result.dependencySummary.analyzedDependencies"
                  :key="index"
                  class="dep-item"
                >
                  <el-icon><Box /></el-icon>
                  {{ dep }}
                </div>
              </div>
            </el-popover>
          </el-col>
        </el-row>
      </div>

      <el-divider v-if="result.dependencySummary?.enabled" />

      <!-- API变更统计 -->
      <div class="summary-section">
        <h3>API变更统计</h3>
        <el-row :gutter="20">
          <el-col :span="4">
            <div class="stat-box high">
              <div class="label">高危</div>
              <div class="value">{{ result.apiSummary?.highRiskApis || 0 }}</div>
            </div>
          </el-col>
          <el-col :span="4">
            <div class="stat-box medium">
              <div class="label">中危</div>
              <div class="value">{{ result.apiSummary?.mediumRiskApis || 0 }}</div>
            </div>
          </el-col>
          <el-col :span="4">
            <div class="stat-box low">
              <div class="label">低危</div>
              <div class="value">{{ result.apiSummary?.lowRiskApis || 0 }}</div>
            </div>
          </el-col>
          <el-col :span="4">
            <div class="stat-box">
              <div class="label">新增API</div>
              <div class="value">{{ result.apiSummary?.newApis || 0 }}</div>
            </div>
          </el-col>
          <el-col :span="4">
            <div class="stat-box">
              <div class="label">修改API</div>
              <div class="value">{{ result.apiSummary?.modifiedApis || 0 }}</div>
            </div>
          </el-col>
          <el-col :span="4">
            <div class="stat-box">
              <div class="label">删除API</div>
              <div class="value">{{ result.apiSummary?.deletedApis || 0 }}</div>
            </div>
          </el-col>
        </el-row>
      </div>

      <el-divider />

      <!-- API变更详情 -->
      <div class="detail-section" v-if="result.apiDiffs?.length">
        <h3>API变更详情</h3>
        <el-tabs v-model="activeTab">
          <el-tab-pane label="全部" name="all" />
          <el-tab-pane label="新增" name="NEW_API" />
          <el-tab-pane label="修改" name="MODIFIED_API" />
          <el-tab-pane label="受影响" name="AFFECTED_API" />
          <el-tab-pane label="删除" name="DELETED_API" />
        </el-tabs>

        <el-table :data="filteredApiDiffs" style="width: 100%">
          <el-table-column prop="httpMethod" label="方法" width="80">
            <template #default="{ row }">
              <el-tag :type="getMethodTagType(row.httpMethod)" size="small">
                {{ row.httpMethod }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="apiUrl" label="API路径" min-width="200" show-overflow-tooltip />
          <el-table-column prop="changeType" label="变更类型" width="100">
            <template #default="{ row }">
              <el-tag :type="getChangeTypeTag(row.changeType)" size="small">
                {{ getChangeTypeLabel(row.changeType) }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="riskLevel" label="风险" width="80">
            <template #default="{ row }">
              <el-tag :type="getRiskTagType(row.riskLevel)" size="small">
                {{ row.riskLevel }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="changeReason" label="原因" min-width="200" show-overflow-tooltip />
          <el-table-column label="操作" width="80">
            <template #default="{ row }">
              <el-button type="primary" link @click="showApiDetail(row)">详情</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <el-divider v-if="result.apiDiffs?.length" />

      <!-- 文件差异详情 -->
      <div class="detail-section" v-if="result.fileDiffs?.length">
        <h3>文件差异详情</h3>
        <el-table :data="result.fileDiffs" style="width: 100%">
          <el-table-column prop="filePath" label="文件路径" min-width="250" show-overflow-tooltip />
          <el-table-column prop="diffType" label="类型" width="100">
            <template #default="{ row }">
              <el-tag :type="getDiffTypeTag(row.diffType)" size="small">
                {{ row.diffType }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="方法变更" min-width="200">
            <template #default="{ row }">
              <template v-if="row.methodChanges && row.methodChanges.length > 0">
                <div class="method-changes">
                  <template v-for="(mc, index) in row.methodChanges.slice(0, 3)" :key="index">
                    <el-tag
                      :type="mc.changeType === 'ADDED' ? 'success' : mc.changeType === 'DELETED' ? 'danger' : 'warning'"
                      size="small"
                      class="method-tag"
                    >
                      {{ mc.changeType === 'ADDED' ? '+' : mc.changeType === 'DELETED' ? '-' : '~' }}{{ mc.methodName }}
                    </el-tag>
                  </template>
                  <el-popover
                    v-if="row.methodChanges.length > 3"
                    placement="left"
                    :width="400"
                    trigger="click"
                  >
                    <template #reference>
                      <el-tag type="info" size="small" class="method-tag clickable">
                        +{{ row.methodChanges.length - 3 }} 更多
                      </el-tag>
                    </template>
                    <div class="method-popover">
                      <div class="method-popover-header">
                        <span>共 {{ row.methodChanges.length }} 个方法变更</span>
                      </div>
                      <div class="method-popover-list">
                        <div
                          v-for="(mc, index) in row.methodChanges"
                          :key="index"
                          class="method-item"
                        >
                          <el-tag
                            :type="mc.changeType === 'ADDED' ? 'success' : mc.changeType === 'DELETED' ? 'danger' : 'warning'"
                            size="small"
                          >
                            {{ mc.changeType === 'ADDED' ? '+' : mc.changeType === 'DELETED' ? '-' : '~' }}
                            {{ mc.changeType === 'ADDED' ? '新增' : mc.changeType === 'DELETED' ? '删除' : '修改' }}
                          </el-tag>
                          <span class="method-name">{{ mc.methodName }}</span>
                        </div>
                      </div>
                    </div>
                  </el-popover>
                </div>
              </template>
              <template v-else>
                <span v-if="row.methodsAdded > 0" class="added">+{{ row.methodsAdded }}</span>
                <span v-if="row.methodsModified > 0" class="modified">~{{ row.methodsModified }}</span>
                <span v-if="row.methodsDeleted > 0" class="deleted">-{{ row.methodsDeleted }}</span>
                <span v-if="row.methodsAdded === 0 && row.methodsModified === 0 && row.methodsDeleted === 0">-</span>
              </template>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>

    <!-- 影响链路图谱 -->
    <el-card shadow="never" v-if="result?.impactGraph">
      <template #header>
        <span>影响链路图谱</span>
        <el-tag type="info" size="small" style="margin-left: 10px;">
          变更: {{ result.impactGraph.changes?.length || 0 }} |
          API: {{ result.impactGraph.apis?.length || 0 }} |
          受影响: {{ result.impactGraph.affected?.length || 0 }}
        </el-tag>
      </template>
      <ChangeImpactGraph
        :graph-data="result.impactGraph"
        @node-click="handleGraphNodeClick"
      />
    </el-card>

    <!-- 源代码差异对比 -->
    <el-card shadow="never" v-if="result?.sourceDiffs?.length" style="margin-top: 16px;">
      <template #header>
        <span>源代码差异对比</span>
        <el-tag type="info" size="small" style="margin-left: 10px;">
          {{ result.sourceDiffs.length }} 个文件
        </el-tag>
      </template>
      <div class="source-diff-layout">
        <!-- Left: File list -->
        <div class="source-diff-file-list">
          <div class="file-list-header">
            <el-radio-group v-model="sourceDiffFilter" size="small">
              <el-radio-button label="ALL">全部</el-radio-button>
              <el-radio-button label="ADDED">新增</el-radio-button>
              <el-radio-button label="MODIFIED">修改</el-radio-button>
              <el-radio-button label="DELETED">删除</el-radio-button>
            </el-radio-group>
          </div>
          <div class="file-list-items">
            <div v-for="sd in filteredSourceDiffs" :key="sd.filePath"
                 :class="['file-list-item', { active: selectedSourceDiff?.filePath === sd.filePath }]"
                 @click="selectedSourceDiff = sd">
              <el-tag :type="getDiffTypeTag(sd.diffType)" size="small" class="file-diff-type">
                {{ getDiffTypeLabel(sd.diffType) }}
              </el-tag>
              <span class="file-list-path" :title="sd.sourceFilePath || sd.filePath">
                {{ getShortPath(sd.sourceFilePath || sd.filePath) }}
              </span>
            </div>
            <el-empty v-if="!filteredSourceDiffs.length" description="无匹配文件" :image-size="60" />
          </div>
        </div>
        <!-- Right: Diff viewer -->
        <div class="source-diff-viewer">
          <FileDiffViewer
            v-if="selectedSourceDiff"
            :baseline-source="selectedSourceDiff.baselineSource"
            :target-source="selectedSourceDiff.targetSource"
            :file-path="selectedSourceDiff.sourceFilePath || selectedSourceDiff.filePath"
            :diff-type="selectedSourceDiff.diffType"
            :error="selectedSourceDiff.error"
          />
          <el-empty v-else description="请选择左侧文件查看源码差异" />
        </div>
      </div>
    </el-card>

    <!-- API详情弹窗 -->
    <el-dialog v-model="apiDetailVisible" title="API变更详情" width="600px">
      <el-descriptions :column="1" border v-if="selectedApi">
        <el-descriptions-item label="API路径">{{ selectedApi.apiUrl }}</el-descriptions-item>
        <el-descriptions-item label="HTTP方法">{{ selectedApi.httpMethod }}</el-descriptions-item>
        <el-descriptions-item label="控制器">{{ selectedApi.controllerClass }}</el-descriptions-item>
        <el-descriptions-item label="方法名">{{ selectedApi.methodName }}</el-descriptions-item>
        <el-descriptions-item label="变更类型">{{ getChangeTypeLabel(selectedApi.changeType) }}</el-descriptions-item>
        <el-descriptions-item label="风险等级">{{ selectedApi.riskLevel }}</el-descriptions-item>
        <el-descriptions-item label="变更原因">{{ selectedApi.changeReason }}</el-descriptions-item>
        <el-descriptions-item label="调用链" v-if="selectedApi.callChain?.length">
          <div class="call-chain">
            <template v-for="(node, index) in selectedApi.callChain" :key="index">
              <span class="node">{{ node.className }}.{{ node.methodName }}</span>
              <span v-if="index < selectedApi.callChain.length - 1" class="arrow">→</span>
            </template>
          </div>
        </el-descriptions-item>
      </el-descriptions>
    </el-dialog>

    <!-- 保存对话框 -->
    <el-dialog v-model="saveDialogVisible" title="保存对比结果" width="500px">
      <el-form :model="saveForm" label-width="80px">
        <el-form-item label="基线文件">
          <el-input :value="baselineFile?.name" disabled />
        </el-form-item>
        <el-form-item label="目标文件">
          <el-input :value="targetFile?.name" disabled />
        </el-form-item>
        <el-form-item label="描述">
          <el-input
            v-model="saveForm.description"
            type="textarea"
            :rows="3"
            placeholder="请输入对比结果的描述（可选）"
            maxlength="500"
            show-word-limit
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="saveDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveResult" :loading="saving">
          {{ saving ? '保存中...' : '保存' }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'
import { UploadFilled, Document, DocumentAdd, Edit, Delete, Operation, Setting } from '@element-plus/icons-vue'
import diffAnalysisApi from '@/api/diffAnalysis'
import ChangeImpactGraph from '@/components/diff/ChangeImpactGraph.vue'
import FileDiffViewer from '@/components/diff/FileDiffViewer.vue'

// 文件
const baselineFile = ref(null)
const targetFile = ref(null)

// 依赖分析配置
const depConfig = ref({
  analyzeDependencies: false,
  includePackages: [],
  includeJarNames: []
})

// 依赖选项（从后端预览获取）
const dependencyOptions = ref({
  jars: [],           // 可选的JAR列表
  packages: [],       // 可选的包名列表
  loading: false
})

// 状态
const analyzing = ref(false)
const progress = ref(0)
const progressText = ref('')
const result = ref(null)
const saved = ref(false)

// 详情
const activeTab = ref('all')
const apiDetailVisible = ref(false)
const selectedApi = ref(null)

// 源码差异
const sourceDiffFilter = ref('ALL')
const selectedSourceDiff = ref(null)

const filteredSourceDiffs = computed(() => {
  if (!result.value?.sourceDiffs) return []
  if (sourceDiffFilter.value === 'ALL') return result.value.sourceDiffs
  return result.value.sourceDiffs.filter(sd => sd.diffType === sourceDiffFilter.value)
})

// 保存
const saveDialogVisible = ref(false)
const saving = ref(false)
const saveForm = ref({
  description: ''
})

// 计算属性
const totalMethodChanges = computed(() => {
  const s = result.value?.fileSummary || {}
  return (s.totalMethodsAdded || 0) + (s.totalMethodsModified || 0) + (s.totalMethodsDeleted || 0)
})

const filteredApiDiffs = computed(() => {
  if (!result.value?.apiDiffs) return []
  if (activeTab.value === 'all') return result.value.apiDiffs
  return result.value.apiDiffs.filter(api => api.changeType === activeTab.value)
})

// 方法
const onBaselineChange = async (file) => {
  baselineFile.value = file.raw
  // 自动预览依赖
  if (depConfig.value.analyzeDependencies) {
    await previewDependenciesForFile(file.raw)
  }
}

const onTargetChange = async (file) => {
  targetFile.value = file.raw
  // 自动预览依赖
  if (depConfig.value.analyzeDependencies) {
    await previewDependenciesForFile(file.raw)
  }
}

// 当分析依赖开关改变时
const onAnalyzeDependenciesChange = async (value) => {
  if (value && (baselineFile.value || targetFile.value)) {
    // 开启时，如果已上传文件，自动预览
    if (baselineFile.value) {
      await previewDependenciesForFile(baselineFile.value)
    }
    if (targetFile.value) {
      await previewDependenciesForFile(targetFile.value)
    }
  }
}

// 预览依赖信息
const previewDependenciesForFile = async (file) => {
  if (!file) return

  dependencyOptions.value.loading = true
  try {
    const res = await diffAnalysisApi.previewDependencies(file)
    const data = res.data || res

    // 合并结果（去重）
    if (data.dependencyJars) {
      const newJars = new Set([...dependencyOptions.value.jars, ...data.dependencyJars])
      dependencyOptions.value.jars = Array.from(newJars).sort()
    }
    if (data.packages) {
      const newPackages = new Set([...dependencyOptions.value.packages, ...data.packages])
      dependencyOptions.value.packages = Array.from(newPackages).sort()
    }

    // 如果是多模块项目，自动开启分析开关
    if (data.isMultiModule && !depConfig.value.analyzeDependencies) {
      depConfig.value.analyzeDependencies = true
      ElMessage.info('检测到多模块项目，已自动启用依赖分析')
    }
  } catch (e) {
    console.error('预览依赖失败', e)
    // 预览失败不影响正常流程，只是无法提供选项
  } finally {
    dependencyOptions.value.loading = false
  }
}

const formatSize = (bytes) => {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
}

const startAnalysis = async () => {
  if (!baselineFile.value || !targetFile.value) {
    ElMessage.warning('请选择基线和目标文件')
    return
  }

  analyzing.value = true
  progress.value = 0
  progressText.value = '正在上传文件...'

  // 模拟进度
  const progressInterval = setInterval(() => {
    if (progress.value < 90) {
      progress.value += Math.random() * 10
      if (progress.value > 90) progress.value = 90
    }
  }, 500)

  try {
    progressText.value = '正在分析差异...'

    // 构建选项
    const options = {
      analyzeDependencies: depConfig.value.analyzeDependencies,
      includePackages: depConfig.value.includePackages,
      includeJarNames: depConfig.value.includeJarNames
    }

    const res = await diffAnalysisApi.quickDiff(baselineFile.value, targetFile.value, options)
    // 后端返回 Result<QuickDiffResponse>，需要从 data 字段获取实际数据
    result.value = res.data || res
    progress.value = 100
    progressText.value = '分析完成'
    ElMessage.success('差异对比完成')
  } catch (e) {
    console.error('差异对比失败', e)
    ElMessage.error('差异对比失败: ' + (e.message || '未知错误'))
  } finally {
    clearInterval(progressInterval)
    analyzing.value = false
  }
}

const resetAnalysis = () => {
  result.value = null
  baselineFile.value = null
  targetFile.value = null
  progress.value = 0
  activeTab.value = 'all'
  saved.value = false
  // 重置依赖分析配置
  depConfig.value = {
    analyzeDependencies: false,
    includePackages: [],
    includeJarNames: []
  }
  // 清空依赖选项
  dependencyOptions.value = {
    jars: [],
    packages: [],
    loading: false
  }
}

const showApiDetail = (api) => {
  selectedApi.value = api
  apiDetailVisible.value = true
}

// 标签类型
const getMethodTagType = (method) => {
  const types = { GET: 'success', POST: 'primary', PUT: 'warning', DELETE: 'danger' }
  return types[method] || 'info'
}

const getChangeTypeTag = (type) => {
  const types = { NEW_API: 'success', MODIFIED_API: 'warning', AFFECTED_API: 'info', DELETED_API: 'danger' }
  return types[type] || ''
}

const getChangeTypeLabel = (type) => {
  const labels = { NEW_API: '新增', MODIFIED_API: '修改', AFFECTED_API: '受影响', DELETED_API: '删除' }
  return labels[type] || type
}

const getRiskTagType = (level) => {
  const types = { HIGH: 'danger', MEDIUM: 'warning', LOW: 'info' }
  return types[level] || ''
}

const getDiffTypeTag = (type) => {
  const types = { ADDED: 'success', MODIFIED: 'warning', DELETED: 'danger', UNCHANGED: 'info' }
  return types[type] || ''
}

const getDiffTypeLabel = (type) => {
  const labels = { ADDED: '新增', MODIFIED: '修改', DELETED: '删除', UNCHANGED: '未变更' }
  return labels[type] || type
}

const getShortPath = (path) => {
  if (!path) return ''
  const parts = path.split('/')
  if (parts.length <= 3) return path
  return '.../' + parts.slice(-3).join('/')
}

// 图谱节点点击处理
const handleGraphNodeClick = (node) => {
  console.log('Clicked node:', node)
  // 可以扩展：点击节点后在表格中高亮对应的API或跳转到详情
  if (node.nodeType === 'api' && node.apiUrl) {
    const api = result.value.apiDiffs?.find(a => a.apiUrl === node.apiUrl)
    if (api) {
      selectedApi.value = api
      apiDetailVisible.value = true
    }
  }
}

// 保存相关方法
const showSaveDialog = () => {
  saveDialogVisible.value = true
  saveForm.value.description = ''
}

const saveResult = async () => {
  if (!baselineFile.value || !targetFile.value || !result.value) {
    ElMessage.warning('没有可保存的结果')
    return
  }

  saving.value = true
  try {
    // 构建选项
    const options = {
      analyzeDependencies: depConfig.value.analyzeDependencies,
      includePackages: depConfig.value.includePackages,
      includeJarNames: depConfig.value.includeJarNames
    }

    await diffAnalysisApi.quickDiffSave(
      baselineFile.value,
      targetFile.value,
      saveForm.value.description,
      options
    )
    saved.value = true
    saveDialogVisible.value = false
    ElMessage.success('保存成功')
  } catch (e) {
    console.error('保存失败', e)
    ElMessage.error('保存失败: ' + (e.message || '未知错误'))
  } finally {
    saving.value = false
  }
}
</script>

<style scoped>
.quick-diff {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.file-info {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 10px;
  padding: 10px;
  background: #f5f7fa;
  border-radius: 4px;
}

.file-size {
  color: #909399;
  font-size: 12px;
}

.actions {
  margin-top: 20px;
  text-align: center;
}

.progress-container {
  padding: 40px 20px;
  text-align: center;
}

.progress-text {
  margin-top: 15px;
  color: #666;
}

.summary-section {
  padding: 10px 0;
}

.summary-section h3 {
  margin-bottom: 15px;
  color: #303133;
}

.stat-box {
  text-align: center;
  padding: 20px;
  border-radius: 8px;
  background: #f5f7fa;
}

.stat-box.high {
  background: #fef0f0;
}

.stat-box.medium {
  background: #fdf6ec;
}

.stat-box.low {
  background: #f0f9eb;
}

.stat-box .label {
  font-size: 14px;
  color: #666;
}

.stat-box .value {
  font-size: 28px;
  font-weight: bold;
  margin-top: 5px;
}

.detail-section h3 {
  margin-bottom: 15px;
  color: #303133;
}

.added {
  color: #67C23A;
  margin-right: 10px;
}

.modified {
  color: #E6A23C;
  margin-right: 10px;
}

.deleted {
  color: #F56C6C;
}

.call-chain {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 5px;
}

.call-chain .node {
  padding: 2px 8px;
  background: #f0f2f5;
  border-radius: 4px;
  font-size: 12px;
}

.call-chain .arrow {
  color: #409EFF;
}

.method-changes {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.method-tag {
  font-size: 11px;
}

.method-tag.clickable {
  cursor: pointer;
}

.method-tag.clickable:hover {
  opacity: 0.8;
}

.method-popover {
  max-height: 400px;
  overflow-y: auto;
}

.method-popover-header {
  font-weight: bold;
  margin-bottom: 10px;
  padding-bottom: 8px;
  border-bottom: 1px solid #ebeef5;
}

.method-popover-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.method-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 4px 0;
}

.method-name {
  font-family: monospace;
  font-size: 13px;
  word-break: break-all;
}

.source-diff-layout {
  display: flex;
  gap: 16px;
  height: 600px;
}

.source-diff-file-list {
  width: 300px;
  flex-shrink: 0;
  border: 1px solid #e4e7ed;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.file-list-header {
  padding: 10px;
  border-bottom: 1px solid #e4e7ed;
  background: #fafafa;
}

.file-list-items {
  flex: 1;
  overflow-y: auto;
}

.file-list-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  cursor: pointer;
  border-bottom: 1px solid #f0f2f5;
  transition: background 0.2s;
}

.file-list-item:hover {
  background: #f5f7fa;
}

.file-list-item.active {
  background: #ecf5ff;
}

.file-diff-type {
  flex-shrink: 0;
}

.file-list-path {
  font-family: 'SFMono-Regular', Consolas, monospace;
  font-size: 12px;
  color: #606266;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.source-diff-viewer {
  flex: 1;
  overflow: hidden;
  border: 1px solid #e4e7ed;
  border-radius: 4px;
}
</style>
