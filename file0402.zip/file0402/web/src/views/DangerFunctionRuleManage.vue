<template>
  <div class="danger-rule-manage">
    <el-card shadow="never">
      <template #header>
        <div class="card-header">
          <span>危险函数规则管理</span>
          <el-button type="primary" @click="showCreateDialog">
            <el-icon><Plus /></el-icon>
            新建规则
          </el-button>
        </div>
      </template>

      <!-- Filter -->
      <el-form :inline="true" class="filter-form">
        <el-form-item label="函数类型">
          <el-select v-model="filterType" placeholder="全部类型" clearable @change="loadRules">
            <el-option v-for="type in functionTypes" :key="type" :label="type" :value="type" />
          </el-select>
        </el-form-item>
      </el-form>

      <el-table :data="rules" v-loading="loading" style="width: 100%">
        <el-table-column prop="ruleName" label="规则名称" min-width="180" />
        <el-table-column prop="functionType" label="函数类型" width="150">
          <template #default="{ row }">
            <el-tag size="small">{{ row.functionType }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="classPattern" label="类模式" min-width="180" />
        <el-table-column prop="methodPattern" label="方法模式" width="120" />
        <el-table-column prop="riskLevel" label="风险等级" width="100">
          <template #default="{ row }">
            <el-tag :type="getRiskTagType(row.riskLevel)" size="small">
              {{ row.riskLevel }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="cweId" label="CWE" width="100" />
        <el-table-column prop="enabled" label="状态" width="80">
          <template #default="{ row }">
            <el-switch v-model="row.enabled" @change="handleToggle(row)" />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link @click="showEditDialog(row)">编辑</el-button>
            <el-button type="danger" link @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Create/Edit Dialog -->
    <el-dialog v-model="dialogVisible" :title="isEdit ? '编辑规则' : '新建规则'" width="700px">
      <el-form :model="form" :rules="formRules" ref="formRef" label-width="100px">
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="规则名称" prop="ruleName">
              <el-input v-model="form.ruleName" placeholder="如: Runtime.exec" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="函数类型" prop="functionType">
              <el-select v-model="form.functionType" placeholder="请选择类型" style="width: 100%">
                <el-option label="命令执行" value="COMMAND_EXECUTION" />
                <el-option label="反序列化" value="DESERIALIZATION" />
                <el-option label="文件操作" value="FILE_IO" />
                <el-option label="SQL注入" value="SQL_INJECTION" />
                <el-option label="SSRF" value="SSRF" />
                <el-option label="XXE" value="XXE" />
                <el-option label="反射" value="REFLECTION" />
                <el-option label="其他" value="OTHER" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="风险等级" prop="riskLevel">
              <el-select v-model="form.riskLevel" placeholder="请选择风险等级" style="width: 100%">
                <el-option label="高" value="HIGH" />
                <el-option label="中" value="MEDIUM" />
                <el-option label="低" value="LOW" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="CWE编号">
              <el-input v-model="form.cweId" placeholder="如: CWE-78" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="类模式" prop="classPattern">
          <el-input v-model="form.classPattern" placeholder="类匹配模式，如: java/lang/Runtime, *ObjectInputStream" />
        </el-form-item>
        <el-form-item label="方法模式" prop="methodPattern">
          <el-input v-model="form.methodPattern" placeholder="方法匹配模式，如: exec, readObject, *(匹配所有)" />
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="form.description" type="textarea" :rows="2" placeholder="规则描述" />
        </el-form-item>
        <el-form-item label="安全影响">
          <el-input v-model="form.securityImpact" type="textarea" :rows="2" placeholder="安全影响说明" />
        </el-form-item>
        <el-form-item label="修复建议">
          <el-input v-model="form.remediation" type="textarea" :rows="2" placeholder="修复建议" />
        </el-form-item>
        <el-form-item label="参考资料">
          <el-input v-model="form.references" type="textarea" :rows="2" placeholder="参考链接" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm" :loading="submitting">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import dangerFunctionRuleApi from '@/api/dangerFunctionRule'

const loading = ref(false)
const rules = ref([])
const functionTypes = ref([])
const filterType = ref('')

const dialogVisible = ref(false)
const isEdit = ref(false)
const submitting = ref(false)
const formRef = ref(null)

const form = reactive({
  id: null,
  ruleName: '',
  functionType: '',
  classPattern: '',
  methodPattern: '',
  description: '',
  riskLevel: 'HIGH',
  securityImpact: '',
  remediation: '',
  cweId: '',
  references: '',
  enabled: true
})

const formRules = {
  ruleName: [{ required: true, message: '请输入规则名称', trigger: 'blur' }],
  functionType: [{ required: true, message: '请选择函数类型', trigger: 'change' }],
  classPattern: [{ required: true, message: '请输入类模式', trigger: 'blur' }],
  methodPattern: [{ required: true, message: '请输入方法模式', trigger: 'blur' }],
  riskLevel: [{ required: true, message: '请选择风险等级', trigger: 'change' }]
}

const loadRules = async () => {
  loading.value = true
  try {
    if (filterType.value) {
      rules.value = await dangerFunctionRuleApi.getByType(filterType.value)
    } else {
      rules.value = await dangerFunctionRuleApi.getList()
    }
  } catch (e) {
    console.error('Failed to load rules:', e)
  } finally {
    loading.value = false
  }
}

const loadFunctionTypes = async () => {
  try {
    functionTypes.value = await dangerFunctionRuleApi.getFunctionTypes()
  } catch (e) {
    console.error('Failed to load function types:', e)
  }
}

const showCreateDialog = () => {
  isEdit.value = false
  Object.assign(form, {
    id: null,
    ruleName: '',
    functionType: '',
    classPattern: '',
    methodPattern: '',
    description: '',
    riskLevel: 'HIGH',
    securityImpact: '',
    remediation: '',
    cweId: '',
    references: '',
    enabled: true
  })
  dialogVisible.value = true
}

const showEditDialog = (row) => {
  isEdit.value = true
  Object.assign(form, {
    id: row.id,
    ruleName: row.ruleName,
    functionType: row.functionType,
    classPattern: row.classPattern,
    methodPattern: row.methodPattern,
    description: row.description || '',
    riskLevel: row.riskLevel,
    securityImpact: row.securityImpact || '',
    remediation: row.remediation || '',
    cweId: row.cweId || '',
    references: row.references || '',
    enabled: row.enabled
  })
  dialogVisible.value = true
}

const submitForm = async () => {
  await formRef.value.validate()
  submitting.value = true
  try {
    if (isEdit.value) {
      await dangerFunctionRuleApi.update(form.id, form)
      ElMessage.success('更新成功')
    } else {
      await dangerFunctionRuleApi.create(form)
      ElMessage.success('创建成功')
    }
    dialogVisible.value = false
    loadRules()
  } catch (e) {
    console.error('Failed to submit:', e)
  } finally {
    submitting.value = false
  }
}

const handleDelete = async (row) => {
  await ElMessageBox.confirm(`确定删除规则 "${row.ruleName}" 吗？`, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
  try {
    await dangerFunctionRuleApi.delete(row.id)
    ElMessage.success('删除成功')
    loadRules()
  } catch (e) {
    console.error('Failed to delete:', e)
  }
}

const handleToggle = async (row) => {
  try {
    await dangerFunctionRuleApi.toggle(row.id, row.enabled)
    ElMessage.success(row.enabled ? '已启用' : '已禁用')
  } catch (e) {
    row.enabled = !row.enabled
    console.error('Failed to toggle:', e)
  }
}

const getRiskTagType = (level) => {
  const types = { HIGH: 'danger', MEDIUM: 'warning', LOW: 'info' }
  return types[level] || 'info'
}

onMounted(() => {
  loadRules()
  loadFunctionTypes()
})
</script>

<style lang="scss" scoped>
.danger-rule-manage {
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .filter-form {
    margin-bottom: 16px;
  }
}
</style>
