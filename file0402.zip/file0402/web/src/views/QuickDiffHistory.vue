<template>
  <div class="quick-diff-history">
    <el-card shadow="never">
      <template #header>
        <div class="card-header">
          <span>快速对比历史</span>
          <el-button type="primary" @click="$router.push('/quick-diff')">
            新建对比
          </el-button>
        </div>
      </template>

      <el-table :data="records" style="width: 100%" v-loading="loading">
        <el-table-column prop="baselineFileName" label="基线文件" min-width="150" show-overflow-tooltip />
        <el-table-column prop="targetFileName" label="目标文件" min-width="150" show-overflow-tooltip />
        <el-table-column label="文件变更" width="100">
          <template #default="{ row }">
            <span class="stat">{{ row.totalFilesChanged }}</span>
          </template>
        </el-table-column>
        <el-table-column label="方法变更" width="100">
          <template #default="{ row }">
            <span class="stat">{{ row.totalMethodChanges }}</span>
          </template>
        </el-table-column>
        <el-table-column label="API变更" width="100">
          <template #default="{ row }">
            <span class="stat">{{ row.totalApiChanges }}</span>
          </template>
        </el-table-column>
        <el-table-column label="高风险API" width="100">
          <template #default="{ row }">
            <el-tag v-if="row.highRiskApis > 0" type="danger" size="small">
              {{ row.highRiskApis }}
            </el-tag>
            <span v-else>-</span>
          </template>
        </el-table-column>
        <el-table-column prop="durationMs" label="耗时" width="100">
          <template #default="{ row }">
            {{ (row.durationMs / 1000).toFixed(2) }}s
          </template>
        </el-table-column>
        <el-table-column prop="createdAt" label="创建时间" width="160">
          <template #default="{ row }">
            {{ formatTime(row.createdAt) }}
          </template>
        </el-table-column>
        <el-table-column prop="description" label="描述" min-width="200" show-overflow-tooltip />
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link @click="viewDetail(row.id)">查看</el-button>
            <el-button type="danger" link @click="deleteRecord(row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import diffAnalysisApi from '@/api/diffAnalysis'
import { useRouter } from 'vue-router'

const router = useRouter()
const loading = ref(true)
const records = ref([])

const loadData = async () => {
  try {
    const res = await diffAnalysisApi.getQuickDiffList()
    records.value = res.data || []
  } catch (e) {
    console.error('加载历史记录失败', e)
    ElMessage.error('加载失败: ' + (e.message || '未知错误'))
  } finally {
    loading.value = false
  }
}

const viewDetail = (id) => {
  router.push(`/quick-diff/${id}`)
}

const deleteRecord = async (id) => {
  try {
    await ElMessageBox.confirm('确定要删除这条记录吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })

    await diffAnalysisApi.deleteQuickDiff(id)
    ElMessage.success('删除成功')
    await loadData()
  } catch (e) {
    console.error('删除失败', e)
    ElMessage.error('删除失败: ' + (e.message || '未知错误'))
  }
}

const formatTime = (time) => {
  if (!time) return '-'
  const date = new Date(time)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  }).replace(/\//g, '-')
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.quick-diff-history {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.stat {
  font-weight: 500;
}
</style>
