<template>
  <el-container class="app-layout">
    <el-aside :width="isCollapsed ? '64px' : '220px'" class="sidebar">
      <Sidebar :is-collapsed="isCollapsed" />
    </el-aside>
    <el-container>
      <el-header class="header" height="60px">
        <Header />
      </el-header>
      <el-main class="main-content">
        <slot />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import { computed } from 'vue'
import Sidebar from './Sidebar.vue'
import Header from './Header.vue'
import { useLayoutStore } from '@/stores/layout'

const layoutStore = useLayoutStore()
const isCollapsed = computed(() => layoutStore.isCollapsed)
</script>

<style lang="scss" scoped>
.app-layout {
  height: 100vh;
}

.sidebar {
  background-color: #304156;
  overflow: hidden;
  transition: width 0.3s ease-in-out;
}

.header {
  background-color: #fff;
  border-bottom: 1px solid #dcdfe6;
  padding: 0 20px;
  display: flex;
  align-items: center;
}

.main-content {
  background-color: #f5f7fa;
  padding: 20px;
  overflow-y: auto;
}
</style>
