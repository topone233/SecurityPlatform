<template>
  <div class="recommendation-panel">
    <!-- 风险预警卡片 -->
    <el-card shadow="never" class="warning-card">
      <template #header>
        <div class="card-title">
          <el-icon><WarningFilled /></el-icon>
          <span>风险预警</span>
          <el-badge :value="warnings.length" type="danger" />
        </div>
      </template>
      <el-empty v-if="warnings.length === 0" description="暂无风险预警" :image-size="80" />
      <el-timeline v-else>
        <el-timeline-item
          v-for="warning in warnings"
          :key="warning.id"
          :type="getWarningType(warning.level)"
        >
          <div class="warning-item">
            <div class="warning-header">
              <el-tag :type="getWarningTagType(warning.level)" size="small">
                {{ warning.level }}
              </el-tag>
              <el-tag :type="getWarningTypeTag(warning.type)" size="small">
                {{ getWarningTypeText(warning.type) }}
              </el-tag>
            </div>
            <div class="warning-title">{{ warning.title }}</div>
            <div class="warning-desc">{{ warning.description }}</div>
            <div class="warning-location" v-if="warning.className">
              <el-tag size="small" effect="plain">{{ warning.className }}</el-tag>
              <el-tag v-if="warning.methodName" size="small" type="info" effect="plain">
                {{ warning.methodName }}()
              </el-tag>
            </div>
          </div>
        </el-timeline-item>
      </el-timeline>
    </el-card>

    <!-- 优先测试推荐 -->
    <el-card shadow="never" class="priority-card">
      <template #header>
        <div class="card-title">
          <el-icon><Aim /></el-icon>
          <span>优先测试推荐</span>
          <el-badge :value="priorityItems.length" type="warning" />
        </div>
      </template>
      <el-empty v-if="priorityItems.length === 0" description="暂无优先测试项" :image-size="80" />
      <el-table v-else :data="priorityItems" style="width: 100%">
        <el-table-column prop="priority" label="优先级" width="80">
          <template #default="{ row }">
            <el-tag :type="getPriorityType(row.priority)">
              P{{ row.priority }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="changeType" label="变更类型" width="100">
          <template #default="{ row }">
            <el-tag size="small">{{ formatChangeType(row.changeType) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="method" label="方法" show-overflow-tooltip />
        <el-table-column prop="affectedApis" label="影响范围" width="120">
          <template #default="{ row }">
            <el-tag size="small" type="info">{{ row.affectedApis }}个API</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="100">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="viewInGraph(row)">
              查看图谱
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 测试建议 -->
    <el-card shadow="never" class="suggestion-card" v-if="testSuggestions">
      <template #header>
        <div class="card-title">
          <el-icon><Document /></el-icon>
          <span>测试建议</span>
        </div>
      </template>
      <el-descriptions :column="1" border>
        <el-descriptions-item label="推荐测试用例类型">
          <el-tag
            v-for="type in testSuggestions.caseTypes"
            :key="type"
            style="margin-right: 8px"
          >
            {{ type }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="测试重点">
          {{ testSuggestions.focusPoints }}
        </el-descriptions-item>
        <el-descriptions-item label="预估工作量">
          <el-tag type="warning">{{ testSuggestions.estimatedEffort }}</el-tag>
        </el-descriptions-item>
      </el-descriptions>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { WarningFilled, Aim, Document } from '@element-plus/icons-vue'
import diffAnalysisApi from '@/api/diffAnalysis'

const props = defineProps({
  diffTaskId: {
    type: [Number, String],
    required: true
  }
})

const emit = defineEmits(['view-graph'])

const warnings = ref([])
const priorityItems = ref([])
const testSuggestions = ref(null)

const loadRecommendations = async () => {
  try {
    const response = await diffAnalysisApi.getRecommendations(props.diffTaskId)
    warnings.value = response.warnings || []
    priorityItems.value = response.priorityItems || []
    testSuggestions.value = response.testSuggestions
  } catch (e) {
    console.error('Failed to load recommendations:', e)
  }
}

const getWarningType = (level) => {
  const types = {
    HIGH: 'danger',
    MEDIUM: 'warning',
    LOW: 'info'
  }
  return types[level] || 'info'
}

const getWarningTagType = (level) => {
  const types = {
    HIGH: 'danger',
    MEDIUM: 'warning',
    LOW: 'info'
  }
  return types[level] || 'info'
}

const getWarningTypeTag = (type) => {
  const types = {
    SECURITY: 'danger',
    COMPATIBILITY: 'warning',
    PERFORMANCE: 'info'
  }
  return types[type] || 'info'
}

const getWarningTypeText = (type) => {
  const texts = {
    SECURITY: '安全风险',
    COMPATIBILITY: '兼容性风险',
    PERFORMANCE: '性能风险'
  }
  return texts[type] || type
}

const getPriorityType = (priority) => {
  if (priority <= 2) return 'danger'
  if (priority <= 4) return 'warning'
  return 'info'
}

const formatChangeType = (type) => {
  const texts = {
    ADDED: '新增',
    MODIFIED: '修改',
    DELETED: '删除',
    NEW_API: '新增API',
    MODIFIED_API: '修改API',
    DELETED_API: '删除API',
    AFFECTED_API: '受影响API'
  }
  return texts[type] || type
}

const viewInGraph = (row) => {
  emit('view-graph', row.changeId)
}

onMounted(() => {
  loadRecommendations()
})
</script>

<style lang="scss" scoped>
.recommendation-panel {
  .warning-card,
  .priority-card,
  .suggestion-card {
    margin-bottom: 20px;
  }

  .card-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 16px;
    font-weight: 600;

    .el-icon {
      font-size: 18px;
    }
  }

  .warning-item {
    .warning-header {
      display: flex;
      gap: 8px;
      margin-bottom: 8px;
    }

    .warning-title {
      font-weight: 600;
      margin-bottom: 4px;
    }

    .warning-desc {
      color: #606266;
      font-size: 14px;
      margin-bottom: 8px;
    }

    .warning-location {
      display: flex;
      gap: 8px;
    }
  }
}
</style>