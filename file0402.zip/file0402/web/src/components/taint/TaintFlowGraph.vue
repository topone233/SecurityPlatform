<template>
  <div class="taint-flow-graph">
    <div ref="graphContainer" class="graph-container"></div>
    <div v-if="loading" class="loading-overlay">
      <el-icon class="is-loading"><Loading /></el-icon>
      <span>加载中...</span>
    </div>
    <div v-if="!loading && (!paths || paths.length === 0)" class="empty-state">
      <el-empty description="无可达路径" />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, onUnmounted } from 'vue'
import { Graph } from '@antv/g6'
import { Loading } from '@element-plus/icons-vue'

const props = defineProps({
  sinkData: {
    type: Object,
    default: () => ({})
  },
  paths: {
    type: Array,
    default: () => []
  },
  loading: {
    type: Boolean,
    default: false
  }
})

const graphContainer = ref(null)
let graph = null

onMounted(() => {
  initGraph()
})

onUnmounted(() => {
  if (graph) {
    graph.destroy()
  }
})

watch(() => props.paths, () => {
  if (graph && props.paths && props.paths.length > 0) {
    updateGraph()
  }
}, { deep: true })

function initGraph() {
  if (!graphContainer.value) return

  const width = graphContainer.value.offsetWidth
  const height = graphContainer.value.offsetHeight || 400

  graph = new Graph({
    container: graphContainer.value,
    width,
    height,
    autoFit: 'view',
    padding: 20,
    behaviors: ['drag-canvas', 'zoom-canvas', 'drag-element'],
    layout: {
      type: 'dagre',
      rankdir: 'TB',
      nodesep: 60,
      ranksep: 80
    },
    node: {
      style: {
        size: (d) => {
          const label = d.data?.label || ''
          const lines = label.split('\n').length
          return [Math.max(100, label.length * 8), 20 + lines * 16]
        },
        fill: (d) => {
          const type = d.data?.nodeType
          if (type === 'source') return '#FFCDD2'
          if (type === 'sink') return '#FFE0B2'
          return '#E3F2FD'
        },
        stroke: (d) => {
          const type = d.data?.nodeType
          if (type === 'source') return '#E53935'
          if (type === 'sink') return '#FF9800'
          return '#2196F3'
        },
        lineWidth: 2,
        radius: 4,
        labelText: (d) => d.data?.label || '',
        labelFill: '#333',
        labelFontSize: 12,
        labelPlacement: 'center'
      }
    },
    edge: {
      style: {
        stroke: (d) => d.data?.isLast ? '#E53935' : '#5B8FF9',
        lineWidth: (d) => d.data?.isLast ? 3 : 2,
        endArrow: true
      }
    }
  })

  // 初始渲染
  if (props.paths && props.paths.length > 0) {
    updateGraph()
  }
}

function updateGraph() {
  if (!graph) return

  const data = transformToGraphData(props.paths, props.sinkData)
  graph.setData(data)
  graph.render()
}

function transformToGraphData(paths, sinkData) {
  const nodes = []
  const edges = []
  const nodeMap = new Map()

  paths.forEach((path, pathIndex) => {
    // 1. Source节点（Controller入口）
    const sourceId = `source-${path.sourceClass}-${path.sourceMethod}-${pathIndex}`
    if (!nodeMap.has(sourceId)) {
      nodeMap.set(sourceId, true)
      nodes.push({
        id: sourceId,
        data: {
          label: formatNodeLabel(path.sourceClass, path.sourceMethod),
          nodeType: 'source'
        }
      })
    }

    // 2. Sink节点
    const sinkId = `sink-${sinkData.sinkClass}-${sinkData.sinkMethod}`
    if (!nodeMap.has(sinkId)) {
      nodeMap.set(sinkId, true)
      nodes.push({
        id: sinkId,
        data: {
          label: formatNodeLabel(sinkData.sinkClass, sinkData.sinkMethod),
          nodeType: 'sink'
        }
      })
    }

    // 3. 中间节点和边
    let prevId = sourceId
    if (path.callChain && path.callChain.length > 0) {
      path.callChain.forEach((node, nodeIndex) => {
        const nodeId = `node-${node.className}-${node.methodName}-${pathIndex}-${nodeIndex}`
        if (!nodeMap.has(nodeId)) {
          nodeMap.set(nodeId, true)
          nodes.push({
            id: nodeId,
            data: {
              label: formatNodeLabel(node.className, node.methodName),
              nodeType: 'intermediate'
            }
          })
        }

        edges.push({
          id: `edge-${prevId}-${nodeId}`,
          source: prevId,
          target: nodeId,
          data: { isLast: false }
        })
        prevId = nodeId
      })
    }

    // 最后一条边连接到sink
    edges.push({
      id: `edge-${prevId}-${sinkId}`,
      source: prevId,
      target: sinkId,
      data: { isLast: true }
    })
  })

  return { nodes, edges }
}

function formatNodeLabel(className, methodName) {
  // 简化类名显示
  const shortClass = className.split('.').pop()
  return `${shortClass}\n${methodName}()`
}
</script>

<style scoped>
.taint-flow-graph {
  width: 100%;
  height: 100%;
  position: relative;
  background: #fafafa;
  border-radius: 4px;
}

.graph-container {
  width: 100%;
  height: 400px;
}

.loading-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(255, 255, 255, 0.8);
  z-index: 10;
}

.empty-state {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
</style>