<template>
  <div class="evidence-upload">
    <el-upload
      ref="uploadRef"
      :action="uploadAction"
      :headers="uploadHeaders"
      :on-success="handleSuccess"
      :on-error="handleError"
      :on-remove="handleRemove"
      :file-list="fileList"
      :multiple="true"
      :limit="10"
      accept=".jpg,.jpeg,.png,.pdf,.txt,.log"
      list-type="picture-card"
    >
      <el-icon><Plus /></el-icon>
      <template #tip>
        <div class="el-upload__tip">
          支持jpg/png/pdf/txt/log文件，最多10个
        </div>
      </template>
    </el-upload>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'

const props = defineProps({
  modelValue: {
    type: String,
    default: ''
  },
  executionId: {
    type: [Number, String],
    required: true
  }
})

const emit = defineEmits(['update:modelValue'])

const uploadRef = ref(null)
const fileList = ref([])

// 解析已有文件
watch(() => props.modelValue, (newVal) => {
  if (newVal) {
    try {
      const files = JSON.parse(newVal)
      fileList.value = files.map(f => ({
        name: f.fileName,
        url: f.fileUrl,
        uid: f.id
      }))
    } catch (e) {
      fileList.value = []
    }
  } else {
    fileList.value = []
  }
}, { immediate: true })

const uploadAction = computed(() => `/api/evidence/upload/${props.executionId}`)
const uploadHeaders = computed(() => ({
  // 可添加认证token
}))

const handleSuccess = (response, file, fileList) => {
  if (response.code === 200) {
    ElMessage.success('文件上传成功')
    updateFileList(fileList)
  } else {
    ElMessage.error(response.message || '上传失败')
  }
}

const handleError = (error, file) => {
  ElMessage.error(`文件 ${file.name} 上传失败`)
}

const handleRemove = (file, fileList) => {
  updateFileList(fileList)
}

const updateFileList = (list) => {
  const evidenceFiles = list.map(f => ({
    id: f.response?.data?.id || f.uid,
    fileName: f.name,
    fileUrl: f.response?.data?.fileUrl || f.url,
    fileSize: f.size,
    uploadedAt: new Date().toISOString()
  }))
  emit('update:modelValue', JSON.stringify(evidenceFiles))
}
</script>

<style lang="scss" scoped>
.evidence-upload {
  :deep(.el-upload-list--picture-card .el-upload-list__item) {
    width: 100px;
    height: 100px;
  }
}
</style>