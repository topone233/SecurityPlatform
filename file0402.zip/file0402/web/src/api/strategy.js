import api from './index'

export default {
  // Get test checklist by artifact ID
  getChecklist(artifactId) {
    return api.get(`/strategy/checklist/${artifactId}`)
  },

  // Update checklist item status
  updateItemStatus(checklistId, data) {
    const params = new URLSearchParams()
    params.append('status', data.status)
    if (data.testResult) params.append('testResult', data.testResult)
    if (data.testNotes) params.append('testNotes', data.testNotes)
    return api.put(`/strategy/checklist/${checklistId}/status`, null, { params })
  },

  // Batch update checklist items
  batchUpdateStatus(artifactId, items) {
    return api.put(`/strategy/checklist/${artifactId}/batch`, items)
  },

  // Generate test strategy
  generateStrategy(artifactId) {
    return api.post(`/strategy/generate/${artifactId}`)
  },

  // Get strategy detail
  getStrategy(artifactId) {
    return api.get(`/strategy/${artifactId}`)
  }
}
