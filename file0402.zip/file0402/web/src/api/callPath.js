import request from './index'

/**
 * 调用链路分析API
 */
export default {
  /**
   * 查询调用路径
   * @param {object} params 查询参数
   * @returns {Promise} 调用路径响应
   */
  queryPath(params) {
    return request.post('/call-path/query', params, {
      timeout: 60000 // 1分钟超时
    })
  },

  /**
   * 搜索方法（自动补全）
   * @param {number} artifactId 制品ID
   * @param {string} keyword 关键字
   * @param {number} limit 返回数量限制
   * @returns {Promise} 方法建议列表
   */
  searchMethods(artifactId, keyword, limit = 20) {
    return request.get('/call-path/search-methods', {
      params: { artifactId, keyword, limit }
    })
  }
}