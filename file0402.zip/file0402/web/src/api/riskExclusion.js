import api from './index'

export default {
  // Get risk exclusions by artifact ID
  getList(artifactId) {
    return api.get(`/risk-exclusion/list/${artifactId}`)
  },

  // Get pending review exclusions
  getPendingReview(artifactId) {
    return api.get(`/risk-exclusion/pending-review/${artifactId}`)
  },

  // Approve risk exclusion
  approve(exclusionId, reviewer, notes) {
    const params = new URLSearchParams()
    params.append('status', 'APPROVED')
    if (reviewer) params.append('reviewer', reviewer)
    if (notes) params.append('notes', notes)
    return api.put(`/risk-exclusion/review/${exclusionId}`, null, { params })
  },

  // Reject risk exclusion
  reject(exclusionId, reviewer, notes) {
    const params = new URLSearchParams()
    params.append('status', 'REJECTED')
    if (reviewer) params.append('reviewer', reviewer)
    if (notes) params.append('notes', notes)
    return api.put(`/risk-exclusion/review/${exclusionId}`, null, { params })
  },

  // Perform risk exclusion analysis
  analyze(artifactId) {
    return api.post(`/risk-exclusion/analyze/${artifactId}`)
  },

  // Get risk exclusion statistics
  getStatistics(artifactId) {
    return api.get(`/risk-exclusion/statistics/${artifactId}`)
  }
}