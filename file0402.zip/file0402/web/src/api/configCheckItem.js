import api from './index'

export default {
  // 获取所有配置检查项
  getList() {
    return api.get('/strategy/config-items')
  },

  // 获取配置检查项详情
  getById(id) {
    return api.get(`/strategy/config-items/${id}`)
  },

  // 创建配置检查项
  create(data) {
    return api.post('/strategy/config-items', data)
  },

  // 更新配置检查项
  update(id, data) {
    return api.put(`/strategy/config-items/${id}`, data)
  },

  // 删除配置检查项
  delete(id) {
    return api.delete(`/strategy/config-items/${id}`)
  },

  // 按类别获取配置检查项
  getByCategory(category) {
    return api.get(`/strategy/config-items/by-category/${category}`)
  },

  // 获取所有配置检查类别
  getCategories() {
    return api.get('/strategy/config-categories')
  }
}
