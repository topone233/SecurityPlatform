import api from './index'

export default {
  // 获取所有规则
  getList() {
    return api.get('/danger-function-rules')
  },

  // 获取启用的规则
  getEnabled() {
    return api.get('/danger-function-rules/enabled')
  },

  // 获取规则详情
  getById(id) {
    return api.get(`/danger-function-rules/${id}`)
  },

  // 创建规则
  create(data) {
    return api.post('/danger-function-rules', data)
  },

  // 更新规则
  update(id, data) {
    return api.put(`/danger-function-rules/${id}`, data)
  },

  // 删除规则
  delete(id) {
    return api.delete(`/danger-function-rules/${id}`)
  },

  // 切换规则状态
  toggle(id, enabled) {
    return api.put(`/danger-function-rules/${id}/toggle?enabled=${enabled}`)
  },

  // 按类型获取规则
  getByType(type) {
    return api.get(`/danger-function-rules/by-type/${type}`)
  },

  // 获取所有函数类型
  getFunctionTypes() {
    return api.get('/danger-function-rules/function-types')
  }
}
