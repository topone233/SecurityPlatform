/**
 * Generated API 配置
 * 用于配置 OpenAPI 客户端基础设置
 */
import { OpenAPI } from './generated'

// 生成的 URL 已包含 /api 前缀，BASE 设置为空
// 开发环境通过 Vite 代理 /api -> http://localhost:8001/api
OpenAPI.BASE = ''

// 可选：添加请求拦截器
// OpenAPI.interceptors?.request?.use(config => {
//   // 添加 token 等
//   return config
// })

export * from './generated'
