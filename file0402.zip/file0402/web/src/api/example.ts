/**
 * API 使用示例
 *
 * 本文件展示如何使用生成的 API 客户端
 * 可以删除此文件，仅供参考
 */

// 方式1: 直接使用 Service 类
import { Service, type ProjectResponse, type CreateProjectRequest } from './client'

// 获取所有项目
export async function getAllProjects(): Promise<ProjectResponse[]> {
  // 注意：后端返回的是 Result<List<ProjectResponse>>
  // 生成的类型是 ResultListProjectResponse，需要提取 data
  const result = await Service.getAllProjects()
  return result.data || []
}

// 创建项目
export async function createProject(request: CreateProjectRequest): Promise<ProjectResponse> {
  const result = await Service.createProject(request)
  return result.data!
}

// 方式2: 在组件中直接使用
/*
<script setup lang="ts">
import { Service, type ProjectResponse } from '@/api/client'

const projects = ref<ProjectResponse[]>([])

async function loadProjects() {
  try {
    const result = await Service.getAllProjects()
    projects.value = result.data || []
  } catch (error) {
    console.error('加载项目失败', error)
  }
}

async function createProject() {
  // ✅ 类型安全：字段名错误会编译报错
  await Service.createProject({
    projectName: '新项目',  // 正确
    // name: 'xxx',        // ❌ 错误：TypeScript 会报错
    description: '描述'
  })
}
</script>
*/

// 方式3: 封装成独立模块（推荐）
/*
// src/api/projectApi.ts
import { Service, type ProjectResponse, type CreateProjectRequest } from './client'

export const projectApi = {
  async getAll() {
    const result = await Service.getAllProjects()
    return result.data || []
  },

  async getById(id: number) {
    const result = await Service.getProjectById(id)
    return result.data
  },

  async create(request: CreateProjectRequest) {
    const result = await Service.createProject(request)
    return result.data
  },

  async delete(id: number) {
    await Service.deleteProject(id)
  }
}

// 使用
import { projectApi } from '@/api/projectApi'
const projects = await projectApi.getAll()
*/
