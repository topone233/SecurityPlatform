/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RiskExclusionResponse } from './RiskExclusionResponse';
export type ResultListRiskExclusionResponse = {
    code?: number;
    message?: string;
    data?: Array<RiskExclusionResponse>;
};

