/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type TestChecklistResponse = {
    id?: number;
    artifactId?: number;
    testCaseId?: number;
    caseName?: string;
    vulnerabilityType?: string;
    riskLevel?: string;
    matchedComponent?: string;
    matchedDangerFunction?: string;
    matchedConfigKey?: string;
    status?: string;
    exclusionReason?: string;
    exclusionRuleId?: number;
    testResult?: string;
    testNotes?: string;
    testedBy?: string;
    testedAt?: string;
    createdAt?: string;
};

