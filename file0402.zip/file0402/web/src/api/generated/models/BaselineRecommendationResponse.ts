/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { BaselineArtifact } from './BaselineArtifact';
export type BaselineRecommendationResponse = {
    projectId?: number;
    projectName?: string;
    recommended?: BaselineArtifact;
    history?: Array<BaselineArtifact>;
};

