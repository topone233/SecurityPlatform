/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ResultListString = {
    code?: number;
    message?: string;
    data?: Array<string>;
};

