/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ResultObject = {
    code?: number;
    message?: string;
    data?: Record<string, any>;
};

