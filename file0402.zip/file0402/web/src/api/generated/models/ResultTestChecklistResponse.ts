/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { TestChecklistResponse } from './TestChecklistResponse';
export type ResultTestChecklistResponse = {
    code?: number;
    message?: string;
    data?: TestChecklistResponse;
};

