/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type DiffSummary = {
    addedFiles?: number;
    modifiedFiles?: number;
    deletedFiles?: number;
    newApis?: number;
    modifiedApis?: number;
    affectedApis?: number;
    deletedApis?: number;
    highRiskApis?: number;
    mediumRiskApis?: number;
    lowRiskApis?: number;
};

