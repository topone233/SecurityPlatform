/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DiffAnalysisProgressResponse } from './DiffAnalysisProgressResponse';
export type ResultDiffAnalysisProgressResponse = {
    code?: number;
    message?: string;
    data?: DiffAnalysisProgressResponse;
};

