/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { TestExecutionResponse } from './TestExecutionResponse';
export type ResultTestExecutionResponse = {
    code?: number;
    message?: string;
    data?: TestExecutionResponse;
};

