/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { StepInfo } from './StepInfo';
export type DiffAnalysisProgressResponse = {
    diffTaskId?: number;
    status?: string;
    progress?: number;
    currentStep?: string;
    steps?: Array<StepInfo>;
};

