/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { TestCaseResponse } from './TestCaseResponse';
export type ResultListTestCaseResponse = {
    code?: number;
    message?: string;
    data?: Array<TestCaseResponse>;
};

