/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type DangerSummary = {
    functionName?: string;
    functionType?: string;
    className?: string;
    lineNumber?: number;
    riskLevel?: string;
};

