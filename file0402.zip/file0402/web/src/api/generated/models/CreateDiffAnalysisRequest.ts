/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateDiffAnalysisRequest = {
    projectId: number;
    baselineArtifactId: number;
    targetArtifactId: number;
    createdBy?: string;
};

