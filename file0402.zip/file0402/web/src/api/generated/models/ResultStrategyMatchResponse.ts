/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { StrategyMatchResponse } from './StrategyMatchResponse';
export type ResultStrategyMatchResponse = {
    code?: number;
    message?: string;
    data?: StrategyMatchResponse;
};

