/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { TestExecutionResponse } from './TestExecutionResponse';
export type ResultListTestExecutionResponse = {
    code?: number;
    message?: string;
    data?: Array<TestExecutionResponse>;
};

