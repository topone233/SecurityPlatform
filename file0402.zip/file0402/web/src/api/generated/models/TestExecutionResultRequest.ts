/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type TestExecutionResultRequest = {
    testResult?: string;
    severity?: string;
    reproducible?: boolean;
    actualResult?: string;
    logOutput?: string;
    errorMessage?: string;
    evidenceFiles?: string;
    notes?: string;
};

