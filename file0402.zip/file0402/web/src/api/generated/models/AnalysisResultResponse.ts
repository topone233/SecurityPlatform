/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ApiSummary } from './ApiSummary';
import type { ComponentSummary } from './ComponentSummary';
import type { ConfigSummary } from './ConfigSummary';
import type { DangerSummary } from './DangerSummary';
import type { UrlSummary } from './UrlSummary';
export type AnalysisResultResponse = {
    artifactId?: number;
    status?: string;
    apis?: Array<ApiSummary>;
    components?: Array<ComponentSummary>;
    dangers?: Array<DangerSummary>;
    configs?: Array<ConfigSummary>;
    urls?: Array<UrlSummary>;
};

