/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ArtifactSummary = {
    artifactId?: number;
    artifactName?: string;
    fileSize?: number;
    uploadTime?: string;
};

