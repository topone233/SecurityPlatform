/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RiskExclusionResponse } from './RiskExclusionResponse';
export type ResultRiskExclusionResponse = {
    code?: number;
    message?: string;
    data?: RiskExclusionResponse;
};

