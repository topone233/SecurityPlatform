/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type TestCaseRequest = {
    caseName?: string;
    vulnerabilityType?: string;
    riskLevel?: string;
    applicableComponents?: string;
    applicableDangerFunctions?: string;
    detectionMethod?: string;
    testSteps?: string;
    payloadTemplate?: string;
    expectedResult?: string;
    references?: string;
};

