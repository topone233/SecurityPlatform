/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type StepInfo = {
    name?: string;
    status?: string;
    progress?: number;
    message?: string;
};

