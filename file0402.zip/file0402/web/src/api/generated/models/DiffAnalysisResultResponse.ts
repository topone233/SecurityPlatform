/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ApiDiffSummary } from './ApiDiffSummary';
import type { ArtifactSummary } from './ArtifactSummary';
import type { DiffSummary } from './DiffSummary';
import type { FileDiffSummary } from './FileDiffSummary';
export type DiffAnalysisResultResponse = {
    diffTaskId?: number;
    projectId?: number;
    status?: string;
    errorMessage?: string;
    baseline?: ArtifactSummary;
    target?: ArtifactSummary;
    summary?: DiffSummary;
    fileDiffs?: Array<FileDiffSummary>;
    apiDiffs?: Array<ApiDiffSummary>;
};

