/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { TestReportResponse } from './TestReportResponse';
export type ResultTestReportResponse = {
    code?: number;
    message?: string;
    data?: TestReportResponse;
};

