/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type TestExecutionRequest = {
    artifactId?: number;
    checklistId?: number;
    testCaseId?: number;
    executionName?: string;
    vulnerabilityType?: string;
    executionType?: string;
    executor?: string;
    environmentInfo?: string;
    testData?: string;
    expectedResult?: string;
    notes?: string;
};

