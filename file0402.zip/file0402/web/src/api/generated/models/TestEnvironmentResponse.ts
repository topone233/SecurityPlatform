/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type TestEnvironmentResponse = {
    id?: number;
    envName?: string;
    envType?: string;
    description?: string;
    configData?: Record<string, Record<string, any>>;
    isActive?: boolean;
    createdAt?: string;
    updatedAt?: string;
};

