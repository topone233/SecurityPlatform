/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ArtifactResponse = {
    id?: number;
    taskId?: number;
    artifactName?: string;
    artifactType?: string;
    filePath?: string;
    fileSize?: number;
    md5?: string;
    uploadTime?: string;
    status?: string;
};

