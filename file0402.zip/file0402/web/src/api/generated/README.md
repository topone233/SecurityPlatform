# API 自动生成说明

本项目使用 `openapi-typescript-codegen` 从后端 Swagger 自动生成前端 API 代码，确保前后端类型同步。

## 前置条件

1. 后端服务已启动（默认端口 8001）
2. 后端 Swagger 可访问：`http://localhost:8001/v3/api-docs`

## 快速开始

### 1. 安装依赖

```bash
cd security-platform-frontend
npm install
```

### 2. 启动后端服务

确保后端运行在 `http://localhost:8001`

### 3. 生成 API 代码

```bash
# 生成完整的 API 客户端（包含请求方法 + 类型）
npm run generate:api

# 仅生成 TypeScript 类型定义
npm run generate:types
```

## 生成的文件结构

```
src/api/
├── generated/           # 自动生成，请勿手动修改
│   ├── index.ts        # API 客户端入口
│   ├── types.ts        # TypeScript 类型定义
│   ├── services/       # 各模块 API 服务
│   │   ├── ProjectService.ts
│   │   ├── TaskService.ts
│   │   └── ...
│   └── models/         # 数据模型
│       ├── ProjectResponse.ts
│       ├── CreateProjectRequest.ts
│       └── ...
├── index.js            # Axios 实例配置
└── project.js          # 旧的手写 API（待替换）
```

## 使用示例

### 旧的写法（手动维护）

```javascript
// src/api/project.js
export default {
  getList(params) {
    return api.get('/projects', { params })
  }
}

// 在组件中使用
import projectApi from '@/api/project'
const data = await projectApi.getList({ name: 'xxx' })
// data 没有类型提示
```

### 新的写法（自动生成）

```typescript
// 在组件中使用
import { ProjectService } from '@/api/generated'

// 完整的类型提示和自动补全
const projects: ProjectResponse[] = await ProjectService.getAllProjects()

// 创建项目
const newProject = await ProjectService.createProject({
  projectName: '新项目',
  description: '项目描述'
})

// 类型安全：编译时发现错误
await ProjectService.createProject({
  name: 'xxx'  // ❌ 错误：应该是 projectName
})
```

## API 响应处理

生成的代码自动处理响应，直接返回数据：

```typescript
// 自动生成的 Service 内部处理了 axios 响应
const project = await ProjectService.getProjectById(1)
// project 类型为 ProjectResponse，已自动提取 response.data
```

## 配置说明

### 修改后端地址

编辑 `src/api/generated/index.ts`（每次生成会覆盖）：

```typescript
// 在 OpenAPI 配置中修改 baseURL
const instance = axios.create({
  baseURL: '/api'  // 使用代理，或改为 http://localhost:8001/api
})
```

### 自定义请求拦截器

创建自定义封装：

```typescript
// src/api/client.ts
import { OpenAPI } from '@/api/generated'

OpenAPI.BASE = '/api'
OpenAPI.interceptors.request.use(config => {
  // 添加 token 等
  return config
})
```

## 开发流程

1. **后端新增/修改 API** → 更新 Controller
2. **重新生成前端代码** → `npm run generate:api`
3. **使用新 API** → 更新组件代码

## 注意事项

- ⚠️ `src/api/generated/` 目录会被覆盖，不要手动修改
- ✅ 自定义逻辑放在 `src/api/` 下的其他文件
- ✅ 后端 DTO 字段变更后，重新生成即可同步

## VS Code 集成

安装插件获得更好的体验：
- **OpenAPI (Swagger) Editor** - 编辑 OpenAPI 文档
- **Swagger Viewer** - 预览 Swagger 文档
