/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AnalysisProgressResponse } from '../models/AnalysisProgressResponse';
import type { AnalysisResultResponse } from '../models/AnalysisResultResponse';
import type { ArtifactResponse } from '../models/ArtifactResponse';
import type { CreateDiffAnalysisRequest } from '../models/CreateDiffAnalysisRequest';
import type { CreateProjectRequest } from '../models/CreateProjectRequest';
import type { CreateTaskRequest } from '../models/CreateTaskRequest';
import type { ProjectResponse } from '../models/ProjectResponse';
import type { ResultBaselineRecommendationResponse } from '../models/ResultBaselineRecommendationResponse';
import type { ResultConfigCheckItemResponse } from '../models/ResultConfigCheckItemResponse';
import type { ResultDiffAnalysisProgressResponse } from '../models/ResultDiffAnalysisProgressResponse';
import type { ResultDiffAnalysisResultResponse } from '../models/ResultDiffAnalysisResultResponse';
import type { ResultListConfigCheckItemResponse } from '../models/ResultListConfigCheckItemResponse';
import type { ResultListMapStringObject } from '../models/ResultListMapStringObject';
import type { ResultListRiskExclusionResponse } from '../models/ResultListRiskExclusionResponse';
import type { ResultListString } from '../models/ResultListString';
import type { ResultListTestCaseResponse } from '../models/ResultListTestCaseResponse';
import type { ResultListTestEnvironmentResponse } from '../models/ResultListTestEnvironmentResponse';
import type { ResultListTestExecutionResponse } from '../models/ResultListTestExecutionResponse';
import type { ResultListTestReportResponse } from '../models/ResultListTestReportResponse';
import type { ResultLong } from '../models/ResultLong';
import type { ResultMapStringObject } from '../models/ResultMapStringObject';
import type { ResultRiskExclusionResponse } from '../models/ResultRiskExclusionResponse';
import type { ResultStrategyMatchResponse } from '../models/ResultStrategyMatchResponse';
import type { ResultTestCaseResponse } from '../models/ResultTestCaseResponse';
import type { ResultTestChecklistResponse } from '../models/ResultTestChecklistResponse';
import type { ResultTestEnvironmentResponse } from '../models/ResultTestEnvironmentResponse';
import type { ResultTestExecutionResponse } from '../models/ResultTestExecutionResponse';
import type { ResultTestReportResponse } from '../models/ResultTestReportResponse';
import type { ResultVoid } from '../models/ResultVoid';
import type { TaskResponse } from '../models/TaskResponse';
import type { TestCaseRequest } from '../models/TestCaseRequest';
import type { TestExecutionRequest } from '../models/TestExecutionRequest';
import type { TestExecutionResultRequest } from '../models/TestExecutionResultRequest';
import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';
export class Service {
    /**
     * 开始执行测试
     * 将测试执行状态更新为RUNNING
     * @param id 执行记录ID
     * @returns ResultTestExecutionResponse OK
     * @throws ApiError
     */
    public static startExecution(
        id: number,
    ): CancelablePromise<ResultTestExecutionResponse> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/test-execution/{id}/start',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 完成测试执行
     * 记录测试结果并完成执行
     * @param id 执行记录ID
     * @param requestBody
     * @returns ResultTestExecutionResponse OK
     * @throws ApiError
     */
    public static completeExecution(
        id: number,
        requestBody: TestExecutionResultRequest,
    ): CancelablePromise<ResultTestExecutionResponse> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/test-execution/{id}/complete',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 取消测试执行
     * 取消正在进行的测试执行
     * @param id 执行记录ID
     * @param reason 取消原因
     * @returns ResultTestExecutionResponse OK
     * @throws ApiError
     */
    public static cancelExecution(
        id: number,
        reason?: string,
    ): CancelablePromise<ResultTestExecutionResponse> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/test-execution/{id}/cancel',
            path: {
                'id': id,
            },
            query: {
                'reason': reason,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取环境详情
     * 根据ID获取测试环境详情
     * @param id 环境ID
     * @returns ResultTestEnvironmentResponse OK
     * @throws ApiError
     */
    public static getEnvironment(
        id: number,
    ): CancelablePromise<ResultTestEnvironmentResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/test-environment/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 更新测试环境
     * 更新测试环境配置
     * @param id 环境ID
     * @param envName 环境名称
     * @param envType 环境类型
     * @param description 环境描述
     * @param requestBody
     * @returns ResultTestEnvironmentResponse OK
     * @throws ApiError
     */
    public static updateEnvironment(
        id: number,
        envName?: string,
        envType?: string,
        description?: string,
        requestBody?: Record<string, Record<string, any>>,
    ): CancelablePromise<ResultTestEnvironmentResponse> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/test-environment/{id}',
            path: {
                'id': id,
            },
            query: {
                'envName': envName,
                'envType': envType,
                'description': description,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 删除测试环境
     * 删除指定的测试环境
     * @param id 环境ID
     * @returns ResultVoid OK
     * @throws ApiError
     */
    public static deleteEnvironment(
        id: number,
    ): CancelablePromise<ResultVoid> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/test-environment/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 启用测试环境
     * 启用指定的测试环境
     * @param id 环境ID
     * @returns ResultTestEnvironmentResponse OK
     * @throws ApiError
     */
    public static enableEnvironment(
        id: number,
    ): CancelablePromise<ResultTestEnvironmentResponse> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/test-environment/{id}/enable',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 禁用测试环境
     * 禁用指定的测试环境
     * @param id 环境ID
     * @returns ResultTestEnvironmentResponse OK
     * @throws ApiError
     */
    public static disableEnvironment(
        id: number,
    ): CancelablePromise<ResultTestEnvironmentResponse> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/test-environment/{id}/disable',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 更新任务状态
     * 更新指定任务的状态
     * @param id 任务ID
     * @param status 新状态: PENDING, RUNNING, COMPLETED, FAILED
     * @returns TaskResponse OK
     * @throws ApiError
     */
    public static updateTaskStatus(
        id: number,
        status: string,
    ): CancelablePromise<TaskResponse> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/tasks/{id}/status',
            path: {
                'id': id,
            },
            query: {
                'status': status,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取测试用例详情
     * 根据ID获取测试用例详情
     * @param id 用例ID
     * @returns ResultTestCaseResponse OK
     * @throws ApiError
     */
    public static getTestCase(
        id: number,
    ): CancelablePromise<ResultTestCaseResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/strategy/test-cases/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 更新测试用例
     * 更新指定的测试用例
     * @param id 用例ID
     * @param requestBody
     * @returns ResultTestCaseResponse OK
     * @throws ApiError
     */
    public static updateTestCase(
        id: number,
        requestBody: TestCaseRequest,
    ): CancelablePromise<ResultTestCaseResponse> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/strategy/test-cases/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 删除测试用例
     * 删除指定的测试用例
     * @param id 用例ID
     * @returns ResultVoid OK
     * @throws ApiError
     */
    public static deleteTestCase(
        id: number,
    ): CancelablePromise<ResultVoid> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/strategy/test-cases/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 更新测试清单状态
     * 更新测试清单项的测试状态和结果
     * @param checklistId 清单项ID
     * @param status 状态: TODO, PASS, FAIL, NA
     * @param testResult 测试结果
     * @param testNotes 测试备注
     * @returns ResultTestChecklistResponse OK
     * @throws ApiError
     */
    public static updateChecklistStatus(
        checklistId: number,
        status: string,
        testResult?: string,
        testNotes?: string,
    ): CancelablePromise<ResultTestChecklistResponse> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/strategy/checklist/{checklistId}/status',
            path: {
                'checklistId': checklistId,
            },
            query: {
                'status': status,
                'testResult': testResult,
                'testNotes': testNotes,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 审核风险排除
     * 人工审核风险排除项，确认或拒绝
     * @param exclusionId 排除项ID
     * @param status 审核状态: APPROVED, REJECTED
     * @param reviewer 审核人
     * @param notes 审核备注
     * @returns ResultRiskExclusionResponse OK
     * @throws ApiError
     */
    public static reviewExclusion(
        exclusionId: number,
        status: string,
        reviewer?: string,
        notes?: string,
    ): CancelablePromise<ResultRiskExclusionResponse> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/risk-exclusion/review/{exclusionId}',
            path: {
                'exclusionId': exclusionId,
            },
            query: {
                'status': status,
                'reviewer': reviewer,
                'notes': notes,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 更新制品状态
     * 更新指定制品的状态
     * @param id 制品ID
     * @param status 新状态: PENDING, ANALYZING, COMPLETED, FAILED
     * @returns ArtifactResponse OK
     * @throws ApiError
     */
    public static updateArtifactStatus(
        id: number,
        status: string,
    ): CancelablePromise<ArtifactResponse> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/artifacts/{id}/status',
            path: {
                'id': id,
            },
            query: {
                'status': status,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 生成测试报告
     * 根据测试执行结果生成测试报告
     * @param artifactId 制品ID
     * @param reportType 报告类型: FULL, SUMMARY, RISK
     * @param generatedBy 生成人
     * @returns ResultTestReportResponse OK
     * @throws ApiError
     */
    public static generateReport(
        artifactId: number,
        reportType?: string,
        generatedBy?: string,
    ): CancelablePromise<ResultTestReportResponse> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/test-report/generate/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            query: {
                'reportType': reportType,
                'generatedBy': generatedBy,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 创建测试执行记录
     * 为测试清单项创建测试执行记录
     * @param requestBody
     * @returns ResultTestExecutionResponse OK
     * @throws ApiError
     */
    public static createExecution(
        requestBody: TestExecutionRequest,
    ): CancelablePromise<ResultTestExecutionResponse> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/test-execution',
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 批量创建执行记录
     * 为制品下所有TODO状态的测试清单创建执行记录
     * @param artifactId 制品ID
     * @returns ResultListTestExecutionResponse OK
     * @throws ApiError
     */
    public static batchCreateExecutions(
        artifactId: number,
    ): CancelablePromise<ResultListTestExecutionResponse> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/test-execution/batch/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取所有环境
     * 获取所有测试环境列表
     * @returns ResultListTestEnvironmentResponse OK
     * @throws ApiError
     */
    public static getAllEnvironments(): CancelablePromise<ResultListTestEnvironmentResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/test-environment',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 创建测试环境
     * 创建新的测试环境配置
     * @param envName 环境名称
     * @param envType 环境类型: DEV, TEST, STAGING, PROD
     * @param description 环境描述
     * @param requestBody
     * @returns ResultTestEnvironmentResponse OK
     * @throws ApiError
     */
    public static createEnvironment(
        envName: string,
        envType: string,
        description?: string,
        requestBody?: Record<string, Record<string, any>>,
    ): CancelablePromise<ResultTestEnvironmentResponse> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/test-environment',
            query: {
                'envName': envName,
                'envType': envType,
                'description': description,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 查询所有任务
     * 获取所有任务列表
     * @returns TaskResponse OK
     * @throws ApiError
     */
    public static getAllTasks(): CancelablePromise<Array<TaskResponse>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/tasks',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 创建任务
     * 在指定项目下创建新的测试任务
     * @param requestBody
     * @returns TaskResponse OK
     * @throws ApiError
     */
    public static createTask(
        requestBody: CreateTaskRequest,
    ): CancelablePromise<TaskResponse> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/tasks',
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取所有测试用例
     * 获取测试用例库中的所有用例
     * @returns ResultListTestCaseResponse OK
     * @throws ApiError
     */
    public static getAllTestCases(): CancelablePromise<ResultListTestCaseResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/strategy/test-cases',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 创建测试用例
     * 创建新的测试用例
     * @param requestBody
     * @returns ResultTestCaseResponse OK
     * @throws ApiError
     */
    public static createTestCase(
        requestBody: TestCaseRequest,
    ): CancelablePromise<ResultTestCaseResponse> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/strategy/test-cases',
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 生成测试清单
     * 根据分析结果自动生成测试清单
     * @param artifactId 制品ID
     * @returns ResultStrategyMatchResponse OK
     * @throws ApiError
     */
    public static generateTestChecklist(
        artifactId: number,
    ): CancelablePromise<ResultStrategyMatchResponse> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/strategy/generate/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 执行风险排除分析
     * 对制品执行风险自动排除分析
     * @param artifactId 制品ID
     * @returns ResultVoid OK
     * @throws ApiError
     */
    public static performRiskExclusion(
        artifactId: number,
    ): CancelablePromise<ResultVoid> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/risk-exclusion/analyze/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 查询所有项目
     * 获取所有项目列表
     * @returns ProjectResponse OK
     * @throws ApiError
     */
    public static getAllProjects(): CancelablePromise<Array<ProjectResponse>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/projects',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 创建项目
     * 创建一个新的安全测试项目
     * @param requestBody
     * @returns ProjectResponse OK
     * @throws ApiError
     */
    public static createProject(
        requestBody: CreateProjectRequest,
    ): CancelablePromise<ProjectResponse> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/projects',
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 创建差异分析任务
     * 创建基线与目标版本的差异分析任务
     * @param requestBody
     * @returns ResultLong OK
     * @throws ApiError
     */
    public static createDiffAnalysis(
        requestBody: CreateDiffAnalysisRequest,
    ): CancelablePromise<ResultLong> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/diff-analysis/create',
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 上传制品
     * 上传 JAR/WAR 包作为测试制品
     * @param taskId 任务ID
     * @param artifactType 制品类型: JAR, WAR, ZIP
     * @returns ArtifactResponse OK
     * @throws ApiError
     */
    public static uploadArtifact(
        taskId: number,
        artifactType: string,
    ): CancelablePromise<ArtifactResponse> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/artifacts/upload',
            query: {
                'taskId': taskId,
                'artifactType': artifactType,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 异步触发分析
     * 异步触发制品分析，分析完成后可通过结果接口查询
     * @param artifactId 制品ID
     * @returns string OK
     * @throws ApiError
     */
    public static triggerAnalysis(
        artifactId: number,
    ): CancelablePromise<string> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/analysis/trigger/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 同步触发分析
     * 同步触发制品分析，等待分析完成后返回结果
     * @param artifactId 制品ID
     * @returns AnalysisResultResponse OK
     * @throws ApiError
     */
    public static triggerAnalysisSync(
        artifactId: number,
    ): CancelablePromise<AnalysisResultResponse> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/analysis/trigger-sync/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 手动清理过期缓存
     * 手动触发清理过期的分析缓存
     * @returns number OK
     * @throws ApiError
     */
    public static cleanupCache(): CancelablePromise<Record<string, number>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/analysis/cache/cleanup',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取报告
     * 根据ID获取测试报告详情
     * @param id 报告ID
     * @returns ResultTestReportResponse OK
     * @throws ApiError
     */
    public static getReport(
        id: number,
    ): CancelablePromise<ResultTestReportResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/test-report/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 删除报告
     * 删除指定的测试报告
     * @param id 报告ID
     * @returns ResultVoid OK
     * @throws ApiError
     */
    public static deleteReport(
        id: number,
    ): CancelablePromise<ResultVoid> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/test-report/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取最新报告
     * 获取制品最新的完成报告
     * @param artifactId 制品ID
     * @returns ResultTestReportResponse OK
     * @throws ApiError
     */
    public static getLatestReport(
        artifactId: number,
    ): CancelablePromise<ResultTestReportResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/test-report/latest/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取报告列表
     * 获取制品的所有测试报告
     * @param artifactId 制品ID
     * @returns ResultListTestReportResponse OK
     * @throws ApiError
     */
    public static getReportsByArtifact(
        artifactId: number,
    ): CancelablePromise<ResultListTestReportResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/test-report/artifact/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取执行记录
     * 根据ID获取测试执行记录详情
     * @param id 执行记录ID
     * @returns ResultTestExecutionResponse OK
     * @throws ApiError
     */
    public static getExecution(
        id: number,
    ): CancelablePromise<ResultTestExecutionResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/test-execution/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取执行统计
     * 获取测试执行的统计数据
     * @param artifactId 制品ID
     * @returns ResultMapStringObject OK
     * @throws ApiError
     */
    public static getExecutionStatistics(
        artifactId: number,
    ): CancelablePromise<ResultMapStringObject> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/test-execution/statistics/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取清单执行记录
     * 获取测试清单项的所有执行记录
     * @param checklistId 清单项ID
     * @returns ResultListTestExecutionResponse OK
     * @throws ApiError
     */
    public static getExecutionsByChecklist(
        checklistId: number,
    ): CancelablePromise<ResultListTestExecutionResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/test-execution/checklist/{checklistId}',
            path: {
                'checklistId': checklistId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取制品执行记录
     * 获取制品下的所有测试执行记录
     * @param artifactId 制品ID
     * @returns ResultListTestExecutionResponse OK
     * @throws ApiError
     */
    public static getExecutionsByArtifact(
        artifactId: number,
    ): CancelablePromise<ResultListTestExecutionResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/test-execution/artifact/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 按类型获取环境
     * 获取指定类型的所有测试环境
     * @param envType 环境类型: DEV, TEST, STAGING, PROD
     * @returns ResultListTestEnvironmentResponse OK
     * @throws ApiError
     */
    public static getEnvironmentsByType(
        envType: string,
    ): CancelablePromise<ResultListTestEnvironmentResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/test-environment/type/{envType}',
            path: {
                'envType': envType,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取活跃环境
     * 获取所有启用的测试环境
     * @returns ResultListTestEnvironmentResponse OK
     * @throws ApiError
     */
    public static getActiveEnvironments(): CancelablePromise<ResultListTestEnvironmentResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/test-environment/active',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 根据ID查询任务
     * 根据任务ID获取任务详情
     * @param id 任务ID
     * @returns TaskResponse OK
     * @throws ApiError
     */
    public static getTaskById(
        id: number,
    ): CancelablePromise<TaskResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/tasks/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 删除任务
     * 根据ID删除任务
     * @param id 任务ID
     * @returns any OK
     * @throws ApiError
     */
    public static deleteTask(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/tasks/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 根据状态查询任务
     * 获取指定状态的所有任务
     * @param status 任务状态: PENDING, RUNNING, COMPLETED, FAILED
     * @returns TaskResponse OK
     * @throws ApiError
     */
    public static getTasksByStatus(
        status: string,
    ): CancelablePromise<Array<TaskResponse>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/tasks/status/{status}',
            path: {
                'status': status,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 根据项目ID查询任务
     * 获取指定项目下的所有任务
     * @param projectId 项目ID
     * @returns TaskResponse OK
     * @throws ApiError
     */
    public static getTasksByProjectId(
        projectId: number,
    ): CancelablePromise<Array<TaskResponse>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/tasks/project/{projectId}',
            path: {
                'projectId': projectId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取所有漏洞类型
     * 获取测试用例库中所有的漏洞类型列表
     * @returns ResultListString OK
     * @throws ApiError
     */
    public static getAllVulnerabilityTypes(): CancelablePromise<ResultListString> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/strategy/vulnerability-types',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 按漏洞类型获取用例
     * 获取指定漏洞类型的所有测试用例
     * @param vulnerabilityType 漏洞类型
     * @returns ResultListTestCaseResponse OK
     * @throws ApiError
     */
    public static getTestCasesByType(
        vulnerabilityType: string,
    ): CancelablePromise<ResultListTestCaseResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/strategy/test-cases/by-type/{vulnerabilityType}',
            path: {
                'vulnerabilityType': vulnerabilityType,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取所有配置检查项
     * 获取配置检查清单中的所有检查项
     * @returns ResultListConfigCheckItemResponse OK
     * @throws ApiError
     */
    public static getAllConfigCheckItems(): CancelablePromise<ResultListConfigCheckItemResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/strategy/config-items',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取配置检查项详情
     * 根据ID获取配置检查项详情
     * @param id 检查项ID
     * @returns ResultConfigCheckItemResponse OK
     * @throws ApiError
     */
    public static getConfigCheckItem(
        id: number,
    ): CancelablePromise<ResultConfigCheckItemResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/strategy/config-items/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 按类别获取检查项
     * 获取指定类别的所有配置检查项
     * @param category 检查项类别
     * @returns ResultListConfigCheckItemResponse OK
     * @throws ApiError
     */
    public static getConfigCheckItemsByCategory(
        category: string,
    ): CancelablePromise<ResultListConfigCheckItemResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/strategy/config-items/by-category/{category}',
            path: {
                'category': category,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 执行配置检查
     * 对制品执行配置安全检查
     * @param artifactId 制品ID
     * @returns ResultListMapStringObject OK
     * @throws ApiError
     */
    public static performConfigCheck(
        artifactId: number,
    ): CancelablePromise<ResultListMapStringObject> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/strategy/config-check/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取所有配置检查类别
     * 获取配置检查清单中所有的类别列表
     * @returns ResultListString OK
     * @throws ApiError
     */
    public static getAllConfigCategories(): CancelablePromise<ResultListString> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/strategy/config-categories',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取测试清单
     * 获取制品的测试清单内容
     * @param artifactId 制品ID
     * @returns ResultStrategyMatchResponse OK
     * @throws ApiError
     */
    public static getTestChecklist(
        artifactId: number,
    ): CancelablePromise<ResultStrategyMatchResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/strategy/checklist/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取统计信息
     * 获取风险排除的统计数据
     * @param artifactId 制品ID
     * @returns ResultMapStringObject OK
     * @throws ApiError
     */
    public static getExclusionStatistics(
        artifactId: number,
    ): CancelablePromise<ResultMapStringObject> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/risk-exclusion/statistics/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取待审核项
     * 获取需要人工审核的风险排除项
     * @param artifactId 制品ID
     * @returns ResultListRiskExclusionResponse OK
     * @throws ApiError
     */
    public static getPendingReviewExclusions(
        artifactId: number,
    ): CancelablePromise<ResultListRiskExclusionResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/risk-exclusion/pending-review/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取风险排除列表
     * 获取制品的所有风险排除记录
     * @param artifactId 制品ID
     * @returns ResultListRiskExclusionResponse OK
     * @throws ApiError
     */
    public static getExclusions(
        artifactId: number,
    ): CancelablePromise<ResultListRiskExclusionResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/risk-exclusion/list/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 根据ID查询项目
     * 根据项目ID获取项目详情
     * @param id 项目ID
     * @returns ProjectResponse OK
     * @throws ApiError
     */
    public static getProjectById(
        id: number,
    ): CancelablePromise<ProjectResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/projects/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 删除项目
     * 根据ID删除项目
     * @param id 项目ID
     * @returns any OK
     * @throws ApiError
     */
    public static deleteProject(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/projects/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 根据名称查询项目
     * 根据项目名称获取项目详情
     * @param projectName 项目名称
     * @returns ProjectResponse OK
     * @throws ApiError
     */
    public static getProjectByName(
        projectName: string,
    ): CancelablePromise<ProjectResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/projects/name/{projectName}',
            path: {
                'projectName': projectName,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取分析结果
     * 获取差异分析的完整结果
     * @param taskId 任务ID
     * @returns ResultDiffAnalysisResultResponse OK
     * @throws ApiError
     */
    public static getDiffResult(
        taskId: number,
    ): CancelablePromise<ResultDiffAnalysisResultResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/diff-analysis/{taskId}',
            path: {
                'taskId': taskId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 按风险等级筛选API
     * 根据风险等级筛选API差异
     * @param taskId 任务ID
     * @param riskLevel 风险等级: HIGH, MEDIUM, LOW
     * @returns ResultDiffAnalysisResultResponse OK
     * @throws ApiError
     */
    public static getApisByRiskLevel(
        taskId: number,
        riskLevel?: string,
    ): CancelablePromise<ResultDiffAnalysisResultResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/diff-analysis/{taskId}/risks',
            path: {
                'taskId': taskId,
            },
            query: {
                'riskLevel': riskLevel,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取分析进度
     * 获取差异分析任务的执行进度
     * @param taskId 任务ID
     * @returns ResultDiffAnalysisProgressResponse OK
     * @throws ApiError
     */
    public static getProgress(
        taskId: number,
    ): CancelablePromise<ResultDiffAnalysisProgressResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/diff-analysis/{taskId}/progress',
            path: {
                'taskId': taskId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 导出分析报告
     * 导出差异分析报告为Excel文件
     * @param taskId 任务ID
     * @returns string OK
     * @throws ApiError
     */
    public static exportReport(
        taskId: number,
    ): CancelablePromise<string> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/diff-analysis/{taskId}/export',
            path: {
                'taskId': taskId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 按变更类型筛选API
     * 根据变更类型筛选API差异
     * @param taskId 任务ID
     * @param changeType 变更类型: NEW_API, MODIFIED_API, AFFECTED_API, DELETED_API
     * @returns ResultDiffAnalysisResultResponse OK
     * @throws ApiError
     */
    public static getApisByChangeType(
        taskId: number,
        changeType?: string,
    ): CancelablePromise<ResultDiffAnalysisResultResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/diff-analysis/{taskId}/apis',
            path: {
                'taskId': taskId,
            },
            query: {
                'changeType': changeType,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 获取基线推荐
     * 根据项目历史分析推荐最佳基线版本
     * @param projectId 项目ID
     * @returns ResultBaselineRecommendationResponse OK
     * @throws ApiError
     */
    public static getBaselineRecommendation(
        projectId: number,
    ): CancelablePromise<ResultBaselineRecommendationResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/diff-analysis/baseline/{projectId}',
            path: {
                'projectId': projectId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 查询所有制品
     * 获取所有制品列表
     * @returns ArtifactResponse OK
     * @throws ApiError
     */
    public static getAllArtifacts(): CancelablePromise<Array<ArtifactResponse>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/artifacts',
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 根据ID查询制品
     * 根据制品ID获取制品详情
     * @param id 制品ID
     * @returns ArtifactResponse OK
     * @throws ApiError
     */
    public static getArtifactById(
        id: number,
    ): CancelablePromise<ArtifactResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/artifacts/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 删除制品
     * 根据ID删除制品
     * @param id 制品ID
     * @returns any OK
     * @throws ApiError
     */
    public static deleteArtifact(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/artifacts/{id}',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 下载制品
     * 下载指定的制品文件
     * @param id 制品ID
     * @returns binary OK
     * @throws ApiError
     */
    public static downloadArtifact(
        id: number,
    ): CancelablePromise<Blob> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/artifacts/{id}/download',
            path: {
                'id': id,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 根据任务ID查询制品
     * 获取指定任务下的所有制品
     * @param taskId 任务ID
     * @returns ArtifactResponse OK
     * @throws ApiError
     */
    public static getArtifactsByTaskId(
        taskId: number,
    ): CancelablePromise<Array<ArtifactResponse>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/artifacts/task/{taskId}',
            path: {
                'taskId': taskId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 根据状态查询制品
     * 获取指定状态的所有制品
     * @param status 制品状态: PENDING, ANALYZING, COMPLETED, FAILED
     * @returns ArtifactResponse OK
     * @throws ApiError
     */
    public static getArtifactsByStatus(
        status: string,
    ): CancelablePromise<Array<ArtifactResponse>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/artifacts/status/{status}',
            path: {
                'status': status,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 查询分析结果
     * 获取制品的完整分析结果，包括API、组件、危险函数、配置、外部URL等
     * @param artifactId 制品ID
     * @returns AnalysisResultResponse OK
     * @throws ApiError
     */
    public static getAnalysisResult(
        artifactId: number,
    ): CancelablePromise<AnalysisResultResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/analysis/result/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 查询分析进度
     * 获取制品的实时分析进度信息
     * @param artifactId 制品ID
     * @returns AnalysisProgressResponse OK
     * @throws ApiError
     */
    public static getAnalysisProgress(
        artifactId: number,
    ): CancelablePromise<AnalysisProgressResponse> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/analysis/progress/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 查询缓存状态
     * 查询制品的分析缓存状态
     * @param artifactId 制品ID
     * @returns any OK
     * @throws ApiError
     */
    public static getCacheStatus(
        artifactId: number,
    ): CancelablePromise<Record<string, Record<string, any>>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/analysis/cache/{artifactId}',
            path: {
                'artifactId': artifactId,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
    /**
     * 清除分析缓存
     * 根据MD5清除指定的分析缓存
     * @param md5 制品MD5值
     * @returns any OK
     * @throws ApiError
     */
    public static clearCache(
        md5: string,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/analysis/cache/{md5}',
            path: {
                'md5': md5,
            },
            errors: {
                400: `Bad Request`,
                413: `Payload Too Large`,
                500: `Internal Server Error`,
            },
        });
    }
}
