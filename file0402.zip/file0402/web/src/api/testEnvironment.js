import api from './index'

export default {
  // Get environment list
  getList() {
    return api.get('/test-environment')
  },

  // Get environment by ID
  getById(id) {
    return api.get(`/test-environment/${id}`)
  },

  // Create environment
  create(data) {
    return api.post('/test-environment', data)
  },

  // Update environment
  update(id, data) {
    return api.put(`/test-environment/${id}`, data)
  },

  // Delete environment
  delete(id) {
    return api.delete(`/test-environment/${id}`)
  },

  // Test connection
  testConnection(id) {
    return api.post(`/test-environment/${id}/test`)
  }
}
