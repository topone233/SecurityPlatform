import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useLayoutStore = defineStore('layout', () => {
  const isCollapsed = ref(localStorage.getItem('sidebarCollapsed') === 'true')

  const toggleSidebar = () => {
    isCollapsed.value = !isCollapsed.value
    localStorage.setItem('sidebarCollapsed', isCollapsed.value)
  }

  return { isCollapsed, toggleSidebar }
})