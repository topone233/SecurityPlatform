import request from './index'

/**
 * 差异分析相关API
 */
export default {
  /**
   * 快速差异对比 - 直接上传两个JAR包对比
   */
  quickDiff(baselineFile, targetFile) {
    const formData = new FormData()
    formData.append('baseline', baselineFile)
    formData.append('target', targetFile)
    return request.post('/quick-diff/analyze', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      timeout: 300000 // 5分钟超时
    })
  },

  /**
   * 获取基线推荐
   */
  getBaselineRecommendation(projectId) {
    return request.get(`/diff-analysis/baseline/${projectId}`)
  },

  /**
   * 创建差异分析任务
   */
  createDiffAnalysis(data) {
    return request.post('/diff-analysis/create', data)
  },

  /**
   * 获取差异分析进度
   */
  getProgress(taskId) {
    return request.get(`/diff-analysis/${taskId}/progress`)
  },

  /**
   * 获取差异分析结果
   */
  getDiffResult(taskId) {
    return request.get(`/diff-analysis/${taskId}`)
  },

  /**
   * 按变更类型筛选API
   */
  getApisByChangeType(taskId, changeType) {
    return request.get(`/diff-analysis/${taskId}/apis`, { params: { changeType } })
  },

  /**
   * 按风险等级筛选API
   */
  getApisByRiskLevel(taskId, riskLevel) {
    return request.get(`/diff-analysis/${taskId}/risks`, { params: { riskLevel } })
  },

  /**
   * 导出差异分析报告
   */
  exportReport(taskId) {
    return request.get(`/diff-analysis/${taskId}/export`, { responseType: 'blob' })
  },

  /**
   * 快速差异对比并保存
   */
  quickDiffSave(baselineFile, targetFile, description) {
    const formData = new FormData()
    formData.append('baseline', baselineFile)
    formData.append('target', targetFile)
    if (description) {
      formData.append('description', description)
    }
    return request.post('/quick-diff/save', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      timeout: 300000 // 5分钟超时
    })
  },

  /**
   * 获取快速对比历史列表
   */
  getQuickDiffList() {
    return request.get('/quick-diff/list')
  },

  /**
   * 获取快速对比详情
   */
  getQuickDiffDetail(id) {
    return request.get(`/quick-diff/${id}`)
  },

  /**
   * 删除快速对比记录
   */
  deleteQuickDiff(id) {
    return request.delete(`/quick-diff/${id}`)
  }
}
