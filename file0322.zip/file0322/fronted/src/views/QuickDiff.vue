<template>
  <div class="quick-diff">
    <!-- 上传区域 -->
    <el-card shadow="never" v-if="!result">
      <template #header>
        <div class="card-header">
          <span>快速差异对比</span>
          <el-tag type="info">无需创建项目，直接上传对比</el-tag>
        </div>
      </template>

      <el-alert
        title="使用说明"
        type="info"
        description="直接上传两个 JAR/WAR 文件进行差异对比分析，无需预先创建项目或制品记录。分析完成后可直接查看结果。"
        :closable="false"
        show-icon
        style="margin-bottom: 20px;"
      />

      <el-form label-width="120px">
        <el-form-item label="基线文件">
          <el-upload
            :auto-upload="false"
            :on-change="onBaselineChange"
            :show-file-list="false"
            accept=".jar,.war"
            drag
          >
            <el-icon class="el-icon--upload"><upload-filled /></el-icon>
            <div class="el-upload__text">
              拖拽文件到此处，或 <em>点击选择</em>
            </div>
            <template #tip>
              <div class="el-upload__tip">上传基线版本 JAR/WAR 文件</div>
            </template>
          </el-upload>
          <div v-if="baselineFile" class="file-info">
            <el-icon><Document /></el-icon>
            <span>{{ baselineFile.name }}</span>
            <span class="file-size">({{ formatSize(baselineFile.size) }})</span>
          </div>
        </el-form-item>

        <el-form-item label="目标文件">
          <el-upload
            :auto-upload="false"
            :on-change="onTargetChange"
            :show-file-list="false"
            accept=".jar,.war"
            drag
          >
            <el-icon class="el-icon--upload"><upload-filled /></el-icon>
            <div class="el-upload__text">
              拖拽文件到此处，或 <em>点击选择</em>
            </div>
            <template #tip>
              <div class="el-upload__tip">上传目标版本 JAR/WAR 文件</div>
            </template>
          </el-upload>
          <div v-if="targetFile" class="file-info">
            <el-icon><Document /></el-icon>
            <span>{{ targetFile.name }}</span>
            <span class="file-size">({{ formatSize(targetFile.size) }})</span>
          </div>
        </el-form-item>
      </el-form>

      <div class="actions">
        <el-button
          type="primary"
          size="large"
          @click="startAnalysis"
          :loading="analyzing"
          :disabled="!baselineFile || !targetFile"
        >
          {{ analyzing ? '分析中...' : '开始对比分析' }}
        </el-button>
      </div>
    </el-card>

    <!-- 分析进度 -->
    <el-card shadow="never" v-if="analyzing">
      <template #header>
        <span>正在分析</span>
      </template>
      <div class="progress-container">
        <el-progress
          :percentage="progress"
          :stroke-width="20"
          :indeterminate="true"
        />
        <p class="progress-text">{{ progressText }}</p>
      </div>
    </el-card>

    <!-- 分析结果 -->
    <el-card shadow="never" v-if="result && !analyzing">
      <template #header>
        <div class="card-header">
          <span>对比结果</span>
          <div>
            <el-tag v-if="result.duration" type="info">
              耗时: {{ (result.duration / 1000).toFixed(2) }}s
            </el-tag>
            <el-button
              v-if="!saved"
              type="success"
              @click="showSaveDialog"
              style="margin-left: 10px;"
            >
              保存结果
            </el-button>
            <el-tag v-else type="success" style="margin-left: 10px;">
              已保存
            </el-tag>
            <el-button type="primary" @click="resetAnalysis" style="margin-left: 10px;">
              重新对比
            </el-button>
          </div>
        </div>
      </template>

      <!-- 文件差异统计 -->
      <div class="summary-section">
        <h3>文件变更统计</h3>
        <el-row :gutter="20">
          <el-col :span="6">
            <el-statistic title="新增文件" :value="result.fileSummary?.addedFiles || 0">
              <template #suffix>
                <el-icon color="#67C23A"><DocumentAdd /></el-icon>
              </template>
            </el-statistic>
          </el-col>
          <el-col :span="6">
            <el-statistic title="修改文件" :value="result.fileSummary?.modifiedFiles || 0">
              <template #suffix>
                <el-icon color="#E6A23C"><Edit /></el-icon>
              </template>
            </el-statistic>
          </el-col>
          <el-col :span="6">
            <el-statistic title="删除文件" :value="result.fileSummary?.deletedFiles || 0">
              <template #suffix>
                <el-icon color="#F56C6C"><Delete /></el-icon>
              </template>
            </el-statistic>
          </el-col>
          <el-col :span="6">
            <el-statistic title="方法变更" :value="totalMethodChanges">
              <template #suffix>
                <el-icon color="#409EFF"><Operation /></el-icon>
              </template>
            </el-statistic>
          </el-col>
        </el-row>
      </div>

      <el-divider />

      <!-- API变更统计 -->
      <div class="summary-section">
        <h3>API变更统计</h3>
        <el-row :gutter="20">
          <el-col :span="4">
            <div class="stat-box high">
              <div class="label">高危</div>
              <div class="value">{{ result.apiSummary?.highRiskApis || 0 }}</div>
            </div>
          </el-col>
          <el-col :span="4">
            <div class="stat-box medium">
              <div class="label">中危</div>
              <div class="value">{{ result.apiSummary?.mediumRiskApis || 0 }}</div>
            </div>
          </el-col>
          <el-col :span="4">
            <div class="stat-box low">
              <div class="label">低危</div>
              <div class="value">{{ result.apiSummary?.lowRiskApis || 0 }}</div>
            </div>
          </el-col>
          <el-col :span="4">
            <div class="stat-box">
              <div class="label">新增API</div>
              <div class="value">{{ result.apiSummary?.newApis || 0 }}</div>
            </div>
          </el-col>
          <el-col :span="4">
            <div class="stat-box">
              <div class="label">修改API</div>
              <div class="value">{{ result.apiSummary?.modifiedApis || 0 }}</div>
            </div>
          </el-col>
          <el-col :span="4">
            <div class="stat-box">
              <div class="label">删除API</div>
              <div class="value">{{ result.apiSummary?.deletedApis || 0 }}</div>
            </div>
          </el-col>
        </el-row>
      </div>

      <el-divider />

      <!-- API变更详情 -->
      <div class="detail-section" v-if="result.apiDiffs?.length">
        <h3>API变更详情</h3>
        <el-tabs v-model="activeTab">
          <el-tab-pane label="全部" name="all" />
          <el-tab-pane label="新增" name="NEW_API" />
          <el-tab-pane label="修改" name="MODIFIED_API" />
          <el-tab-pane label="受影响" name="AFFECTED_API" />
          <el-tab-pane label="删除" name="DELETED_API" />
        </el-tabs>

        <el-table :data="filteredApiDiffs" style="width: 100%">
          <el-table-column prop="httpMethod" label="方法" width="80">
            <template #default="{ row }">
              <el-tag :type="getMethodTagType(row.httpMethod)" size="small">
                {{ row.httpMethod }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="apiUrl" label="API路径" min-width="200" show-overflow-tooltip />
          <el-table-column prop="changeType" label="变更类型" width="100">
            <template #default="{ row }">
              <el-tag :type="getChangeTypeTag(row.changeType)" size="small">
                {{ getChangeTypeLabel(row.changeType) }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="riskLevel" label="风险" width="80">
            <template #default="{ row }">
              <el-tag :type="getRiskTagType(row.riskLevel)" size="small">
                {{ row.riskLevel }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="changeReason" label="原因" min-width="200" show-overflow-tooltip />
          <el-table-column label="操作" width="80">
            <template #default="{ row }">
              <el-button type="primary" link @click="showApiDetail(row)">详情</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <el-divider v-if="result.apiDiffs?.length" />

      <!-- 文件差异详情 -->
      <div class="detail-section" v-if="result.fileDiffs?.length">
        <h3>文件差异详情</h3>
        <el-table :data="result.fileDiffs" style="width: 100%">
          <el-table-column prop="filePath" label="文件路径" min-width="250" show-overflow-tooltip />
          <el-table-column prop="diffType" label="类型" width="100">
            <template #default="{ row }">
              <el-tag :type="getDiffTypeTag(row.diffType)" size="small">
                {{ row.diffType }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="方法变更" min-width="200">
            <template #default="{ row }">
              <template v-if="row.methodChanges && row.methodChanges.length > 0">
                <div class="method-changes">
                  <template v-for="(mc, index) in row.methodChanges.slice(0, 3)" :key="index">
                    <el-tag
                      :type="mc.changeType === 'ADDED' ? 'success' : mc.changeType === 'DELETED' ? 'danger' : 'warning'"
                      size="small"
                      class="method-tag"
                    >
                      {{ mc.changeType === 'ADDED' ? '+' : mc.changeType === 'DELETED' ? '-' : '~' }}{{ mc.methodName }}
                    </el-tag>
                  </template>
                  <el-popover
                    v-if="row.methodChanges.length > 3"
                    placement="left"
                    :width="400"
                    trigger="click"
                  >
                    <template #reference>
                      <el-tag type="info" size="small" class="method-tag clickable">
                        +{{ row.methodChanges.length - 3 }} 更多
                      </el-tag>
                    </template>
                    <div class="method-popover">
                      <div class="method-popover-header">
                        <span>共 {{ row.methodChanges.length }} 个方法变更</span>
                      </div>
                      <div class="method-popover-list">
                        <div
                          v-for="(mc, index) in row.methodChanges"
                          :key="index"
                          class="method-item"
                        >
                          <el-tag
                            :type="mc.changeType === 'ADDED' ? 'success' : mc.changeType === 'DELETED' ? 'danger' : 'warning'"
                            size="small"
                          >
                            {{ mc.changeType === 'ADDED' ? '+' : mc.changeType === 'DELETED' ? '-' : '~' }}
                            {{ mc.changeType === 'ADDED' ? '新增' : mc.changeType === 'DELETED' ? '删除' : '修改' }}
                          </el-tag>
                          <span class="method-name">{{ mc.methodName }}</span>
                        </div>
                      </div>
                    </div>
                  </el-popover>
                </div>
              </template>
              <template v-else>
                <span v-if="row.methodsAdded > 0" class="added">+{{ row.methodsAdded }}</span>
                <span v-if="row.methodsModified > 0" class="modified">~{{ row.methodsModified }}</span>
                <span v-if="row.methodsDeleted > 0" class="deleted">-{{ row.methodsDeleted }}</span>
                <span v-if="row.methodsAdded === 0 && row.methodsModified === 0 && row.methodsDeleted === 0">-</span>
              </template>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>

    <!-- API详情弹窗 -->
    <el-dialog v-model="apiDetailVisible" title="API变更详情" width="600px">
      <el-descriptions :column="1" border v-if="selectedApi">
        <el-descriptions-item label="API路径">{{ selectedApi.apiUrl }}</el-descriptions-item>
        <el-descriptions-item label="HTTP方法">{{ selectedApi.httpMethod }}</el-descriptions-item>
        <el-descriptions-item label="控制器">{{ selectedApi.controllerClass }}</el-descriptions-item>
        <el-descriptions-item label="方法名">{{ selectedApi.methodName }}</el-descriptions-item>
        <el-descriptions-item label="变更类型">{{ getChangeTypeLabel(selectedApi.changeType) }}</el-descriptions-item>
        <el-descriptions-item label="风险等级">{{ selectedApi.riskLevel }}</el-descriptions-item>
        <el-descriptions-item label="变更原因">{{ selectedApi.changeReason }}</el-descriptions-item>
        <el-descriptions-item label="调用链" v-if="selectedApi.callChain?.length">
          <div class="call-chain">
            <template v-for="(node, index) in selectedApi.callChain" :key="index">
              <span class="node">{{ node.className }}.{{ node.methodName }}</span>
              <span v-if="index < selectedApi.callChain.length - 1" class="arrow">→</span>
            </template>
          </div>
        </el-descriptions-item>
      </el-descriptions>
    </el-dialog>

    <!-- 保存对话框 -->
    <el-dialog v-model="saveDialogVisible" title="保存对比结果" width="500px">
      <el-form :model="saveForm" label-width="80px">
        <el-form-item label="基线文件">
          <el-input :value="baselineFile?.name" disabled />
        </el-form-item>
        <el-form-item label="目标文件">
          <el-input :value="targetFile?.name" disabled />
        </el-form-item>
        <el-form-item label="描述">
          <el-input
            v-model="saveForm.description"
            type="textarea"
            :rows="3"
            placeholder="请输入对比结果的描述（可选）"
            maxlength="500"
            show-word-limit
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="saveDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveResult" :loading="saving">
          {{ saving ? '保存中...' : '保存' }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'
import { UploadFilled, Document, DocumentAdd, Edit, Delete, Operation } from '@element-plus/icons-vue'
import diffAnalysisApi from '@/api/diffAnalysis'

// 文件
const baselineFile = ref(null)
const targetFile = ref(null)

// 状态
const analyzing = ref(false)
const progress = ref(0)
const progressText = ref('')
const result = ref(null)
const saved = ref(false)

// 详情
const activeTab = ref('all')
const apiDetailVisible = ref(false)
const selectedApi = ref(null)

// 保存
const saveDialogVisible = ref(false)
const saving = ref(false)
const saveForm = ref({
  description: ''
})

// 计算属性
const totalMethodChanges = computed(() => {
  const s = result.value?.fileSummary || {}
  return (s.totalMethodsAdded || 0) + (s.totalMethodsModified || 0) + (s.totalMethodsDeleted || 0)
})

const filteredApiDiffs = computed(() => {
  if (!result.value?.apiDiffs) return []
  if (activeTab.value === 'all') return result.value.apiDiffs
  return result.value.apiDiffs.filter(api => api.changeType === activeTab.value)
})

// 方法
const onBaselineChange = (file) => {
  baselineFile.value = file.raw
}

const onTargetChange = (file) => {
  targetFile.value = file.raw
}

const formatSize = (bytes) => {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
}

const startAnalysis = async () => {
  if (!baselineFile.value || !targetFile.value) {
    ElMessage.warning('请选择基线和目标文件')
    return
  }

  analyzing.value = true
  progress.value = 0
  progressText.value = '正在上传文件...'

  // 模拟进度
  const progressInterval = setInterval(() => {
    if (progress.value < 90) {
      progress.value += Math.random() * 10
      if (progress.value > 90) progress.value = 90
    }
  }, 500)

  try {
    progressText.value = '正在分析差异...'
    const res = await diffAnalysisApi.quickDiff(baselineFile.value, targetFile.value)
    // 后端返回 Result<QuickDiffResponse>，需要从 data 字段获取实际数据
    result.value = res.data || res
    progress.value = 100
    progressText.value = '分析完成'
    ElMessage.success('差异对比完成')
  } catch (e) {
    console.error('差异对比失败', e)
    ElMessage.error('差异对比失败: ' + (e.message || '未知错误'))
  } finally {
    clearInterval(progressInterval)
    analyzing.value = false
  }
}

const resetAnalysis = () => {
  result.value = null
  baselineFile.value = null
  targetFile.value = null
  progress.value = 0
  activeTab.value = 'all'
  saved.value = false
}

const showApiDetail = (api) => {
  selectedApi.value = api
  apiDetailVisible.value = true
}

// 标签类型
const getMethodTagType = (method) => {
  const types = { GET: 'success', POST: 'primary', PUT: 'warning', DELETE: 'danger' }
  return types[method] || 'info'
}

const getChangeTypeTag = (type) => {
  const types = { NEW_API: 'success', MODIFIED_API: 'warning', AFFECTED_API: 'info', DELETED_API: 'danger' }
  return types[type] || ''
}

const getChangeTypeLabel = (type) => {
  const labels = { NEW_API: '新增', MODIFIED_API: '修改', AFFECTED_API: '受影响', DELETED_API: '删除' }
  return labels[type] || type
}

const getRiskTagType = (level) => {
  const types = { HIGH: 'danger', MEDIUM: 'warning', LOW: 'info' }
  return types[level] || ''
}

const getDiffTypeTag = (type) => {
  const types = { ADDED: 'success', MODIFIED: 'warning', DELETED: 'danger' }
  return types[type] || ''
}

// 保存相关方法
const showSaveDialog = () => {
  saveDialogVisible.value = true
  saveForm.value.description = ''
}

const saveResult = async () => {
  if (!baselineFile.value || !targetFile.value || !result.value) {
    ElMessage.warning('没有可保存的结果')
    return
  }

  saving.value = true
  try {
    await diffAnalysisApi.quickDiffSave(
      baselineFile.value,
      targetFile.value,
      saveForm.value.description
    )
    saved.value = true
    saveDialogVisible.value = false
    ElMessage.success('保存成功')
  } catch (e) {
    console.error('保存失败', e)
    ElMessage.error('保存失败: ' + (e.message || '未知错误'))
  } finally {
    saving.value = false
  }
}
</script>

<style scoped>
.quick-diff {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.file-info {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 10px;
  padding: 10px;
  background: #f5f7fa;
  border-radius: 4px;
}

.file-size {
  color: #909399;
  font-size: 12px;
}

.actions {
  margin-top: 20px;
  text-align: center;
}

.progress-container {
  padding: 40px 20px;
  text-align: center;
}

.progress-text {
  margin-top: 15px;
  color: #666;
}

.summary-section {
  padding: 10px 0;
}

.summary-section h3 {
  margin-bottom: 15px;
  color: #303133;
}

.stat-box {
  text-align: center;
  padding: 20px;
  border-radius: 8px;
  background: #f5f7fa;
}

.stat-box.high {
  background: #fef0f0;
}

.stat-box.medium {
  background: #fdf6ec;
}

.stat-box.low {
  background: #f0f9eb;
}

.stat-box .label {
  font-size: 14px;
  color: #666;
}

.stat-box .value {
  font-size: 28px;
  font-weight: bold;
  margin-top: 5px;
}

.detail-section h3 {
  margin-bottom: 15px;
  color: #303133;
}

.added {
  color: #67C23A;
  margin-right: 10px;
}

.modified {
  color: #E6A23C;
  margin-right: 10px;
}

.deleted {
  color: #F56C6C;
}

.call-chain {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 5px;
}

.call-chain .node {
  padding: 2px 8px;
  background: #f0f2f5;
  border-radius: 4px;
  font-size: 12px;
}

.call-chain .arrow {
  color: #409EFF;
}

.method-changes {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.method-tag {
  font-size: 11px;
}

.method-tag.clickable {
  cursor: pointer;
}

.method-tag.clickable:hover {
  opacity: 0.8;
}

.method-popover {
  max-height: 400px;
  overflow-y: auto;
}

.method-popover-header {
  font-weight: bold;
  margin-bottom: 10px;
  padding-bottom: 8px;
  border-bottom: 1px solid #ebeef5;
}

.method-popover-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.method-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 4px 0;
}

.method-name {
  font-family: monospace;
  font-size: 13px;
  word-break: break-all;
}
</style>
