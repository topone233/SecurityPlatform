package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.QuickDiffListItem;
import org.example.securityplatform.dto.QuickDiffResponse;
import org.example.securityplatform.service.QuickDiffService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 快速差异对比 API 控制器
 * 独立运行，直接上传两个JAR包进行对比，无需预先创建项目和制品
 */
@Tag(name = "快速差异对比", description = "直接上传两个JAR包进行差异对比")
@Slf4j
@RestController
@RequestMapping("/api/quick-diff")
@RequiredArgsConstructor
public class QuickDiffController {

    private final QuickDiffService quickDiffService;

    /**
     * 执行快速差异对比
     */
    @Operation(summary = "快速差异对比", description = "上传基线和目标JAR包，直接进行差异对比分析")
    @PostMapping(value = "/analyze", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Result<QuickDiffResponse> analyze(
            @Parameter(description = "基线JAR文件") @RequestParam("baseline") MultipartFile baseline,
            @Parameter(description = "目标JAR文件") @RequestParam("target") MultipartFile target) {

        log.info("收到快速差异对比请求: baseline={}, target={}",
                baseline.getOriginalFilename(), target.getOriginalFilename());

        // 校验文件
        validateFile(baseline, "基线文件");
        validateFile(target, "目标文件");

        // 执行分析
        QuickDiffResponse response = quickDiffService.analyze(baseline, target);

        return Result.success(response);
    }

    /**
     * 执行快速差异对比并保存结果
     */
    @Operation(summary = "快速差异对比并保存", description = "上传基线和目标JAR包，进行差异对比分析并保存结果到数据库")
    @PostMapping(value = "/save", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Result<QuickDiffResponse> analyzeAndSave(
            @Parameter(description = "基线JAR文件") @RequestParam("baseline") MultipartFile baseline,
            @Parameter(description = "目标JAR文件") @RequestParam("target") MultipartFile target,
            @Parameter(description = "描述") @RequestParam(value = "description", required = false) String description) {

        log.info("收到快速差异对比并保存请求: baseline={}, target={}",
                baseline.getOriginalFilename(), target.getOriginalFilename());

        // 校验文件
        validateFile(baseline, "基线文件");
        validateFile(target, "目标文件");

        // 执行分析并保存
        QuickDiffResponse response = quickDiffService.analyzeAndSave(baseline, target, description);

        return Result.success(response);
    }

    /**
     * 查询历史记录列表
     */
    @Operation(summary = "查询历史记录列表", description = "查询所有快速差异对比的历史记录")
    @GetMapping("/list")
    public Result<List<QuickDiffListItem>> list() {
        List<QuickDiffListItem> records = quickDiffService.findAllOrderByCreateTimeDesc();
        return Result.success(records);
    }

    /**
     * 查询详情
     */
    @Operation(summary = "查询详情", description = "根据ID查询快速差异对比的详细信息")
    @GetMapping("/{id}")
    public Result<QuickDiffResponse> getById(@PathVariable Long id) {
        QuickDiffResponse response = quickDiffService.findById(id);
        return Result.success(response);
    }

    /**
     * 删除记录
     */
    @Operation(summary = "删除记录", description = "根据ID删除快速差异对比记录")
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        quickDiffService.deleteById(id);
        return Result.success(null);
    }

    /**
     * 校验上传文件
     */
    private void validateFile(MultipartFile file, String fileDesc) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException(fileDesc + "不能为空");
        }

        String filename = file.getOriginalFilename();
        if (filename == null) {
            throw new IllegalArgumentException(fileDesc + "文件名无效");
        }

        String extension = filename.substring(filename.lastIndexOf(".") + 1).toLowerCase();
        if (!"jar".equals(extension) && !"war".equals(extension)) {
            throw new IllegalArgumentException(fileDesc + "仅支持 .jar 或 .war 格式");
        }
    }
}
