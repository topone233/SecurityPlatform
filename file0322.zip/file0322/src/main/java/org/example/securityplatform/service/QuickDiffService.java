package org.example.securityplatform.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.api.ApiExtractorStrategy;
import org.example.securityplatform.analyzer.api.ApiModel;
import org.example.securityplatform.analyzer.api.BytecodeApiExtractorStrategy;
import org.example.securityplatform.analyzer.api.SpringMvcApiExtractor;
import org.example.securityplatform.analyzer.api.JaxRsApiExtractor;
import org.example.securityplatform.analyzer.diff.*;
import org.example.securityplatform.dto.QuickDiffListItem;
import org.example.securityplatform.dto.QuickDiffResponse;
import org.example.securityplatform.entity.ApiInfo;
import org.example.securityplatform.entity.MethodCallEdge;
import org.example.securityplatform.entity.QuickDiffRecord;
import org.example.securityplatform.exception.BusinessException;
import org.example.securityplatform.repository.QuickDiffRecordRepository;
import org.example.securityplatform.util.FileUtil;
import org.example.securityplatform.util.HashUtil;
import org.example.securityplatform.util.JarUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Collectors;

/**
 * 快速差异对比服务
 * 独立运行，不依赖数据库，直接分析上传的JAR文件
 */
@Slf4j
@Service
public class QuickDiffService {

    private final List<ApiExtractorStrategy> apiStrategies = new ArrayList<>();

    @Autowired
    private QuickDiffRecordRepository quickDiffRecordRepository;

    @Autowired
    private ObjectMapper objectMapper;

    public QuickDiffService() {
        apiStrategies.add(new SpringMvcApiExtractor());
        apiStrategies.add(new JaxRsApiExtractor());
        apiStrategies.add(new BytecodeApiExtractorStrategy());
    }

    /**
     * 执行快速差异对比
     *
     * @param baselineFile 基线文件
     * @param targetFile   目标文件
     * @return 对比结果
     */
    public QuickDiffResponse analyze(MultipartFile baselineFile, MultipartFile targetFile) {
        log.info("开始快速差异对比: baseline={}, target={}",
                baselineFile.getOriginalFilename(), targetFile.getOriginalFilename());
        long startTime = System.currentTimeMillis();

        String tempDir = null;
        try {
            // 创建临时目录
            tempDir = createTempDir();
            String baselinePath = saveTempFile(tempDir, "baseline", baselineFile);
            String targetPath = saveTempFile(tempDir, "target", targetFile);

            // 执行分析
            QuickDiffResponse response = doAnalyze(baselinePath, targetPath);

            long endTime = System.currentTimeMillis();
            response.setDuration(endTime - startTime);
            log.info("快速差异对比完成: 耗时={}ms", endTime - startTime);

            return response;

        } catch (Exception e) {
            log.error("快速差异对比失败", e);
            throw new BusinessException("差异对比失败: " + e.getMessage());
        } finally {
            // 清理临时文件
            if (tempDir != null) {
                cleanupTempDir(tempDir);
            }
        }
    }

    /**
     * 执行核心分析逻辑
     */
    private QuickDiffResponse doAnalyze(String baselinePath, String targetPath) throws IOException {
        // Step 1: 文件差异检测
        log.info("Step 1: 文件差异检测");
        FileDiffDetector fileDiffDetector = new FileDiffDetector(baselinePath, targetPath);
        List<FileDiffModel> fileDiffs = fileDiffDetector.detect();
        FileDiffDetector.DiffStatistics fileStats = fileDiffDetector.getStatistics(fileDiffs);

        // Step 2: 提取API信息（不依赖数据库）
        log.info("Step 2: 提取API信息");
        List<ApiInfo> baselineApis = extractApisFromJar(baselinePath, "baseline");
        List<ApiInfo> targetApis = extractApisFromJar(targetPath, "target");

        // Step 3: 构建调用图
        log.info("Step 3: 构建调用图");
        List<MethodCallModel> callModels = new ArrayList<>();
        try {
            CallGraphBuilder callGraphBuilder = new CallGraphBuilder(targetPath);
            callModels = callGraphBuilder.build();
        } catch (Exception e) {
            log.warn("调用图构建失败，跳过API影响追溯", e);
        }

        // 转换为MethodCallEdge
        List<MethodCallEdge> callEdges = callModels.stream().map(call -> {
            MethodCallEdge edge = new MethodCallEdge();
            edge.setCallerClass(call.getCallerClass());
            edge.setCallerMethod(call.getCallerMethod());
            edge.setCalleeClass(call.getCalleeClass());
            edge.setCalleeMethod(call.getCalleeMethod());
            edge.setCallType(call.getCallType());
            return edge;
        }).collect(Collectors.toList());

        // Step 4: 提取变更方法
        log.info("Step 4: 提取变更方法");
        Set<String> changedMethods = extractChangedMethods(fileDiffs);

        // Step 5: 先检测新增和删除的API（基于 baseline 和 target 对比）
        log.info("Step 5: 检测新增和删除的API");
        List<ApiChangeModel> newDeletedApis = detectNewAndDeletedApis(baselineApis, targetApis);

        // 获取新增的 API 对应的 Controller 方法（这些方法不应该被标记为 MODIFIED_API）
        Set<String> newApiControllerMethods = new HashSet<>();
        for (ApiChangeModel change : newDeletedApis) {
            if ("NEW_API".equals(change.getChangeType()) && change.getControllerClass() != null) {
                newApiControllerMethods.add(change.getControllerClass() + "#" + change.getMethodName());
            }
        }

        // Step 6: API影响追溯
        log.info("Step 6: API影响追溯");
        List<ApiChangeModel> apiChanges = new ArrayList<>(newDeletedApis);

        if (!callEdges.isEmpty() && !targetApis.isEmpty()) {
            // 过滤掉新增 Controller 的方法，只保留真正修改的方法
            Set<String> modifiedMethods = changedMethods.stream()
                    .filter(m -> !newApiControllerMethods.contains(m))
                    .collect(Collectors.toSet());

            if (!modifiedMethods.isEmpty()) {
                ApiImpactAnalyzer analyzer = new ApiImpactAnalyzer(callEdges, targetApis, modifiedMethods);
                List<ApiChangeModel> affectedChanges = analyzer.analyze();

                // 去重：移除已经作为 NEW_API 或 DELETED_API 检测过的
                Set<String> existingApiKeys = apiChanges.stream()
                        .map(c -> c.getHttpMethod() + " " + c.getApiUrl())
                        .collect(Collectors.toSet());
                for (ApiChangeModel change : affectedChanges) {
                    String key = change.getHttpMethod() + " " + change.getApiUrl();
                    if (!existingApiKeys.contains(key)) {
                        apiChanges.add(change);
                    }
                }
            }
        }

        // 构建响应
        return buildResponse(fileDiffs, fileStats, apiChanges);
    }

    /**
     * 从JAR包提取API信息（独立方法，不依赖数据库）
     */
    private List<ApiInfo> extractApisFromJar(String jarPath, String label) throws IOException {
        List<ApiInfo> apiInfos = new ArrayList<>();

        // 创建临时解压目录
        String tempExtractDir = createTempDir() + "/" + label;
        FileUtil.createDirectoryIfNotExists(tempExtractDir);

        try {
            JarUtil.extractJar(jarPath, tempExtractDir);

            // 获取所有class文件
            List<Path> classFiles = FileUtil.listFilesByExtension(tempExtractDir, "class");

            // 处理 Spring Boot Fat JAR 结构：检查 BOOT-INF/classes 目录
            String bootInfClassesDir = tempExtractDir + "/BOOT-INF/classes";
            File bootInfDir = new File(bootInfClassesDir);
            if (bootInfDir.exists() && bootInfDir.isDirectory()) {
                log.info("检测到 Spring Boot Fat JAR 结构，扫描 BOOT-INF/classes 目录");
                List<Path> bootInfClassFiles = FileUtil.listFilesByExtension(bootInfClassesDir, "class");
                classFiles.addAll(bootInfClassFiles);
                log.info("从 BOOT-INF/classes 找到 {} 个 class 文件", bootInfClassFiles.size());
            }

            for (Path classFile : classFiles) {
                for (ApiExtractorStrategy strategy : apiStrategies) {
                    if (strategy.supports(classFile.toString())) {
                        List<ApiModel> apis = strategy.extract(classFile.toString());
                        for (ApiModel api : apis) {
                            ApiInfo info = new ApiInfo();
                            info.setUrl(api.getUrl());
                            info.setHttpMethod(api.getHttpMethod());
                            info.setControllerClass(api.getControllerClass());
                            info.setMethodName(api.getMethodName());
                            info.setParameters(api.getParameters());
                            info.setFramework(api.getFramework());
                            apiInfos.add(info);
                        }
                    }
                }
            }

            log.info("从{}提取到 {} 个API", label, apiInfos.size());

        } finally {
            // 清理解压目录
            FileUtil.deleteDirectory(tempExtractDir);
        }

        return apiInfos;
    }

    /**
     * 提取变更的方法
     */
    private Set<String> extractChangedMethods(List<FileDiffModel> fileDiffs) {
        Set<String> changedMethods = new HashSet<>();

        for (FileDiffModel fileDiff : fileDiffs) {
            if (fileDiff.getBytecodeDiff() != null && fileDiff.getBytecodeDiff().getMethodChanges() != null) {
                String className = fileDiff.getFilePath();
                if (className.endsWith(".class")) {
                    className = className.substring(0, className.length() - 6);
                }

                // 处理 Spring Boot Fat JAR 路径：BOOT-INF/classes/org/example/... -> org.example...
                if (className.startsWith("BOOT-INF/classes/")) {
                    className = className.substring("BOOT-INF/classes/".length());
                } else if (className.startsWith("BOOT-INF\\classes\\")) {
                    className = className.substring("BOOT-INF\\classes\\".length());
                }

                // 转换为标准类名格式
                className = className.replace('/', '.').replace('\\', '.');

                for (MethodChangeModel methodChange : fileDiff.getBytecodeDiff().getMethodChanges()) {
                    changedMethods.add(className + "#" + methodChange.getMethodName());
                }
            }
        }

        log.info("提取到 {} 个变更方法", changedMethods.size());
        return changedMethods;
    }

    /**
     * 检测新增和删除的API
     */
    private List<ApiChangeModel> detectNewAndDeletedApis(List<ApiInfo> baselineApis, List<ApiInfo> targetApis) {
        List<ApiChangeModel> changes = new ArrayList<>();

        // 使用 Map 去重，以 key 为唯一标识
        Map<String, ApiInfo> baselineApiMap = baselineApis.stream()
                .collect(Collectors.toMap(
                        api -> api.getHttpMethod() + " " + api.getUrl(),
                        api -> api,
                        (existing, replacement) -> existing, // 保留第一个
                        LinkedHashMap::new
                ));

        Map<String, ApiInfo> targetApiMap = targetApis.stream()
                .collect(Collectors.toMap(
                        api -> api.getHttpMethod() + " " + api.getUrl(),
                        api -> api,
                        (existing, replacement) -> existing, // 保留第一个
                        LinkedHashMap::new
                ));

        Set<String> baselineApiKeys = baselineApiMap.keySet();
        Set<String> targetApiKeys = targetApiMap.keySet();

        // 新增的API
        for (Map.Entry<String, ApiInfo> entry : targetApiMap.entrySet()) {
            if (!baselineApiKeys.contains(entry.getKey())) {
                ApiInfo api = entry.getValue();
                ApiChangeModel change = new ApiChangeModel();
                change.setApiUrl(api.getUrl());
                change.setHttpMethod(api.getHttpMethod());
                change.setControllerClass(api.getControllerClass());
                change.setMethodName(api.getMethodName());
                change.setChangeType("NEW_API");
                change.setChangeReason("新增的API端点");
                change.setRiskLevel("HIGH");
                changes.add(change);
            }
        }

        // 删除的API
        for (Map.Entry<String, ApiInfo> entry : baselineApiMap.entrySet()) {
            if (!targetApiKeys.contains(entry.getKey())) {
                ApiInfo api = entry.getValue();
                ApiChangeModel change = new ApiChangeModel();
                change.setApiUrl(api.getUrl());
                change.setHttpMethod(api.getHttpMethod());
                change.setControllerClass(api.getControllerClass());
                change.setMethodName(api.getMethodName());
                change.setChangeType("DELETED_API");
                change.setChangeReason("删除的API端点");
                change.setRiskLevel("MEDIUM");
                changes.add(change);
            }
        }

        return changes;
    }

    /**
     * 构建响应
     */
    private QuickDiffResponse buildResponse(List<FileDiffModel> fileDiffs,
                                             FileDiffDetector.DiffStatistics fileStats,
                                             List<ApiChangeModel> apiChanges) {
        // 构建文件差异列表
        List<QuickDiffResponse.FileDiffItem> fileDiffItems = fileDiffs.stream()
                .map(this::toFileDiffItem)
                .collect(Collectors.toList());

        // 构建API变更列表
        List<QuickDiffResponse.ApiDiffItem> apiDiffItems = apiChanges.stream()
                .map(this::toApiDiffItem)
                .collect(Collectors.toList());

        // 计算API统计
        QuickDiffResponse.ApiDiffSummary apiSummary = calculateApiSummary(apiChanges);

        return QuickDiffResponse.builder()
                .fileSummary(QuickDiffResponse.FileDiffSummary.builder()
                        .addedFiles(fileStats.getAddedFiles())
                        .modifiedFiles(fileStats.getModifiedFiles())
                        .deletedFiles(fileStats.getDeletedFiles())
                        .totalMethodsAdded(fileStats.getTotalMethodsAdded())
                        .totalMethodsDeleted(fileStats.getTotalMethodsDeleted())
                        .totalMethodsModified(fileStats.getTotalMethodsModified())
                        .build())
                .apiSummary(apiSummary)
                .fileDiffs(fileDiffItems)
                .apiDiffs(apiDiffItems)
                .build();
    }

    private QuickDiffResponse.FileDiffItem toFileDiffItem(FileDiffModel model) {
        // 映射方法变更详情
        List<QuickDiffResponse.FileDiffItem.MethodChange> methodChanges = null;
        if (model.getBytecodeDiff() != null && model.getBytecodeDiff().getMethodChanges() != null) {
            methodChanges = model.getBytecodeDiff().getMethodChanges().stream()
                    .filter(mc -> !mc.isConstructor()) // 过滤掉构造方法
                    .map(mc -> QuickDiffResponse.FileDiffItem.MethodChange.builder()
                            .methodName(mc.getMethodName())
                            .changeType(mc.getChangeType())
                            .build())
                    .collect(Collectors.toList());
        }

        return QuickDiffResponse.FileDiffItem.builder()
                .filePath(model.getFilePath())
                .sourceFilePath(model.getSourceFilePath())
                .diffType(model.getDiffType())
                .baselineLines(model.getBaselineLines())
                .targetLines(model.getTargetLines())
                .methodsAdded(model.getMethodsAdded())
                .methodsDeleted(model.getMethodsDeleted())
                .methodsModified(model.getMethodsModified())
                .methodChanges(methodChanges)
                .build();
    }

    private QuickDiffResponse.ApiDiffItem toApiDiffItem(ApiChangeModel model) {
        List<QuickDiffResponse.ApiDiffItem.CallChainNode> callChain = null;
        if (model.getCallChain() != null) {
            callChain = model.getCallChain().stream()
                    .map(node -> QuickDiffResponse.ApiDiffItem.CallChainNode.builder()
                            .className(node.getClassName())
                            .methodName(node.getMethodName())
                            .depth(node.getDepth())
                            .build())
                    .collect(Collectors.toList());
        }

        return QuickDiffResponse.ApiDiffItem.builder()
                .apiUrl(model.getApiUrl())
                .httpMethod(model.getHttpMethod())
                .controllerClass(model.getControllerClass())
                .methodName(model.getMethodName())
                .changeType(model.getChangeType())
                .changeReason(model.getChangeReason())
                .riskLevel(model.getRiskLevel())
                .callChain(callChain)
                .build();
    }

    private QuickDiffResponse.ApiDiffSummary calculateApiSummary(List<ApiChangeModel> apiChanges) {
        int newApis = 0, modifiedApis = 0, affectedApis = 0, deletedApis = 0;
        int highRisk = 0, mediumRisk = 0, lowRisk = 0;

        for (ApiChangeModel change : apiChanges) {
            switch (change.getChangeType()) {
                case "NEW_API": newApis++; break;
                case "MODIFIED_API": modifiedApis++; break;
                case "AFFECTED_API": affectedApis++; break;
                case "DELETED_API": deletedApis++; break;
            }
            switch (change.getRiskLevel()) {
                case "HIGH": highRisk++; break;
                case "MEDIUM": mediumRisk++; break;
                case "LOW": lowRisk++; break;
            }
        }

        return QuickDiffResponse.ApiDiffSummary.builder()
                .newApis(newApis)
                .modifiedApis(modifiedApis)
                .affectedApis(affectedApis)
                .deletedApis(deletedApis)
                .highRiskApis(highRisk)
                .mediumRiskApis(mediumRisk)
                .lowRiskApis(lowRisk)
                .build();
    }

    // ==================== 辅助方法 ====================

    private String createTempDir() throws IOException {
        Path tempPath = Files.createTempDirectory("quick_diff_");
        return tempPath.toString();
    }

    private String saveTempFile(String tempDir, String prefix, MultipartFile file) throws IOException {
        String fileName = prefix + "_" + file.getOriginalFilename();
        String filePath = tempDir + File.separator + fileName;
        Files.copy(file.getInputStream(), Paths.get(filePath));
        log.info("保存临时文件: {}", filePath);
        return filePath;
    }

    private void cleanupTempDir(String tempDir) {
        try {
            FileUtil.deleteDirectory(tempDir);
            log.info("清理临时目录: {}", tempDir);
        } catch (Exception e) {
            log.warn("清理临时目录失败: {}", tempDir, e);
        }
    }

    // ==================== 持久化相关方法 ====================

    /**
     * 分析并保存结果
     */
    public QuickDiffResponse analyzeAndSave(MultipartFile baselineFile, MultipartFile targetFile, String description) {
        log.info("开始快速差异对比并保存: baseline={}, target={}",
                baselineFile.getOriginalFilename(), targetFile.getOriginalFilename());

        // 执行分析
        QuickDiffResponse response = analyze(baselineFile, targetFile);

        // 保存到数据库
        try {
            QuickDiffRecord record = new QuickDiffRecord();
            record.setBaselineFileName(baselineFile.getOriginalFilename());
            record.setTargetFileName(targetFile.getOriginalFilename());
            record.setBaselineMd5(calculateMd5(baselineFile));
            record.setTargetMd5(calculateMd5(targetFile));
            record.setFileSummaryJson(serializeToJson(response.getFileSummary()));
            record.setApiSummaryJson(serializeToJson(response.getApiSummary()));
            record.setFileDiffsJson(serializeToJson(response.getFileDiffs()));
            record.setApiDiffsJson(serializeToJson(response.getApiDiffs()));
            record.setDurationMs(response.getDuration());
            record.setDescription(description);

            record = quickDiffRecordRepository.save(record);
            log.info("快速差异对比结果已保存，ID={}", record.getId());

            return response;
        } catch (Exception e) {
            log.error("保存快速差异对比结果失败", e);
            throw new BusinessException("保存结果失败: " + e.getMessage());
        }
    }

    /**
     * 根据ID查询详情
     */
    public QuickDiffResponse findById(Long id) {
        QuickDiffRecord record = quickDiffRecordRepository.findById(id)
                .orElseThrow(() -> new BusinessException("记录不存在: " + id));

        return convertToResponse(record);
    }

    /**
     * 查询所有历史记录（按创建时间倒序）
     */
    public List<QuickDiffListItem> findAllOrderByCreateTimeDesc() {
        List<QuickDiffRecord> records = quickDiffRecordRepository.findAllByOrderByCreatedAtDesc();
        return records.stream()
                .map(this::convertToListItem)
                .collect(Collectors.toList());
    }

    /**
     * 删除记录
     */
    public void deleteById(Long id) {
        if (!quickDiffRecordRepository.existsById(id)) {
            throw new BusinessException("记录不存在: " + id);
        }
        quickDiffRecordRepository.deleteById(id);
        log.info("已删除快速差异对比记录，ID={}", id);
    }

    // ==================== 辅助方法 ====================

    /**
     * 计算文件MD5
     */
    private String calculateMd5(MultipartFile file) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(file.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            log.warn("计算MD5失败", e);
            return null;
        }
    }

    /**
     * 序列化为JSON
     */
    private String serializeToJson(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            log.error("JSON序列化失败", e);
            throw new RuntimeException("JSON序列化失败", e);
        }
    }

    /**
     * 从JSON反序列化
     */
    private <T> T deserializeFromJson(String json, TypeReference<T> typeReference) {
        try {
            return objectMapper.readValue(json, typeReference);
        } catch (Exception e) {
            log.error("JSON反序列化失败", e);
            throw new RuntimeException("JSON反序列化失败", e);
        }
    }

    /**
     * 实体转换为响应对象
     */
    private QuickDiffResponse convertToResponse(QuickDiffRecord record) {
        try {
            QuickDiffResponse.FileDiffSummary fileSummary = deserializeFromJson(
                    record.getFileSummaryJson(),
                    new TypeReference<QuickDiffResponse.FileDiffSummary>() {}
            );

            QuickDiffResponse.ApiDiffSummary apiSummary = deserializeFromJson(
                    record.getApiSummaryJson(),
                    new TypeReference<QuickDiffResponse.ApiDiffSummary>() {}
            );

            List<QuickDiffResponse.FileDiffItem> fileDiffs = deserializeFromJson(
                    record.getFileDiffsJson(),
                    new TypeReference<List<QuickDiffResponse.FileDiffItem>>() {}
            );

            List<QuickDiffResponse.ApiDiffItem> apiDiffs = deserializeFromJson(
                    record.getApiDiffsJson(),
                    new TypeReference<List<QuickDiffResponse.ApiDiffItem>>() {}
            );

            return QuickDiffResponse.builder()
                    .fileSummary(fileSummary)
                    .apiSummary(apiSummary)
                    .fileDiffs(fileDiffs)
                    .apiDiffs(apiDiffs)
                    .duration(record.getDurationMs())
                    .build();
        } catch (Exception e) {
            log.error("转换响应失败", e);
            throw new BusinessException("数据解析失败: " + e.getMessage());
        }
    }

    /**
     * 实体转换为列表项
     */
    private QuickDiffListItem convertToListItem(QuickDiffRecord record) {
        try {
            QuickDiffResponse.FileDiffSummary fileSummary = deserializeFromJson(
                    record.getFileSummaryJson(),
                    new TypeReference<QuickDiffResponse.FileDiffSummary>() {}
            );

            QuickDiffResponse.ApiDiffSummary apiSummary = deserializeFromJson(
                    record.getApiSummaryJson(),
                    new TypeReference<QuickDiffResponse.ApiDiffSummary>() {}
            );

            int totalFilesChanged = fileSummary.getAddedFiles() + fileSummary.getModifiedFiles() + fileSummary.getDeletedFiles();
            int totalMethodChanges = fileSummary.getTotalMethodsAdded() + fileSummary.getTotalMethodsDeleted() + fileSummary.getTotalMethodsModified();
            int totalApiChanges = apiSummary.getNewApis() + apiSummary.getModifiedApis() + apiSummary.getAffectedApis() + apiSummary.getDeletedApis();

            return QuickDiffListItem.builder()
                    .id(record.getId())
                    .baselineFileName(record.getBaselineFileName())
                    .targetFileName(record.getTargetFileName())
                    .durationMs(record.getDurationMs())
                    .description(record.getDescription())
                    .createdAt(record.getCreatedAt())
                    .totalFilesChanged(totalFilesChanged)
                    .totalMethodChanges(totalMethodChanges)
                    .totalApiChanges(totalApiChanges)
                    .highRiskApis(apiSummary.getHighRiskApis())
                    .build();
        } catch (Exception e) {
            log.error("转换列表项失败", e);
            return QuickDiffListItem.builder()
                    .id(record.getId())
                    .baselineFileName(record.getBaselineFileName())
                    .targetFileName(record.getTargetFileName())
                    .durationMs(record.getDurationMs())
                    .description(record.getDescription())
                    .createdAt(record.getCreatedAt())
                    .totalFilesChanged(0)
                    .totalMethodChanges(0)
                    .totalApiChanges(0)
                    .highRiskApis(0)
                    .build();
        }
    }
}
