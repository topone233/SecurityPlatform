-- 删除api_diff表的risk_level索引
DROP INDEX IF EXISTS idx_api_diff_risk;

-- 删除api_diff表的risk_level列
ALTER TABLE api_diff DROP COLUMN IF EXISTS risk_level;

-- 清空所有历史数据（风险等级从未使用，历史数据无价值）
-- 注意：使用DELETE而不是TRUNCATE，因为TRUNCATE会违反外键约束
-- 先删除子表数据
DELETE FROM api_diff;
DELETE FROM file_diff;
DELETE FROM diff_analysis_progress;
-- 再删除父表数据
DELETE FROM diff_analysis_task;