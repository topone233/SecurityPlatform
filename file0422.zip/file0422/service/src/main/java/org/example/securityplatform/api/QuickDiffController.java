package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.jar.DependencyAnalysisConfig;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.DependencyPreviewResponse;
import org.example.securityplatform.dto.QuickDiffListItem;
import org.example.securityplatform.dto.QuickDiffResponse;
import org.example.securityplatform.service.QuickDiffService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 快速差异对比 API 控制器
 * 独立运行，直接上传两个JAR包进行对比，无需预先创建项目和制品
 */
@Tag(name = "快速差异对比", description = "直接上传两个JAR包进行差异对比")
@Slf4j
@RestController
@RequestMapping("/api/quick-diff")
@RequiredArgsConstructor
public class QuickDiffController {

    private final QuickDiffService quickDiffService;

    /**
     * 预览JAR包中的依赖信息
     * 用于前端下拉选择，自动列举依赖JAR和业务包名
     */
    @Operation(summary = "预览依赖信息", description = "预览JAR包中的依赖JAR列表和业务包名列表，用于配置多模块分析")
    @PostMapping(value = "/preview-dependencies", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Result<DependencyPreviewResponse> previewDependencies(
            @Parameter(description = "JAR文件") @RequestParam("file") MultipartFile file) {

        log.info("收到依赖预览请求: {}", file.getOriginalFilename());

        // 校验文件
        validateFile(file, "JAR文件");

        // 执行预览
        DependencyPreviewResponse response = quickDiffService.previewDependencies(file);

        return Result.success(response);
    }

    /**
     * 执行快速差异对比
     */
    @Operation(summary = "快速差异对比", description = "上传基线和目标JAR包，直接进行差异对比分析")
    @PostMapping(value = "/analyze", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Result<QuickDiffResponse> analyze(
            @Parameter(description = "基线JAR文件") @RequestParam("baseline") MultipartFile baseline,
            @Parameter(description = "目标JAR文件") @RequestParam("target") MultipartFile target,
            @Parameter(description = "是否分析依赖JAR") @RequestParam(value = "analyzeDependencies", required = false, defaultValue = "false") Boolean analyzeDependencies,
            @Parameter(description = "包含的包名模式，逗号分隔") @RequestParam(value = "includePackages", required = false) String includePackages,
            @Parameter(description = "包含的JAR名称模式，逗号分隔") @RequestParam(value = "includeJarNames", required = false) String includeJarNames) {

        log.info("收到快速差异对比请求: baseline={}, target={}, analyzeDependencies={}",
                baseline.getOriginalFilename(), target.getOriginalFilename(), analyzeDependencies);

        // 校验文件
        validateFile(baseline, "基线文件");
        validateFile(target, "目标文件");

        // 构建依赖分析配置
        DependencyAnalysisConfig depConfig = buildDependencyConfig(analyzeDependencies, includePackages, includeJarNames);

        // 执行分析
        QuickDiffResponse response = quickDiffService.analyze(baseline, target, depConfig);

        return Result.success(response);
    }

    /**
     * 执行快速差异对比并保存结果
     */
    @Operation(summary = "快速差异对比并保存", description = "上传基线和目标JAR包，进行差异对比分析并保存结果到数据库")
    @PostMapping(value = "/save", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Result<QuickDiffResponse> analyzeAndSave(
            @Parameter(description = "基线JAR文件") @RequestParam("baseline") MultipartFile baseline,
            @Parameter(description = "目标JAR文件") @RequestParam("target") MultipartFile target,
            @Parameter(description = "描述") @RequestParam(value = "description", required = false) String description,
            @Parameter(description = "是否分析依赖JAR") @RequestParam(value = "analyzeDependencies", required = false, defaultValue = "false") Boolean analyzeDependencies,
            @Parameter(description = "包含的包名模式，逗号分隔") @RequestParam(value = "includePackages", required = false) String includePackages,
            @Parameter(description = "包含的JAR名称模式，逗号分隔") @RequestParam(value = "includeJarNames", required = false) String includeJarNames) {

        log.info("收到快速差异对比并保存请求: baseline={}, target={}, analyzeDependencies={}",
                baseline.getOriginalFilename(), target.getOriginalFilename(), analyzeDependencies);

        // 校验文件
        validateFile(baseline, "基线文件");
        validateFile(target, "目标文件");

        // 构建依赖分析配置
        DependencyAnalysisConfig depConfig = buildDependencyConfig(analyzeDependencies, includePackages, includeJarNames);

        // 执行分析并保存
        QuickDiffResponse response = quickDiffService.analyzeAndSave(baseline, target, description, depConfig);

        return Result.success(response);
    }

    /**
     * 构建依赖分析配置
     */
    private DependencyAnalysisConfig buildDependencyConfig(Boolean analyzeDependencies, String includePackages, String includeJarNames) {
        if (analyzeDependencies == null || !analyzeDependencies) {
            return DependencyAnalysisConfig.defaultConfig();
        }

        List<String> packageList = parseStringList(includePackages);
        List<String> jarNameList = parseStringList(includeJarNames);

        log.info("构建依赖分析配置: includePackages={}, includeJarNames={}", packageList, jarNameList);

        return DependencyAnalysisConfig.withDependencies(packageList, jarNameList);
    }

    /**
     * 解析逗号分隔的字符串列表
     */
    private List<String> parseStringList(String str) {
        if (str == null || str.trim().isEmpty()) {
            return List.of();
        }
        String[] parts = str.split(",");
        return java.util.Arrays.stream(parts)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(java.util.stream.Collectors.toList());
    }

    /**
     * 查询历史记录列表
     */
    @Operation(summary = "查询历史记录列表", description = "查询所有快速差异对比的历史记录")
    @GetMapping("/list")
    public Result<List<QuickDiffListItem>> list() {
        List<QuickDiffListItem> records = quickDiffService.findAllOrderByCreateTimeDesc();
        return Result.success(records);
    }

    /**
     * 查询详情
     */
    @Operation(summary = "查询详情", description = "根据ID查询快速差异对比的详细信息")
    @GetMapping("/{id}")
    public Result<QuickDiffResponse> getById(@PathVariable Long id) {
        QuickDiffResponse response = quickDiffService.findById(id);
        return Result.success(response);
    }

    /**
     * 删除记录
     */
    @Operation(summary = "删除记录", description = "根据ID删除快速差异对比记录")
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        quickDiffService.deleteById(id);
        return Result.success(null);
    }

    /**
     * 校验上传文件
     */
    private void validateFile(MultipartFile file, String fileDesc) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException(fileDesc + "不能为空");
        }

        String filename = file.getOriginalFilename();
        if (filename == null) {
            throw new IllegalArgumentException(fileDesc + "文件名无效");
        }

        String extension = filename.substring(filename.lastIndexOf(".") + 1).toLowerCase();
        if (!"jar".equals(extension) && !"war".equals(extension)) {
            throw new IllegalArgumentException(fileDesc + "仅支持 .jar 或 .war 格式");
        }
    }
}
