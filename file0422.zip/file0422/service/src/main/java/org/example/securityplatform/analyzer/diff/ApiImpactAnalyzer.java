package org.example.securityplatform.analyzer.diff;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.core.InterfaceMapper;
import org.example.securityplatform.entity.ApiInfo;
import org.example.securityplatform.entity.MethodCallEdge;

import java.util.*;
import java.util.stream.Collectors;

/**
 * API影响追溯分析器 - 从变更方法反向追溯到API
 * 核心功能：构建调用链，找出受影响的API
 */
@Slf4j
public class ApiImpactAnalyzer {

    // 调用图（按被调用者索引，便于反向追溯）
    private final Map<String, List<MethodCallEdge>> callGraphByCallee;

    // API列表（Controller方法）
    private final List<ApiInfo> apis;

    // 变更的方法列表
    private final Set<String> changedMethods;

    // 接口映射器
    private final InterfaceMapper interfaceMapper;

    // 所有类名集合
    private final Set<String> classNames;

    // 追溯深度限制
    private static final int MAX_TRACE_DEPTH = 10;

    public ApiImpactAnalyzer(List<MethodCallEdge> callEdges, List<ApiInfo> apis, Set<String> changedMethods) {
        this.apis = apis;
        this.changedMethods = changedMethods;

        // 从调用边提取所有类名，构建接口映射
        this.classNames = new HashSet<>();
        for (MethodCallEdge edge : callEdges) {
            classNames.add(edge.getCallerClass());
            classNames.add(edge.getCalleeClass());
        }
        this.interfaceMapper = new InterfaceMapper();
        Map<String, Set<String>> interfaceToImpl = interfaceMapper.buildInterfaceToImplMap(classNames);

        // 构建按被调用者索引的调用图（含接口映射）
        this.callGraphByCallee = new HashMap<>();
        for (MethodCallEdge edge : callEdges) {
            String calleeKey = edge.getCalleeClass() + "#" + edge.getCalleeMethod();
            callGraphByCallee.computeIfAbsent(calleeKey, k -> new ArrayList<>()).add(edge);

            // 如果被调用者是接口，为实现类也添加索引（创建正确的边）
            Set<String> impls = interfaceToImpl.get(edge.getCalleeClass());
            if (impls != null) {
                for (String impl : impls) {
                    String implCalleeKey = impl + "#" + edge.getCalleeMethod();
                    // 创建新的边，calleeClass改为实现类名
                    MethodCallEdge implEdge = new MethodCallEdge();
                    implEdge.setCallerClass(edge.getCallerClass());
                    implEdge.setCallerMethod(edge.getCallerMethod());
                    implEdge.setCalleeClass(impl);  // 使用实现类名而非接口名
                    implEdge.setCalleeMethod(edge.getCalleeMethod());
                    implEdge.setCallLine(edge.getCallLine());

                    callGraphByCallee.computeIfAbsent(implCalleeKey, k -> new ArrayList<>()).add(implEdge);
                    log.debug("接口映射边: {} -> {} (接口: {})", implEdge.getCallerClass(), impl, edge.getCalleeClass());
                }
            }
        }

        log.info("========== ApiImpactAnalyzer初始化 ==========");
        log.info("输入数据: 调用边 {} 条, API {} 个, 变更方法 {} 个",
                callEdges.size(), apis.size(), changedMethods.size());
        log.info("调用图索引完成: {} 个被调用者", callGraphByCallee.size());
        log.info("接口映射统计: {} 个接口有实现类", interfaceToImpl.size());

        // 显示调用图样例（前5个）
        int sampleCount = 0;
        for (Map.Entry<String, List<MethodCallEdge>> entry : callGraphByCallee.entrySet()) {
            if (sampleCount++ < 5) {
                String calleeSimpleName = entry.getKey().substring(entry.getKey().lastIndexOf('.') + 1);
                log.info("  被调用者 #{}: {} (有 {} 个调用者)",
                        sampleCount, calleeSimpleName, entry.getValue().size());
            }
        }
    }

    /**
     * 分析API变更
     */
    public List<ApiChangeModel> analyze() {
        log.info("========== 开始API影响追溯分析 ==========");

        List<ApiChangeModel> apiChanges = new ArrayList<>();

        // 1. 识别新增和删除的API
        apiChanges.addAll(detectNewAndDeletedApis());

        // 2. 识别受影响的API（通过调用链追溯）
        apiChanges.addAll(traceAffectedApis());

        log.info("API影响追溯分析完成: 共 {} 个API变更", apiChanges.size());
        return apiChanges;
    }

    /**
     * 检测新增和删除的API
     */
    private List<ApiChangeModel> detectNewAndDeletedApis() {
        List<ApiChangeModel> changes = new ArrayList<>();

        // 获取所有变更方法中的Controller方法
        Set<String> apiMethods = apis.stream()
                .map(api -> api.getControllerClass() + "#" + api.getMethodName())
                .collect(Collectors.toSet());

        for (String changedMethod : changedMethods) {
            if (apiMethods.contains(changedMethod)) {
                // 变更的方法是Controller方法
                ApiInfo api = apis.stream()
                        .filter(a -> (a.getControllerClass() + "#" + a.getMethodName()).equals(changedMethod))
                        .findFirst()
                        .orElse(null);

                if (api != null) {
                    ApiChangeModel change = new ApiChangeModel();
                    change.setApiUrl(api.getUrl());
                    change.setHttpMethod(api.getHttpMethod());
                    change.setControllerClass(api.getControllerClass());
                    change.setMethodName(api.getMethodName());
                    change.setParameters(api.getParameters());
                    change.setFramework(api.getFramework());
                    change.setChangeType("MODIFIED_API");
                    change.setChangeReason("API端点方法存在变更");

                    // 构建调用链
                    List<ApiChangeModel.CallChainNode> chain = new ArrayList<>();
                    chain.add(new ApiChangeModel.CallChainNode(api.getControllerClass(), api.getMethodName(), 0));
                    change.setCallChain(chain);

                    changes.add(change);
                }
            }
        }

        return changes;
    }

    /**
     * 追溯受影响的API
     */
    private List<ApiChangeModel> traceAffectedApis() {
        List<ApiChangeModel> affectedApis = new ArrayList<>();

        for (String changedMethod : changedMethods) {
            // 每个变更方法使用独立的追溯集合，避免跨路径污染
            Set<String> tracedMethods = new HashSet<>();

            // 从变更方法出发，反向追溯所有调用者
            List<TraceResult> traceResults = traceCallers(changedMethod, new ArrayList<>(), 0, tracedMethods);

            for (TraceResult result : traceResults) {
                // 检查追溯结果是否到达了Controller
                ApiInfo api = findApiByControllerMethod(result.methodClass, result.methodName);
                if (api != null) {
                    // 找到了受影响的API
                    ApiChangeModel change = createAffectedApiChange(api, changedMethod, result.callChain);
                    affectedApis.add(change);

                    log.info("  ✓ 追溯到受影响API: {} {} - 调用链长度: {}",
                            api.getHttpMethod(), api.getUrl(), result.callChain.size() + 1);
                }
            }
        }

        // 去重（同一个API可能被多个变更方法影响）
        return deduplicateApiChanges(affectedApis);
    }

    /**
     * 反向追溯调用者
     */
    private List<TraceResult> traceCallers(String methodKey,
                                            List<ApiChangeModel.CallChainNode> currentChain,
                                            int depth,
                                            Set<String> tracedMethods) {
        List<TraceResult> results = new ArrayList<>();

        // 深度限制
        if (depth >= MAX_TRACE_DEPTH) {
            return results;
        }

        // 避免循环
        if (tracedMethods.contains(methodKey)) {
            return results;
        }
        tracedMethods.add(methodKey);

        // 创建新的调用链副本，添加当前方法
        List<ApiChangeModel.CallChainNode> workChain = new ArrayList<>(currentChain);
        String[] parts = methodKey.split("#");
        if (parts.length >= 2) {
            workChain.add(new ApiChangeModel.CallChainNode(parts[0], parts[1], depth));
            log.debug("调用链添加方法: {}.{} (depth={})", parts[0], parts[1], depth);
        }

        // 查找调用者
        List<MethodCallEdge> callers = callGraphByCallee.get(methodKey);
        if (callers == null || callers.isEmpty()) {
            // 没有更多调用者，到达终点，记录这条链路
            TraceResult result = new TraceResult();
            String[] methodParts = methodKey.split("#");
            if (methodParts.length >= 2) {
                result.methodClass = methodParts[0];
                result.methodName = methodParts[1];
                result.callChain = workChain;
                results.add(result);
            }
            return results;
        }

        log.info("  方法 {} 找到 {} 个调用者", methodKey.substring(methodKey.lastIndexOf('.') + 1), callers.size());

        for (MethodCallEdge caller : callers) {
            String callerKey = caller.getCallerClass() + "#" + caller.getCallerMethod();

            // 继续向上追溯，传入包含当前方法的chain
            results.addAll(traceCallers(callerKey, workChain, depth + 1, tracedMethods));
        }

        return results;
    }

    /**
     * 根据Controller类和方法查找API
     * 支持接口映射：如果className是实现类，会尝试匹配接口上定义的API
     */
    private ApiInfo findApiByControllerMethod(String className, String methodName) {
        // 1. 直接匹配
        for (ApiInfo api : apis) {
            if (api.getControllerClass().equals(className) && api.getMethodName().equals(methodName)) {
                return api;
            }
        }

        // 2. 接口映射匹配（支持CXF等接口模式的RESTful API）
        Set<String> interfaces = interfaceMapper.findInterfaces(className);
        if (interfaces != null) {
            for (String interfaceName : interfaces) {
                for (ApiInfo api : apis) {
                    if (api.getControllerClass().equals(interfaceName) && api.getMethodName().equals(methodName)) {
                        log.debug("API匹配成功（通过接口映射）: {} -> {}", className, interfaceName);
                        return api;
                    }
                }
            }
        }

        // 3. 类名格式兼容匹配（处理简单名与完整名不一致的情况）
        String simpleClassName = className.substring(className.lastIndexOf('.') + 1);
        for (ApiInfo api : apis) {
            String apiSimpleClassName = api.getControllerClass().substring(api.getControllerClass().lastIndexOf('.') + 1);
            if (apiSimpleClassName.equals(simpleClassName) && api.getMethodName().equals(methodName)) {
                log.warn("API匹配成功（通过简单类名匹配，存在格式不一致）: {} <-> {}", className, api.getControllerClass());
                return api;
            }
        }

        return null;
    }

    /**
     * 创建受影响API的变更模型
     */
    private ApiChangeModel createAffectedApiChange(ApiInfo api, String changedMethod,
                                                    List<ApiChangeModel.CallChainNode> callChain) {
        ApiChangeModel change = new ApiChangeModel();
        change.setApiUrl(api.getUrl());
        change.setHttpMethod(api.getHttpMethod());
        change.setControllerClass(api.getControllerClass());
        change.setMethodName(api.getMethodName());
        change.setParameters(api.getParameters());
        change.setFramework(api.getFramework());
        change.setChangeType("AFFECTED_API");

        // 解析变更方法
        String[] parts = changedMethod.split("#");
        String changedClass = parts.length > 0 ? parts[0] : "";
        String changedMethodName = parts.length > 1 ? parts[1] : "";
        change.setChangeReason("下游方法 " + changedClass + "." + changedMethodName + " 存在变更");

        // callChain已经包含从changedMethod到API的完整链路
        // 需要反转（从API到changedMethod）
        List<ApiChangeModel.CallChainNode> reversedChain = new ArrayList<>();

        // 从后往前遍历，实现反转
        for (int i = callChain.size() - 1; i >= 0; i--) {
            ApiChangeModel.CallChainNode node = callChain.get(i);
            reversedChain.add(new ApiChangeModel.CallChainNode(node.getClassName(), node.getMethodName(), reversedChain.size()));
        }

        change.setCallChain(reversedChain);

        log.debug("调用链构建完成: {} -> {} (长度={})", api.getUrl(), changedMethod, reversedChain.size());

        return change;
    }

    /**
     * 去重API变更，优先级：NEW_API/DELETED_API > MODIFIED_API > AFFECTED_API
     */
    private List<ApiChangeModel> deduplicateApiChanges(List<ApiChangeModel> changes) {
        Map<String, ApiChangeModel> uniqueChanges = new LinkedHashMap<>();

        for (ApiChangeModel change : changes) {
            String apiKey = change.getApiKey();
            String changeType = change.getChangeType();

            ApiChangeModel existing = uniqueChanges.get(apiKey);

            if (existing == null) {
                // 第一次遇到该 API
                uniqueChanges.put(apiKey, change);
            } else {
                // 已存在，根据优先级决定是否替换
                String existingType = existing.getChangeType();

                // 优先级判断
                if (shouldReplaceChangeType(existingType, changeType)) {
                    // 新的变更类型优先级更高，替换
                    uniqueChanges.put(apiKey, change);
                    log.info("API {} 变更类型升级: {} -> {}", apiKey, existingType, changeType);
                } else if (existingType.equals(changeType)) {
                    // 相同变更类型，合并调用链
                    existing.getCallChain().addAll(change.getCallChain());
                    log.info("API {} 合并调用链", apiKey);
                } else {
                    // 旧的变更类型优先级更高，保留旧的，丢弃新的
                    log.info("API {} 保留高优先级变更类型: {} (丢弃: {})", apiKey, existingType, changeType);
                }
            }
        }

        return new ArrayList<>(uniqueChanges.values());
    }

    /**
     * 判断是否应该替换变更类型
     * 优先级：NEW_API/DELETED_API (优先级最高) > MODIFIED_API > AFFECTED_API
     */
    private boolean shouldReplaceChangeType(String existingType, String newType) {
        int existingPriority = getChangeTypePriority(existingType);
        int newPriority = getChangeTypePriority(newType);

        return newPriority > existingPriority;
    }

    /**
     * 获取变更类型优先级（数值越大优先级越高）
     */
    private int getChangeTypePriority(String changeType) {
        if ("NEW_API".equals(changeType) || "DELETED_API".equals(changeType)) {
            return 3; // 最高优先级
        } else if ("MODIFIED_API".equals(changeType)) {
            return 2;
        } else if ("AFFECTED_API".equals(changeType)) {
            return 1; // 最低优先级
        }
        return 0;
    }

    /**
     * 追溯结果内部类
     */
    private static class TraceResult {
        String methodClass;
        String methodName;
        List<ApiChangeModel.CallChainNode> callChain;
    }
}