package org.example.securityplatform.analyzer.api;

import lombok.extern.slf4j.Slf4j;
import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

/**
 * 基于ASM的字节码API提取器
 * 用于从编译后的.class文件中提取Spring MVC和JAX-RS的API信息
 * 支持 Java EE (javax.ws.rs.*) 和 Jakarta EE 9+ (jakarta.ws.rs.*) 两套注解
 */
@Slf4j
public class BytecodeApiExtractor {

    private static final String SPRING_REQUEST_MAPPING = "Lorg/springframework/web/bind/annotation/RequestMapping;";
    private static final String SPRING_GET_MAPPING = "Lorg/springframework/web/bind/annotation/GetMapping;";
    private static final String SPRING_POST_MAPPING = "Lorg/springframework/web/bind/annotation/PostMapping;";
    private static final String SPRING_PUT_MAPPING = "Lorg/springframework/web/bind/annotation/PutMapping;";
    private static final String SPRING_DELETE_MAPPING = "Lorg/springframework/web/bind/annotation/DeleteMapping;";
    private static final String SPRING_PATCH_MAPPING = "Lorg/springframework/web/bind/annotation/PatchMapping;";

    private static final String JAX_RS_PATH = "Ljavax/ws/rs/Path;";
    private static final String JAX_RS_GET = "Ljavax/ws/rs/GET;";
    private static final String JAX_RS_POST = "Ljavax/ws/rs/POST;";
    private static final String JAX_RS_PUT = "Ljavax/ws/rs/PUT;";
    private static final String JAX_RS_DELETE = "Ljavax/ws/rs/DELETE;";

    // Jakarta EE 9+ JAX-RS 注解
    private static final String JAKARTA_JAX_RS_PATH = "Ljakarta/ws/rs/Path;";
    private static final String JAKARTA_JAX_RS_GET = "Ljakarta/ws/rs/GET;";
    private static final String JAKARTA_JAX_RS_POST = "Ljakarta/ws/rs/POST;";
    private static final String JAKARTA_JAX_RS_PUT = "Ljakarta/ws/rs/PUT;";
    private static final String JAKARTA_JAX_RS_DELETE = "Ljakarta/ws/rs/DELETE;";

    /**
     * 检查是否为 Path 注解（支持 javax 和 jakarta 两个版本）
     */
    private static boolean isPathAnnotation(String descriptor) {
        return JAX_RS_PATH.equals(descriptor) || JAKARTA_JAX_RS_PATH.equals(descriptor);
    }

    /**
     * 检查是否为 HTTP 方法注解（支持 javax 和 jakarta 两个版本）
     * @return HTTP 方法名称（GET, POST, PUT, DELETE），如果不是则返回 null
     */
    private static String checkHttpMethodAnnotation(String descriptor) {
        if (JAX_RS_GET.equals(descriptor) || JAKARTA_JAX_RS_GET.equals(descriptor)) {
            return "GET";
        } else if (JAX_RS_POST.equals(descriptor) || JAKARTA_JAX_RS_POST.equals(descriptor)) {
            return "POST";
        } else if (JAX_RS_PUT.equals(descriptor) || JAKARTA_JAX_RS_PUT.equals(descriptor)) {
            return "PUT";
        } else if (JAX_RS_DELETE.equals(descriptor) || JAKARTA_JAX_RS_DELETE.equals(descriptor)) {
            return "DELETE";
        }
        return null;
    }

    /**
     * 从.class文件中提取API信息
     */
    public List<ApiModel> extractFromClassFile(String classFilePath) {
        List<ApiModel> apis = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(classFilePath)) {
            ClassReader reader = new ClassReader(fis);
            ApiClassVisitor visitor = new ApiClassVisitor(apis);
            reader.accept(visitor, 0);
        } catch (IOException e) {
            log.error("解析class文件失败: {}", classFilePath, e);
        }

        return apis;
    }

    /**
     * ASM ClassVisitor - 访问类信息
     */
    private static class ApiClassVisitor extends ClassVisitor {
        private final List<ApiModel> apis;
        private String className;
        private String classLevelPath = "";

        public ApiClassVisitor(List<ApiModel> apis) {
            super(Opcodes.ASM9);
            this.apis = apis;
        }

        @Override
        public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
            // 将内部类名转换为标准类名 (org/example/Test -> org.example.Test)
            this.className = name.replace('/', '.');

            // 判断是否为interface类型
            boolean isInterface = (access & Opcodes.ACC_INTERFACE) != 0;

            // 记录扫描到的类类型和接口信息
            log.debug("扫描到 {}: {}, implements={}",
                     isInterface ? "interface" : "class", this.className,
                     interfaces != null && interfaces.length > 0 ? Arrays.toString(interfaces) : "无");

            super.visit(version, access, name, signature, superName, interfaces);
        }

        @Override
        public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
            // 记录检测到的类级别注解
            log.debug("类 {} 检测到注解: {}", className, descriptor);

            // 检查类级别的@RequestMapping或@Path注解
            if (SPRING_REQUEST_MAPPING.equals(descriptor)) {
                log.debug("类 {} 识别为Spring MVC控制器，提取@RequestMapping", className);
                return new SpringRequestMappingVisitor(value -> classLevelPath = value, null);
            } else if (isPathAnnotation(descriptor)) {
                log.debug("类 {} 识别为JAX-RS资源，提取@Path注解", className);
                return new JaxRsPathVisitor(value -> classLevelPath = value);
            }
            return super.visitAnnotation(descriptor, visible);
        }

        @Override
        public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
            // 过滤构造方法和静态初始化块
            if ("<init>".equals(name) || "<clinit>".equals(name)) {
                log.debug("跳过构造方法/静态初始化块: {}.{}", className, name);
                return null;  // 返回null表示不访问该方法
            }

            return new ApiMethodVisitor(apis, className, classLevelPath, name, descriptor);
        }
    }

    /**
     * ASM MethodVisitor - 访问方法信息并提取API
     */
    private static class ApiMethodVisitor extends MethodVisitor {
        private final List<ApiModel> apis;
        private final String className;
        private final String classLevelPath;
        private final String methodName;
        private final String methodDescriptor;

        // 临时存储方法上的注解信息
        private String currentHttpMethod;
        private String currentPath;
        private String framework;

        public ApiMethodVisitor(List<ApiModel> apis, String className, String classLevelPath,
                               String methodName, String methodDescriptor) {
            super(Opcodes.ASM9);
            this.apis = apis;
            this.className = className;
            this.classLevelPath = classLevelPath;
            this.methodName = methodName;
            this.methodDescriptor = methodDescriptor;
        }

        @Override
        public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
            // Spring MVC 注解
            if (SPRING_GET_MAPPING.equals(descriptor)) {
                currentHttpMethod = "GET";
                framework = "SPRING_MVC";
                return new SpringRequestMappingVisitor(value -> currentPath = value, null);
            } else if (SPRING_POST_MAPPING.equals(descriptor)) {
                currentHttpMethod = "POST";
                framework = "SPRING_MVC";
                return new SpringRequestMappingVisitor(value -> currentPath = value, null);
            } else if (SPRING_PUT_MAPPING.equals(descriptor)) {
                currentHttpMethod = "PUT";
                framework = "SPRING_MVC";
                return new SpringRequestMappingVisitor(value -> currentPath = value, null);
            } else if (SPRING_DELETE_MAPPING.equals(descriptor)) {
                currentHttpMethod = "DELETE";
                framework = "SPRING_MVC";
                return new SpringRequestMappingVisitor(value -> currentPath = value, null);
            } else if (SPRING_PATCH_MAPPING.equals(descriptor)) {
                currentHttpMethod = "PATCH";
                framework = "SPRING_MVC";
                return new SpringRequestMappingVisitor(value -> currentPath = value, null);
            } else if (SPRING_REQUEST_MAPPING.equals(descriptor)) {
                framework = "SPRING_MVC";
                return new SpringRequestMappingVisitor(path -> currentPath = path, method -> currentHttpMethod = method);
            }
            // JAX-RS 注解（支持 javax 和 jakarta 版本）
            String httpMethod = checkHttpMethodAnnotation(descriptor);
            if (httpMethod != null) {
                currentHttpMethod = httpMethod;
                framework = "JAX_RS";
            } else if (isPathAnnotation(descriptor)) {
                return new JaxRsPathVisitor(value -> currentPath = value);
            }

            return super.visitAnnotation(descriptor, visible);
        }

        @Override
        public void visitEnd() {
            // 放宽API识别规则：只要有JAX-RS或Spring MVC相关注解就认为是API

            // 情况1：有HTTP方法但缺少路径 - 使用空路径或类级别路径
            if (currentHttpMethod != null && currentPath == null) {
                currentPath = classLevelPath.isEmpty() ? "" : classLevelPath;
                log.debug("方法 {}.{} 有HTTP方法 {} 但缺少方法级@Path，使用路径: {}",
                         className, methodName, currentHttpMethod, currentPath);
            }

            // 情况2：有路径但缺少HTTP方法 - 默认使用GET
            if (currentHttpMethod == null && (currentPath != null || !classLevelPath.isEmpty())) {
                currentHttpMethod = "GET";
                framework = framework != null ? framework : "JAX_RS";
                log.debug("方法 {}.{} 有路径 {} 但缺少HTTP方法注解，默认使用GET",
                         className, methodName,
                         currentPath != null ? currentPath : classLevelPath);
            }

            // 只要识别到了HTTP方法，就创建API（不再要求必须有路径）
            if (currentHttpMethod != null) {
                String fullPath = classLevelPath;
                if (currentPath != null) {
                    fullPath = classLevelPath + currentPath;
                }
                fullPath = fullPath.replace("//", "/");

                // 如果路径为空，使用默认路径
                if (fullPath.isEmpty()) {
                    fullPath = "/" + className.substring(className.lastIndexOf('.') + 1).toLowerCase();
                    log.debug("方法 {}.{} 缺少路径，使用默认路径: {}", className, methodName, fullPath);
                }

                ApiModel api = new ApiModel();
                api.setUrl(fullPath);
                api.setHttpMethod(currentHttpMethod);
                api.setControllerClass(className);
                api.setMethodName(methodName);
                api.setFramework(framework);
                api.setParameters(extractParameters(methodDescriptor));

                apis.add(api);
                log.debug("成功创建API: {} {} -> {}.{}", currentHttpMethod, fullPath, className, methodName);
            } else {
                // 未检测到任何API相关注解
                log.debug("方法 {}.{} 未检测到任何API注解（无HTTP方法、无@Path）", className, methodName);
            }

            super.visitEnd();
        }

        /**
         * 从方法描述符中提取参数信息
         */
        private String extractParameters(String descriptor) {
            if (descriptor == null || descriptor.isEmpty()) {
                return "";
            }

            try {
                Type[] argumentTypes = Type.getArgumentTypes(descriptor);
                StringBuilder params = new StringBuilder();
                for (Type type : argumentTypes) {
                    if (params.length() > 0) {
                        params.append(", ");
                    }
                    params.append(type.getClassName());
                }
                return params.toString();
            } catch (Exception e) {
                return "";
            }
        }
    }

    /**
     * Spring @RequestMapping 注解访问器
     */
    private static class SpringRequestMappingVisitor extends AnnotationVisitor {
        private final Consumer<String> pathCallback;
        private final Consumer<String> methodCallback;

        public SpringRequestMappingVisitor(Consumer<String> pathCallback, Consumer<String> methodCallback) {
            super(Opcodes.ASM9);
            this.pathCallback = pathCallback;
            this.methodCallback = methodCallback;
        }

        @Override
        public void visit(String name, Object value) {
            if ("value".equals(name) || "path".equals(name)) {
                if (pathCallback != null) {
                    pathCallback.accept(value.toString());
                }
            } else if ("method".equals(name) && methodCallback != null) {
                // RequestMethod通常是一个数组，这里简化处理
                String methodStr = value.toString();
                if (methodStr.contains("GET")) methodCallback.accept("GET");
                else if (methodStr.contains("POST")) methodCallback.accept("POST");
                else if (methodStr.contains("PUT")) methodCallback.accept("PUT");
                else if (methodStr.contains("DELETE")) methodCallback.accept("DELETE");
                else if (methodStr.contains("PATCH")) methodCallback.accept("PATCH");
            }
            super.visit(name, value);
        }

        @Override
        public AnnotationVisitor visitArray(String name) {
            if (("value".equals(name) || "path".equals(name)) && pathCallback != null) {
                return new AnnotationArrayVisitor(pathCallback);
            } else if ("method".equals(name) && methodCallback != null) {
                return new AnnotationArrayVisitor(item -> {
                    if (item.contains("GET")) methodCallback.accept("GET");
                    else if (item.contains("POST")) methodCallback.accept("POST");
                    else if (item.contains("PUT")) methodCallback.accept("PUT");
                    else if (item.contains("DELETE")) methodCallback.accept("DELETE");
                    else if (item.contains("PATCH")) methodCallback.accept("PATCH");
                });
            }
            return super.visitArray(name);
        }
    }

    /**
     * JAX-RS @Path 注解访问器
     */
    private static class JaxRsPathVisitor extends AnnotationVisitor {
        private final Consumer<String> callback;

        public JaxRsPathVisitor(Consumer<String> callback) {
            super(Opcodes.ASM9);
            this.callback = callback;
        }

        @Override
        public void visit(String name, Object value) {
            if ("value".equals(name) && callback != null) {
                callback.accept(value.toString());
            }
            super.visit(name, value);
        }
    }

    /**
     * 注解数组访问器
     */
    private static class AnnotationArrayVisitor extends AnnotationVisitor {
        private final Consumer<String> callback;

        public AnnotationArrayVisitor(Consumer<String> callback) {
            super(Opcodes.ASM9);
            this.callback = callback;
        }

        @Override
        public void visit(String name, Object value) {
            if (callback != null) {
                callback.accept(value.toString());
            }
            super.visit(name, value);
        }
    }
}
