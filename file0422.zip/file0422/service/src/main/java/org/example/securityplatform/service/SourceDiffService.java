package org.example.securityplatform.service;

import lombok.extern.slf4j.Slf4j;
import org.benf.cfr.reader.api.CfrDriver;
import org.benf.cfr.reader.api.OutputSinkFactory;
import org.example.securityplatform.analyzer.diff.FileDiffModel;
import org.example.securityplatform.analyzer.jar.JarInfo;
import org.example.securityplatform.dto.FileSourceDiff;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 源代码差异服务 - 使用CFR反编译器将.class文件转为Java源码
 */
@Slf4j
@Service
public class SourceDiffService {

    /**
     * 反编译变更的class文件
     */
    public List<FileSourceDiff> decompileChangedFiles(
            List<FileDiffModel> fileDiffs,
            String baselinePath,
            String targetPath,
            List<JarInfo> baselineJars,
            List<JarInfo> targetJars) {

        log.info("开始源码反编译，共 {} 个变更文件", fileDiffs.size());
        long startTime = System.currentTimeMillis();

        List<FileSourceDiff> sourceDiffs = new ArrayList<>();
        int successCount = 0;
        int failCount = 0;
        int total = fileDiffs.size();

        for (int i = 0; i < fileDiffs.size(); i++) {
            FileDiffModel diff = fileDiffs.get(i);

            // 进度日志（每10%输出一次）
            if (total > 10 && (i % (total / 10) == 0)) {
                log.info("反编译进度: {}/{} ({} 个成功, {} 个失败)",
                        i, total, successCount, failCount);
            }

            try {
                String baselineSource = null;
                String targetSource = null;

                boolean isMultiJar = baselineJars != null && !baselineJars.isEmpty();

                // 判断文件类型：资源文件或字节码文件
                boolean isResourceFile = isResourceFile(diff);

                switch (diff.getDiffType()) {
                    case "ADDED":
                        if (isResourceFile) {
                            targetSource = extractTextContentForSide(diff.getFilePath(), targetPath, targetJars, isMultiJar);
                        } else {
                            targetSource = decompileForSide(diff.getFilePath(), targetPath, targetJars, isMultiJar);
                        }
                        break;
                    case "DELETED":
                        if (isResourceFile) {
                            baselineSource = extractTextContentForSide(diff.getFilePath(), baselinePath, baselineJars, isMultiJar);
                        } else {
                            baselineSource = decompileForSide(diff.getFilePath(), baselinePath, baselineJars, isMultiJar);
                        }
                        break;
                    case "MODIFIED":
                        if (isResourceFile) {
                            baselineSource = extractTextContentForSide(diff.getFilePath(), baselinePath, baselineJars, isMultiJar);
                            targetSource = extractTextContentForSide(diff.getFilePath(), targetPath, targetJars, isMultiJar);
                        } else {
                            baselineSource = decompileForSide(diff.getFilePath(), baselinePath, baselineJars, isMultiJar);
                            targetSource = decompileForSide(diff.getFilePath(), targetPath, targetJars, isMultiJar);
                        }
                        break;
                    default:
                        continue;
                }

                boolean hasResult = baselineSource != null || targetSource != null;
                String error = null;
                String actualDiffType = diff.getDiffType();
                String originalDiffType = diff.getDiffType();  // 保存原始差异类型
                boolean bytecodeDiffButSourceSame = false;     // 标记字节码差异但源码相同

                // Re-evaluate diffType based on decompiled source
                if ("MODIFIED".equals(diff.getDiffType()) && baselineSource != null && targetSource != null) {
                    if (baselineSource.equals(targetSource)) {
                        actualDiffType = "UNCHANGED";
                        bytecodeDiffButSourceSame = true;  // 标记为字节码差异但源码相同
                        log.debug("字节码差异但反编译后源码相同: {}", diff.getFilePath());
                    }
                }

                if (!hasResult && "MODIFIED".equals(diff.getDiffType())) {
                    error = "反编译未返回任何源码";
                }

                if (hasResult) {
                    successCount++;
                } else {
                    failCount++;
                }

                sourceDiffs.add(FileSourceDiff.builder()
                        .filePath(diff.getFilePath())
                        .sourceFilePath(diff.getSourceFilePath())
                        .diffType(actualDiffType)  // Use re-evaluated diffType
                        .originalDiffType(originalDiffType)  // 保存原始差异类型
                        .bytecodeDiffButSourceSame(bytecodeDiffButSourceSame)  // 标记字节码差异但源码相同
                        .baselineSource(baselineSource)
                        .targetSource(targetSource)
                        .error(error)
                        .sourceJar(diff.getSourceJar())
                        .jarType(diff.getJarType())
                        .build());

            } catch (Exception e) {
                log.warn("反编译处理失败: {} - {}", diff.getFilePath(), e.getMessage());
                sourceDiffs.add(FileSourceDiff.builder()
                        .filePath(diff.getFilePath())
                        .sourceFilePath(diff.getSourceFilePath())
                        .diffType(diff.getDiffType())
                        .error("反编译失败: " + e.getMessage())
                        .sourceJar(diff.getSourceJar())
                        .jarType(diff.getJarType())
                        .build());
                failCount++;
            }
        }

        long elapsed = System.currentTimeMillis() - startTime;
        log.info("源码反编译完成: 成功={}, 失败={}, 共={}, 耗时={}ms, 平均={}ms/文件",
                successCount, failCount, fileDiffs.size(), elapsed,
                fileDiffs.size() > 0 ? elapsed / fileDiffs.size() : 0);

        return sourceDiffs;
    }

    /**
     * 反编译指定端的class文件
     */
    private String decompileForSide(String classPath, String mainJarPath,
                                     List<JarInfo> jarInfos, boolean isMultiJar) {
        if (isMultiJar) {
            return decompileFromJars(classPath, jarInfos);
        } else {
            return decompileClassFromJar(mainJarPath, classPath);
        }
    }

    /**
     * 从多个JAR中查找并反编译
     */
    private String decompileFromJars(String classPath, List<JarInfo> jarInfos) {
        for (JarInfo jarInfo : jarInfos) {
            String result = decompileClassFromJar(jarInfo.getJarPath(), classPath);
            if (result != null) {
                return result;
            }
        }
        log.warn("在所有JAR中均未找到: {}", classPath);
        return null;
    }

    /**
     * 从JAR中提取class字节并反编译
     * 先提取字节到临时文件，再用CFR反编译，避免JAR路径格式问题
     */
    private String decompileClassFromJar(String jarPath, String classPath) {
        // 1. 在JAR中找到正确的条目名
        String entryName = resolveEntryName(jarPath, classPath);
        if (entryName == null) {
            return null;
        }

        // 2. 从JAR中提取class字节到临时文件
        Path tempFile = null;
        try {
            byte[] classBytes = extractClassBytes(jarPath, entryName);
            if (classBytes == null) {
                log.warn("无法提取class字节: {} from {}", entryName, jarPath);
                return null;
            }

            tempFile = Files.createTempFile("cfr-", ".class");
            Files.write(tempFile, classBytes);

            // 3. 用CFR反编译临时文件
            String source = decompileFile(tempFile.toString());
            return source;

        } catch (Exception e) {
            log.warn("反编译失败: {} in {} - {}", classPath, jarPath, e.getMessage());
            return null;
        } finally {
            if (tempFile != null) {
                try {
                    Files.deleteIfExists(tempFile);
                } catch (Exception ignored) {}
            }
        }
    }

    /**
     * 从JAR中提取class文件的字节
     */
    private byte[] extractClassBytes(String jarPath, String entryName) {
        try (JarFile jar = new JarFile(jarPath)) {
            JarEntry entry = jar.getJarEntry(entryName);
            if (entry == null) {
                return null;
            }
            try (InputStream is = jar.getInputStream(entry)) {
                return is.readAllBytes();
            }
        } catch (IOException e) {
            log.warn("读取JAR条目失败: {} in {} - {}", entryName, jarPath, e.getMessage());
            return null;
        }
    }

    /**
     * 用CFR反编译一个class文件
     */
    private String decompileFile(String classFilePath) {
        StringBuilder output = new StringBuilder();

        OutputSinkFactory sinkFactory = new OutputSinkFactory() {
            @Override
            public List<SinkClass> getSupportedSinks(SinkType sinkType, Collection<SinkClass> available) {
                return Collections.singletonList(SinkClass.STRING);
            }

            @Override
            public <T> Sink<T> getSink(SinkType sinkType, SinkClass sinkClass) {
                if (sinkType == SinkType.JAVA) {
                    return t -> output.append(t);
                }
                return t -> {};
            }
        };

        Map<String, String> options = new HashMap<>();
        options.put("showversion", "false");
        options.put("removeboilerplate", "true");
        options.put("decodestringswitch", "true");
        options.put("sugarenums", "true");
        options.put("decodelambdas", "true");
        options.put("aexagg", "false");

        CfrDriver driver = new CfrDriver.Builder()
                .withOutputSink(sinkFactory)
                .withOptions(options)
                .build();

        driver.analyse(Collections.singletonList(classFilePath));

        String source = output.toString().trim();
        if (source.isEmpty()) {
            return null;
        }
        return source;
    }

    /**
     * 在JAR中解析class条目的实际路径
     * 支持原始路径和规范化路径（BOOT-INF/classes前缀）
     */
    private String resolveEntryName(String jarPath, String classPath) {
        try (JarFile jar = new JarFile(jarPath)) {
            // 1. 尝试原始路径
            if (jar.getEntry(classPath) != null) {
                return classPath;
            }

            // 2. 尝试添加 BOOT-INF/classes 前缀
            String bootPath = "BOOT-INF/classes/" + classPath;
            if (jar.getEntry(bootPath) != null) {
                return bootPath;
            }

            // 3. 尝试添加 WEB-INF/classes 前缀
            String webPath = "WEB-INF/classes/" + classPath;
            if (jar.getEntry(webPath) != null) {
                return webPath;
            }

            // 4. 如果原始路径已有 BOOT-INF/classes 前缀，尝试去掉
            if (classPath.startsWith("BOOT-INF/classes/")) {
                String stripped = classPath.substring("BOOT-INF/classes/".length());
                if (jar.getEntry(stripped) != null) {
                    return stripped;
                }
            }

            // 5. 如果原始路径已有 WEB-INF/classes 前缀，尝试去掉
            if (classPath.startsWith("WEB-INF/classes/")) {
                String stripped = classPath.substring("WEB-INF/classes/".length());
                if (jar.getEntry(stripped) != null) {
                    return stripped;
                }
            }

            // 6. 模糊搜索：按文件名后缀匹配
            String suffix = classPath.contains("/")
                    ? classPath.substring(classPath.lastIndexOf('/'))
                    : classPath;
            Enumeration<JarEntry> entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (entry.getName().endsWith(suffix) && !entry.isDirectory()) {
                    return entry.getName();
                }
            }

            log.debug("在JAR中未找到条目: {} (tried raw, BOOT-INF, WEB-INF, fuzzy)", classPath);
            return null;

        } catch (IOException e) {
            log.warn("解析JAR条目失败: {} in {} - {}", classPath, jarPath, e.getMessage());
            return null;
        }
    }

    /**
     * 判断是否为资源文件
     *
     * @param diff 文件差异模型
     * @return true if 资源文件
     */
    private boolean isResourceFile(FileDiffModel diff) {
        // 方法1：使用fileType字段
        if (diff.getFileType() != null) {
            return "RESOURCE".equals(diff.getFileType());
        }

        // 方法2：根据文件扩展名判断
        String filePath = diff.getFilePath();
        if (filePath == null) {
            return false;
        }

        String extension = getFileExtension(filePath);
        Set<String> resourceExtensions = Set.of(
            "xml", "properties", "yml", "yaml", "json", "sql",
            "html", "css", "js", "ts", "txt", "md", "csv"
        );

        return resourceExtensions.contains(extension);
    }

    /**
     * 获取文件扩展名（不含点）
     *
     * @param filePath 文件路径
     * @return 扩展名（小写）
     */
    private String getFileExtension(String filePath) {
        if (filePath == null || filePath.isEmpty()) {
            return "";
        }
        int lastDot = filePath.lastIndexOf('.');
        if (lastDot == -1 || lastDot == filePath.length() - 1) {
            return "";
        }
        return filePath.substring(lastDot + 1).toLowerCase();
    }

    /**
     * 判断是否为二进制文件（不应提取文本）
     *
     * @param filePath 文件路径
     * @return true if 二进制文件
     */
    private boolean isBinaryFile(String filePath) {
        Set<String> binaryExtensions = Set.of(
            "png", "jpg", "jpeg", "gif", "bmp", "ico",
            "pdf", "doc", "docx", "xls", "xlsx",
            "zip", "tar", "gz", "rar",
            "ttf", "woff", "woff2", "eot",
            "class", "jar", "war"  // class/jar/war 本身也是二进制
        );
        return binaryExtensions.contains(getFileExtension(filePath));
    }

    /**
     * 从InputStream读取文本内容（UTF-8编码）
     *
     * @param inputStream 输入流
     * @return 文本内容
     * @throws IOException IO异常
     */
    private String readTextContent(InputStream inputStream) throws IOException {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
            return content.toString();
        }
    }

    /**
     * 提取资源文件的文本内容（指定端）
     *
     * @param filePath 资源文件路径
     * @param mainJarPath 主JAR路径
     * @param jarInfos JAR信息列表（多JAR模式）
     * @param isMultiJar 是否多JAR模式
     * @return 文本内容
     */
    private String extractTextContentForSide(String filePath, String mainJarPath,
                                               List<JarInfo> jarInfos, boolean isMultiJar) {
        if (isMultiJar) {
            return extractTextFromJars(filePath, jarInfos);
        } else {
            return extractTextFromJar(mainJarPath, filePath);
        }
    }

    /**
     * 从多个JAR中查找并提取资源文件文本内容
     *
     * @param filePath 资源文件路径
     * @param jarInfos JAR信息列表
     * @return 文本内容
     */
    private String extractTextFromJars(String filePath, List<JarInfo> jarInfos) {
        for (JarInfo jarInfo : jarInfos) {
            String result = extractTextFromJar(jarInfo.getJarPath(), filePath);
            if (result != null) {
                return result;
            }
        }
        log.warn("在所有JAR中均未找到资源文件: {}", filePath);
        return null;
    }

    /**
     * 从JAR中提取资源文件的文本内容
     *
     * @param jarPath JAR路径
     * @param filePath 资源文件路径
     * @return 文本内容
     */
    private String extractTextFromJar(String jarPath, String filePath) {
        // 检查是否为二进制文件
        if (isBinaryFile(filePath)) {
            log.debug("跳过二进制资源文件: {}", filePath);
            return null;
        }

        try (JarFile jar = new JarFile(jarPath)) {
            // 解析条目名称（复用resolveEntryName逻辑）
            String entryName = resolveEntryName(jarPath, filePath);
            if (entryName == null) {
                return null;
            }

            JarEntry entry = jar.getJarEntry(entryName);
            if (entry == null) {
                return null;
            }

            // 检查文件大小（限制1MB）
            long size = entry.getSize();
            if (size > 1024 * 1024) {
                log.warn("资源文件过大，跳过提取: {} (size={} bytes)", filePath, size);
                return null;
            }

            // 读取文本内容
            try (InputStream is = jar.getInputStream(entry)) {
                return readTextContent(is);
            }

        } catch (IOException e) {
            log.warn("读取资源文件失败: {} in {} - {}", filePath, jarPath, e.getMessage());
            return null;
        }
    }
}
