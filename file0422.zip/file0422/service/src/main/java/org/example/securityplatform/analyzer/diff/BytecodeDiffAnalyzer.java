package org.example.securityplatform.analyzer.diff;

import lombok.extern.slf4j.Slf4j;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

/**
 * 字节码差异分析器 - 对比两个class文件的字节码差异
 */
@Slf4j
public class BytecodeDiffAnalyzer {

    /**
     * 分析两个字节码文件的差异
     *
     * @param baselineStream 基线版本的字节码输入流
     * @param targetStream   目标版本的字节码输入流
     * @param filePath       文件路径（用于日志）
     * @return 字节码差异结果
     */
    public BytecodeDiffResult analyze(InputStream baselineStream, InputStream targetStream, String filePath) {
        BytecodeDiffResult result = new BytecodeDiffResult();
        result.setFilePath(filePath);

        // 初始化默认值
        result.setMethodsAdded(0);
        result.setMethodsDeleted(0);
        result.setMethodsModified(0);
        result.setBaselineInstructions(0);
        result.setTargetInstructions(0);

        try {
            // 提取基线版本的方法信息
            Map<String, MethodInfo> baselineMethods = new HashMap<>();
            try {
                baselineMethods = extractMethods(baselineStream);
            } catch (Exception e) {
                log.debug("解析基线版本失败，跳过: {} - {}", filePath, e.getMessage());
            }

            // 提取目标版本的方法信息
            Map<String, MethodInfo> targetMethods = new HashMap<>();
            try {
                targetMethods = extractMethods(targetStream);
            } catch (Exception e) {
                log.debug("解析目标版本失败，跳过: {} - {}", filePath, e.getMessage());
            }

            // 如果两个都解析失败，直接返回
            if (baselineMethods.isEmpty() && targetMethods.isEmpty()) {
                result.setHasDiff(false);
                return result;
            }

            // 对比方法差异
            List<MethodChangeModel> methodChanges = new ArrayList<>();
            int methodsAdded = 0;
            int methodsDeleted = 0;
            int methodsModified = 0;

            // 查找新增和修改的方法
            for (Map.Entry<String, MethodInfo> entry : targetMethods.entrySet()) {
                String methodKey = entry.getKey();
                MethodInfo targetMethod = entry.getValue();

                if (!baselineMethods.containsKey(methodKey)) {
                    // 新增方法
                    MethodChangeModel change = new MethodChangeModel();
                    change.setMethodName(targetMethod.methodName);
                    change.setDescriptor(targetMethod.descriptor);
                    change.setAccess(targetMethod.access);
                    change.setChangeType("ADDED");
                    change.setTargetInstructions(targetMethod.instructionCount);
                    methodChanges.add(change);
                    methodsAdded++;
                } else {
                    // 检查是否修改
                    MethodInfo baselineMethod = baselineMethods.get(methodKey);
                    if (baselineMethod.instructionCount != targetMethod.instructionCount ||
                        !Objects.equals(baselineMethod.codeHash, targetMethod.codeHash)) {
                        // 方法修改
                        MethodChangeModel change = new MethodChangeModel();
                        change.setMethodName(targetMethod.methodName);
                        change.setDescriptor(targetMethod.descriptor);
                        change.setAccess(targetMethod.access);
                        change.setChangeType("MODIFIED");
                        change.setBaselineInstructions(baselineMethod.instructionCount);
                        change.setTargetInstructions(targetMethod.instructionCount);
                        methodChanges.add(change);
                        methodsModified++;
                    }
                }
            }

            // 查找删除的方法
            for (Map.Entry<String, MethodInfo> entry : baselineMethods.entrySet()) {
                String methodKey = entry.getKey();
                if (!targetMethods.containsKey(methodKey)) {
                    MethodInfo baselineMethod = entry.getValue();
                    MethodChangeModel change = new MethodChangeModel();
                    change.setMethodName(baselineMethod.methodName);
                    change.setDescriptor(baselineMethod.descriptor);
                    change.setAccess(baselineMethod.access);
                    change.setChangeType("DELETED");
                    change.setBaselineInstructions(baselineMethod.instructionCount);
                    methodChanges.add(change);
                    methodsDeleted++;
                }
            }

            result.setMethodChanges(methodChanges);
            result.setMethodsAdded(methodsAdded);
            result.setMethodsDeleted(methodsDeleted);
            result.setMethodsModified(methodsModified);
            result.setHasDiff(methodsAdded > 0 || methodsDeleted > 0 || methodsModified > 0);

            // Calculate instruction statistics
            int totalBaselineInstructions = 0;
            int totalTargetInstructions = 0;
            int addedInstructionCount = 0;
            int deletedInstructionCount = 0;

            for (MethodChangeModel change : methodChanges) {
                switch (change.getChangeType()) {
                    case "ADDED":
                        totalTargetInstructions += change.getTargetInstructions();
                        addedInstructionCount += change.getTargetInstructions();
                        break;
                    case "DELETED":
                        totalBaselineInstructions += change.getBaselineInstructions();
                        deletedInstructionCount += change.getBaselineInstructions();
                        break;
                    case "MODIFIED":
                        int baseline = change.getBaselineInstructions();
                        int target = change.getTargetInstructions();
                        totalBaselineInstructions += baseline;
                        totalTargetInstructions += target;
                        // Calculate diff for modified methods
                        if (target > baseline) {
                            addedInstructionCount += (target - baseline);
                        } else if (baseline > target) {
                            deletedInstructionCount += (baseline - target);
                        }
                        break;
                }
            }

            result.setBaselineInstructions(totalBaselineInstructions);
            result.setTargetInstructions(totalTargetInstructions);
            result.setAddedInstructions(addedInstructionCount);
            result.setDeletedInstructions(deletedInstructionCount);

            log.debug("Bytecode diff for {}: baseline={} instr, target={} instr, added={} instr, deleted={} instr",
                    filePath, totalBaselineInstructions, totalTargetInstructions,
                    addedInstructionCount, deletedInstructionCount);

        } catch (Exception e) {
            log.warn("字节码差异分析失败: {}", filePath, e);
            result.setHasDiff(false);
        }

        return result;
    }

    /**
     * 提取class文件中的方法信息
     */
    private Map<String, MethodInfo> extractMethods(InputStream inputStream) throws IOException {
        Map<String, MethodInfo> methods = new HashMap<>();

        try {
            ClassReader classReader = new ClassReader(inputStream);
            ClassVisitor visitor = new ClassVisitor(Opcodes.ASM9) {
                @Override
                public MethodVisitor visitMethod(int access, String name, String descriptor,
                                                  String signature, String[] exceptions) {
                    MethodInfo info = new MethodInfo();
                    info.methodName = name;
                    info.descriptor = descriptor;
                    info.access = access;

                    return new MethodVisitor(Opcodes.ASM9) {
                        private int instructionCount = 0;
                        private final StringBuilder codeBuilder = new StringBuilder();

                        @Override
                        public void visitInsn(int opcode) {
                            instructionCount++;
                            codeBuilder.append(opcode).append(",");
                        }

                        @Override
                        public void visitIntInsn(int opcode, int operand) {
                            instructionCount++;
                            codeBuilder.append(opcode).append(":").append(operand).append(",");
                        }

                        @Override
                        public void visitVarInsn(int opcode, int var) {
                            instructionCount++;
                            codeBuilder.append(opcode).append(":").append(var).append(",");
                        }

                        @Override
                        public void visitMethodInsn(int opcode, String owner, String name,
                                                    String descriptor, boolean isInterface) {
                            instructionCount++;
                            codeBuilder.append(opcode).append(":")
                                       .append(owner).append(".").append(name).append(",");
                        }

                        // 新增：记录字段访问指令
                        @Override
                        public void visitFieldInsn(int opcode, String owner, String name, String descriptor) {
                            instructionCount++;
                            codeBuilder.append(opcode).append(":F:")
                                       .append(owner).append(".").append(name).append(",");
                        }

                        // 新增：记录常量加载指令
                        @Override
                        public void visitLdcInsn(Object value) {
                            instructionCount++;
                            codeBuilder.append("LDC").append(":")
                                       .append(value != null ? value.toString() : "null").append(",");
                        }

                        // 新增：记录类型指令
                        @Override
                        public void visitTypeInsn(int opcode, String type) {
                            instructionCount++;
                            codeBuilder.append(opcode).append(":T:")
                                       .append(type).append(",");
                        }

                        // 新增：记录跳转指令
                        @Override
                        public void visitJumpInsn(int opcode, org.objectweb.asm.Label label) {
                            instructionCount++;
                            codeBuilder.append(opcode).append(":JUMP,");
                        }

                        @Override
                        public void visitEnd() {
                            info.instructionCount = instructionCount;
                            // 使用SHA-256替代hashCode()，避免碰撞
                            try {
                                MessageDigest md = MessageDigest.getInstance("SHA-256");
                                byte[] digest = md.digest(codeBuilder.toString().getBytes(StandardCharsets.UTF_8));
                                StringBuilder sb = new StringBuilder();
                                for (byte b : digest) {
                                    sb.append(String.format("%02x", b));
                                }
                                info.codeHash = sb.toString();
                                log.debug("方法 {} 的SHA-256哈希: {}", name, info.codeHash);
                            } catch (NoSuchAlgorithmException e) {
                                // 降级使用hashCode（极端情况）
                                log.warn("SHA-256不可用，降级使用hashCode");
                                info.codeHash = String.valueOf(codeBuilder.toString().hashCode());
                            }
                            String key = name + descriptor;
                            methods.put(key, info);
                        }
                    };
                }
            };

            // 使用 SKIP_CODE 会导致无法统计指令，所以我们只跳过调试信息和帧
            // 对于 Lombok 生成的内部类，可能需要跳过父类验证
            classReader.accept(visitor, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
        } catch (IOException e) {
            // 对于 Lombok 生成的内部类（如 Builder），可能无法找到父类
            // 记录警告并返回空结果
            log.debug("无法解析类文件，可能是 Lombok 生成的内部类: {}", e.getMessage());
            throw e;
        }

        return methods;
    }

    /**
     * 方法信息内部类
     */
    private static class MethodInfo {
        String methodName;
        String descriptor;
        int access;
        int instructionCount;
        String codeHash;
    }
}