package org.example.securityplatform.analyzer.diff;

import lombok.extern.slf4j.Slf4j;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * Analyzer for non-Java resource files (config files, SQL scripts, XML, etc.)
 * Performs line count analysis using simplified strategy
 */
@Slf4j
public class ResourceFileDiffAnalyzer {

    /**
     * Analyze line counts for resource file diff
     * Uses SIMPLIFIED STRATEGY: no line-by-line diff
     *
     * @param baselineStream baseline version content (null if new file)
     * @param targetStream target version content (null if deleted file)
     * @param filePath file path being analyzed
     * @return ResourceDiffResult with line counts
     */
    public ResourceDiffResult analyze(InputStream baselineStream,
                                       InputStream targetStream,
                                       String filePath) {
        ResourceDiffResult result = new ResourceDiffResult();
        result.setFilePath(filePath);

        try {
            int baselineLines = 0;
            if (baselineStream != null) {
                baselineLines = countLines(baselineStream);
            }
            result.setBaselineLines(baselineLines);

            int targetLines = 0;
            if (targetStream != null) {
                targetLines = countLines(targetStream);
            }
            result.setTargetLines(targetLines);

            // SIMPLIFIED STRATEGY - no line-by-line diff
            if (baselineStream != null && targetStream != null) {
                result.setAddedLines(targetLines);
                result.setDeletedLines(baselineLines);
            } else if (baselineStream == null && targetStream != null) {
                result.setAddedLines(targetLines);
                result.setDeletedLines(0);
            } else if (baselineStream != null && targetStream == null) {
                result.setAddedLines(0);
                result.setDeletedLines(baselineLines);
            } else {
                result.setAddedLines(0);
                result.setDeletedLines(0);
            }

            log.debug("Resource file analysis complete: {}", filePath);
        } catch (IOException e) {
            log.warn("Failed to count lines: {}", filePath, e);
            result.setBaselineLines(0);
            result.setTargetLines(0);
            result.setAddedLines(0);
            result.setDeletedLines(0);
        }

        return result;
    }

    /**
     * Count total lines in a stream (UTF-8 encoding)
     */
    private int countLines(InputStream inputStream) throws IOException {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            int lines = 0;
            while (reader.readLine() != null) {
                lines++;
            }
            return lines;
        }
    }
}