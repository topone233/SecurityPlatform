package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * 快速差异对比响应
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QuickDiffResponse {

    /**
     * 文件差异摘要
     */
    private FileSummary fileSummary;

    /**
     * API变更摘要
     */
    private ApiDiffSummary apiSummary;

    /**
     * 文件差异列表
     */
    private List<FileDiffItem> fileDiffs;

    /**
     * API变更列表
     */
    private List<ApiDiffItem> apiDiffs;

    /**
     * 分析耗时（毫秒）
     */
    private Long duration;

    /**
     * 依赖分析摘要（多JAR分析时使用）
     */
    private DependencySummary dependencySummary;

    /**
     * 分析警告或建议
     */
    private List<String> warnings;

    /**
     * 源代码差异列表（反编译后的Java源码）
     */
    private List<FileSourceDiff> sourceDiffs;

    /**
     * 影响图谱数据（变更影响链路可视化）
     */
    private ImpactGraphResponse impactGraph;

    /**
     * 依赖分析摘要
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DependencySummary {
        /**
         * 是否启用了依赖分析
         */
        private boolean enabled;
        /**
         * 分析的依赖JAR数量（baseline）
         */
        private int baselineDependencyCount;
        /**
         * 分析的依赖JAR数量（target）
         */
        private int targetDependencyCount;
        /**
         * 分析的依赖JAR名称列表
         */
        private List<String> analyzedDependencies;
    }

    /**
     * 文件差异摘要
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FileSummary {
        private int addedFiles;
        private int modifiedFiles;
        private int deletedFiles;
        private int totalMethodsAdded;
        private int totalMethodsDeleted;
        private int totalMethodsModified;
        private int bytecodeTotalAdditions;
        private int bytecodeTotalDeletions;
        private int bytecodeBaselineTotalLines;
        private int bytecodeTargetTotalLines;
        private BusinessCodeSummary businessCodeSummary;
        // Total line counts (bytecode + business)
        private int totalAdditions;
        private int totalDeletions;
        private int baselineTotalLines;
        private int targetTotalLines;
    }

    /**
     * 业务代码统计摘要
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BusinessCodeSummary {
        private int totalAdditions;
        private int totalDeletions;
        private int baselineTotalLines;
        private int targetTotalLines;
        private Map<String, Integer> additionsByType;
        private Map<String, Integer> deletionsByType;
    }

    /**
     * API变更摘要
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ApiDiffSummary {
        private int newApis;
        private int modifiedApis;
        private int affectedApis;
        private int deletedApis;
    }

    /**
     * 文件差异项
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FileDiffItem {
        private String filePath;
        private String sourceFilePath;
        private String diffType;
        // 多JAR支持：记录来源JAR
        private String sourceJar;      // 来源JAR名称
        private String jarType;        // MAIN 或 DEPENDENCY
        private Integer baselineLines;
        private Integer targetLines;
        private Integer addedLines;
        private Integer deletedLines;
        private Integer methodsAdded;
        private Integer methodsDeleted;
        private Integer methodsModified;
        // 方法变更详情
        private List<MethodChange> methodChanges;

        @Data
        @Builder
        @NoArgsConstructor
        @AllArgsConstructor
        public static class MethodChange {
            private String methodName;
            private String changeType; // ADDED, DELETED, MODIFIED
        }
    }

    /**
     * API变更项
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ApiDiffItem {
        private String apiUrl;
        private String httpMethod;
        private String controllerClass;
        private String methodName;
        private String changeType;
        private String changeReason;
        private List<CallChainNode> callChain;

        @Data
        @Builder
        @NoArgsConstructor
        @AllArgsConstructor
        public static class CallChainNode {
            private String className;
            private String methodName;
            private int depth;
        }
    }
}
