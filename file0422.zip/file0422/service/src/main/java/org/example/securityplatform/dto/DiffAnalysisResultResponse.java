package org.example.securityplatform.dto;

import lombok.Data;

import java.util.List;

/**
 * 差异分析结果响应
 */
@Data
public class DiffAnalysisResultResponse {
    private Long diffTaskId;
    private Long projectId;
    private String status;
    private String errorMessage;

    // 基线和目标制品信息
    private ArtifactSummary baseline;
    private ArtifactSummary target;

    // 统计摘要
    private DiffSummary summary;

    // 文件差异列表
    private List<FileDiffSummary> fileDiffs;

    // API变更列表
    private List<ApiDiffSummary> apiDiffs;

    @Data
    public static class ArtifactSummary {
        private Long artifactId;
        private String artifactName;
        private Long fileSize;
        private String uploadTime;
    }

    @Data
    public static class DiffSummary {
        // 文件统计
        private long addedFiles;
        private long modifiedFiles;
        private long deletedFiles;

        // API统计
        private long newApis;
        private long modifiedApis;
        private long affectedApis;
        private long deletedApis;
    }
}
