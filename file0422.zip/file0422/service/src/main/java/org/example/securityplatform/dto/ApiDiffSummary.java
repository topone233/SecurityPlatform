package org.example.securityplatform.dto;

import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * API变更摘要
 */
@Data
public class ApiDiffSummary {
    private Long id;
    private String apiUrl;
    private String httpMethod;
    private String controllerClass;
    private String methodName;
    private String changeType; // NEW_API, MODIFIED_API, DELETED_API, AFFECTED_API
    private String changeReason;

    // 参数信息
    private List<Map<String, Object>> parameters;

    // 调用链
    private List<CallChainNode> callChain;

    // 关联的文件差异ID
    private Long[] relatedFileDiffIds;

    // 关联的危险函数
    private List<DangerFunctionInfo> dangerFunctions;

    @Data
    public static class CallChainNode {
        private String className;
        private String methodName;
        private Integer depth;
    }

    @Data
    public static class DangerFunctionInfo {
        private String name;
        private String type;
    }
}
