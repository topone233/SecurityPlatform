package org.example.securityplatform.repository;

import org.example.securityplatform.entity.ApiDiff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * API变更数据访问接口
 */
@Repository
public interface ApiDiffRepository extends JpaRepository<ApiDiff, Long> {
    List<ApiDiff> findByDiffTaskId(Long diffTaskId);
    List<ApiDiff> findByDiffTaskIdAndChangeType(Long diffTaskId, String changeType);
    long countByDiffTaskId(Long diffTaskId);
    long countByDiffTaskIdAndChangeType(Long diffTaskId, String changeType);
}
