package org.example.securityplatform.analyzer.jar;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Path;
import java.util.Collections;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;

import static org.junit.jupiter.api.Assertions.*;

class MultiJarClasspathBuilderResourceTest {

    @TempDir
    Path tempDir;

    @Test
    void testIndexResourceFiles() throws Exception {
        // Create test JAR with resource files
        File jarFile = tempDir.resolve("test.jar").toFile();
        try (JarOutputStream jos = new JarOutputStream(new FileOutputStream(jarFile))) {
            // Add a class file
            jos.putNextEntry(new JarEntry("com/example/Test.class"));
            jos.write("class content".getBytes());
            jos.closeEntry();

            // Add XML resource
            jos.putNextEntry(new JarEntry("config/test.xml"));
            jos.write("<root></root>".getBytes());
            jos.closeEntry();

            // Add YAML resource
            jos.putNextEntry(new JarEntry("config/app.yml"));
            jos.write("key: value".getBytes());
            jos.closeEntry();

            // Add properties resource
            jos.putNextEntry(new JarEntry("config.properties"));
            jos.write("prop=value".getBytes());
            jos.closeEntry();
        }

        // Build classpath - constructor: (jarPath, type, name)
        JarInfo jarInfo = new JarInfo(jarFile.getAbsolutePath(), JarInfo.JarType.MAIN, "test.jar");
        MultiJarClasspathBuilder builder = new MultiJarClasspathBuilder(Collections.singletonList(jarInfo));

        // Verify resource paths
        assertTrue(builder.getAllResourcePaths().contains("config/test.xml"));
        assertTrue(builder.getAllResourcePaths().contains("config/app.yml"));
        assertTrue(builder.getAllResourcePaths().contains("config.properties"));
        assertEquals(3, builder.getAllResourcePaths().size());

        // Verify class still indexed
        assertTrue(builder.getAllClassPaths().contains("com/example/Test.class"));
    }

    @Test
    void testNormalizeBootInfResourcePath() throws Exception {
        // Create Spring Boot Fat JAR with BOOT-INF structure
        File jarFile = tempDir.resolve("boot.jar").toFile();
        try (JarOutputStream jos = new JarOutputStream(new FileOutputStream(jarFile))) {
            jos.putNextEntry(new JarEntry("BOOT-INF/classes/config/application.yml"));
            jos.write("spring:\n  app: test".getBytes());
            jos.closeEntry();
        }

        JarInfo jarInfo = new JarInfo(jarFile.getAbsolutePath(), JarInfo.JarType.MAIN, "boot.jar");
        MultiJarClasspathBuilder builder = new MultiJarClasspathBuilder(Collections.singletonList(jarInfo));

        // Should normalize to config/application.yml
        assertTrue(builder.getAllResourcePaths().contains("config/application.yml"));
        assertFalse(builder.getAllResourcePaths().contains("BOOT-INF/classes/config/application.yml"));
    }
}