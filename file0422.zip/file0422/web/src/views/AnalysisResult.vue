<template>
  <div class="analysis-result">
    <el-card shadow="never" class="header-card">
      <template #header>
        <div class="card-header">
          <span>分析结果</span>
          <div>
            <el-button @click="goBack">返回</el-button>
            <el-button @click="goToChecklist">测试清单</el-button>
            <el-button type="primary" @click="goToExecution">开始测试</el-button>
          </div>
        </div>
      </template>

      <ProgressPanel
        v-if="progress.status === 'RUNNING'"
        :percentage="progress.progressPercentage"
        :status="progress.status"
        :current-step="progress.currentStep"
        title="分析进度"
      />

      <el-alert
        v-if="progress.status === 'FAILED'"
        type="error"
        :title="'分析失败'"
        :description="progress.message || '未知错误'"
        show-icon
        :closable="false"
        style="margin-top: 20px"
      />
    </el-card>

    <el-card shadow="never" style="margin-top: 20px" v-if="progress.status === 'COMPLETED'">
      <el-tabs v-model="activeTab">
        <el-tab-pane label="组件信息" name="components">
          <el-table :data="result.components" v-loading="loading" max-height="400">
            <el-table-column prop="componentName" label="组件名称" min-width="150" />
            <el-table-column prop="componentType" label="类型" width="120" />
            <el-table-column prop="version" label="版本" width="120" />
            <el-table-column prop="detectionSource" label="检测来源" width="120" />
          </el-table>
        </el-tab-pane>

        <el-tab-pane label="危险函数" name="dangers">
          <el-table :data="result.dangerFunctions" v-loading="loading" max-height="400">
            <el-table-column prop="functionName" label="函数名" min-width="150" />
            <el-table-column prop="functionType" label="类型" width="150" />
            <el-table-column prop="className" label="类名" min-width="200" />
          </el-table>
        </el-tab-pane>

        <el-tab-pane label="API信息" name="apis">
          <el-table :data="result.apis" v-loading="loading" max-height="400">
            <el-table-column prop="url" label="URL" min-width="200" />
            <el-table-column prop="httpMethod" label="方法" width="80">
              <template #default="{ row }">
                <el-tag :type="getMethodTag(row.httpMethod)" size="small">{{ row.httpMethod }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="controllerClass" label="Controller" min-width="150" />
            <el-table-column prop="methodName" label="Handler方法" min-width="150" />
          </el-table>
        </el-tab-pane>

        <el-tab-pane label="配置信息" name="configs">
          <el-table :data="result.configs" v-loading="loading" max-height="400">
            <el-table-column prop="configKey" label="配置键" min-width="200" />
            <el-table-column prop="configValue" label="配置值" show-overflow-tooltip />
            <el-table-column prop="configSource" label="来源" width="120" />
            <el-table-column prop="category" label="分类" width="120" />
          </el-table>
        </el-tab-pane>

        <el-tab-pane label="外部URL" name="urls">
          <el-table :data="result.urls" v-loading="loading" max-height="400">
            <el-table-column prop="url" label="URL" min-width="300" />
            <el-table-column prop="protocol" label="协议" width="100" />
            <el-table-column prop="usageContext" label="使用场景" min-width="200" />
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </el-card>

    <el-empty v-if="progress.status === 'PENDING' || progress.status === 'RUNNING'" description="分析尚未开始或正在进行中" />
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import analysisApi from '@/api/analysis'
import ProgressPanel from '@/components/common/ProgressPanel.vue'

const route = useRoute()
const router = useRouter()

const artifactId = route.params.artifactId
const activeTab = ref('components')

const progress = ref({
  percentage: 0,
  status: 'PENDING',
  currentStep: ''
})

const result = ref({
  components: [],
  dangerFunctions: [],
  apis: [],
  configs: [],
  urls: []
})

const loading = ref(false)
let pollTimer = null

// 轮询错误计数和超时配置
const errorCount = ref(0)
const maxErrors = 5  // 最大错误次数
const maxPollingTime = 10 * 60 * 1000  // 最大轮询时间 10分钟
let pollingStartTime = null

const goBack = () => {
  router.back()
}

const goToChecklist = () => {
  router.push(`/strategy/checklist/${artifactId}`)
}

const goToExecution = () => {
  router.push(`/execution/${artifactId}`)
}

const loadProgress = async () => {
  try {
    const data = await analysisApi.getProgress(artifactId)
    errorCount.value = 0  // 重置错误计数

    progress.value = data
    if (data.status === 'COMPLETED' || data.status === 'FAILED') {
      stopPolling()
      if (data.status === 'COMPLETED') {
        loadResult()
      }
    }
  } catch (e) {
    console.error('Failed to load progress:', e)
    errorCount.value++

    // 连续失败超过阈值，停止轮询
    if (errorCount.value >= maxErrors) {
      stopPolling()
      ElMessage.error('获取分析进度失败，请刷新页面重试')
      return
    }
  }
}

const loadResult = async () => {
  loading.value = true
  try {
    const data = await analysisApi.getResult(artifactId)
    result.value = {
      components: data.components || [],
      dangerFunctions: data.dangers || [],
      apis: data.apis || [],
      configs: data.configs || [],
      urls: data.urls || []
    }
    result.value.components.forEach(c => {
      c.version = c.version || '未知'
    })
  } catch (e) {
    console.error('Failed to load result:', e)
  } finally {
    loading.value = false
  }
}

const startPolling = () => {
  pollingStartTime = Date.now()
  loadProgress()
  pollTimer = setInterval(() => {
    // 检查是否超时
    if (Date.now() - pollingStartTime > maxPollingTime) {
      stopPolling()
      ElMessage.warning('分析超时，请检查分析状态')
      return
    }
    loadProgress()
  }, 3000)
}

const stopPolling = () => {
  if (pollTimer) {
    clearInterval(pollTimer)
    pollTimer = null
  }
}

const getMethodTag = (method) => {
  const types = {
    GET: 'success',
    POST: 'primary',
    PUT: 'warning',
    DELETE: 'danger',
    PATCH: 'info'
  }
  return types[method] || 'info'
}

onMounted(() => {
  startPolling()
})

onUnmounted(() => {
  stopPolling()
})
</script>

<style lang="scss" scoped>
.analysis-result {
  .header-card {
    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }
}
</style>
