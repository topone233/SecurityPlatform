<template>
  <div class="file-diff-viewer">
    <!-- Header -->
    <div class="diff-header">
      <span class="diff-file-path">{{ filePath || 'unknown' }}</span>
      <el-tag :type="diffTypeTag" size="small" class="diff-type-tag">
        {{ diffTypeLabel }}
      </el-tag>
      <!-- 字节码差异但源码相同的警告 -->
      <el-tag v-if="bytecodeDiffButSourceSame" type="warning" size="small">
        ⚠️ 字节码差异但源码相同
      </el-tag>
      <el-tag v-if="methodBlocks.length > 1" type="info" size="small">
        {{ methodBlocks.length }} 个块
      </el-tag>
      <el-tag v-if="unchangedCount > 0" type="info" size="small">
        {{ unchangedCount }} 未变更
      </el-tag>
      <el-tag v-if="modifiedCount > 0" type="warning" size="small">
        {{ modifiedCount }} 已修改
      </el-tag>
      <el-button v-if="unchangedCount > 0" size="small" @click="toggleAll">
        {{ allExpanded ? '全部折叠' : '全部展开' }}
      </el-button>
    </div>

    <!-- Error -->
    <el-alert v-if="error" type="error" :closable="false" :title="error"
              style="margin: 10px" />

    <!-- Method-aware diff -->
    <div v-else class="diff-content" ref="diffContentRef">
      <div class="diff-pane diff-pane-left" ref="leftPane" @scroll="onLeftScroll"
           :style="{ width: baselineWidth + '%' }">
        <div class="diff-pane-header">Baseline ({{ baselineWidth }}%)</div>
        <div class="diff-lines">
          <template v-for="(block, idx) in methodBlocks" :key="'l' + idx">
            <!-- Method block header (for all methods) -->
            <div v-if="block.type !== 'header'"
                 class="method-block"
                 :class="block.status"
                 @click="block.status === 'unchanged' && toggleMethod(idx)">
              <span v-if="block.status === 'unchanged'" class="collapse-icon">
                {{ expandedMethods.has(idx) ? '▼' : '▶' }}
              </span>
              <span class="method-sig">{{ block.signature }}</span>
              <span class="method-status" :class="block.status">
                {{ blockStatusLabel(block.status) }}
              </span>
            </div>
            <!-- Class header block -->
            <div v-else class="method-block" :class="block.status">
              <span class="method-sig">{{ block.signature }}</span>
              <span class="method-status" :class="block.status">
                {{ blockStatusLabel(block.status) }}
              </span>
            </div>
            <!-- Unchanged method: show lines only when expanded -->
            <template v-if="block.type !== 'header' && block.status === 'unchanged' && expandedMethods.has(idx)">
              <div v-for="(row, lidx) in block.lines" :key="'l' + idx + '-' + lidx"
                   class="diff-line equal">
                <span class="line-num">{{ row.leftNum || '' }}</span>
                <span class="line-prefix"> </span>
                <pre class="line-text">{{ row.leftText }}</pre>
              </div>
            </template>
            <!-- Changed/Added/Deleted block: show diff lines -->
            <template v-if="block.type === 'header' || block.status !== 'unchanged'">
              <div v-for="(row, lidx) in block.lines" :key="'l' + idx + '-' + lidx"
                   :class="['diff-line', row.leftType]">
                <span class="line-num">{{ row.leftNum || '' }}</span>
                <span class="line-prefix">{{ leftPrefix(row.leftType) }}</span>
                <pre class="line-text">{{ row.leftText }}</pre>
              </div>
            </template>
          </template>
        </div>
      </div>
      <div class="resize-handle"
           :class="{ 'resizing': isResizing }"
           @mousedown="startResize">
      </div>
      <div class="diff-pane diff-pane-right" ref="rightPane" @scroll="onRightScroll"
           :style="{ width: targetWidth + '%' }">
        <div class="diff-pane-header">Target ({{ targetWidth }}%)</div>
        <div class="diff-lines">
          <template v-for="(block, idx) in methodBlocks" :key="'r' + idx">
            <!-- Method block header (for all methods) -->
            <div v-if="block.type !== 'header'"
                 class="method-block"
                 :class="block.status"
                 @click="block.status === 'unchanged' && toggleMethod(idx)">
              <span v-if="block.status === 'unchanged'" class="collapse-icon">
                {{ expandedMethods.has(idx) ? '▼' : '▶' }}
              </span>
              <span class="method-sig">{{ block.signature }}</span>
              <span class="method-status" :class="block.status">
                {{ blockStatusLabel(block.status) }}
              </span>
            </div>
            <!-- Class header block -->
            <div v-else class="method-block" :class="block.status">
              <span class="method-sig">{{ block.signature }}</span>
              <span class="method-status" :class="block.status">
                {{ blockStatusLabel(block.status) }}
              </span>
            </div>
            <!-- Unchanged method: show lines only when expanded -->
            <template v-if="block.type !== 'header' && block.status === 'unchanged' && expandedMethods.has(idx)">
              <div v-for="(row, lidx) in block.lines" :key="'r' + idx + '-' + lidx"
                   class="diff-line equal">
                <span class="line-num">{{ row.rightNum || '' }}</span>
                <span class="line-prefix"> </span>
                <pre class="line-text">{{ row.rightText }}</pre>
              </div>
            </template>
            <!-- Changed/Added/Deleted block: show diff lines -->
            <template v-if="block.type === 'header' || block.status !== 'unchanged'">
              <div v-for="(row, lidx) in block.lines" :key="'r' + idx + '-' + lidx"
                   :class="['diff-line', row.rightType]">
                <span class="line-num">{{ row.rightNum || '' }}</span>
                <span class="line-prefix">{{ rightPrefix(row.rightType) }}</span>
                <pre class="line-text">{{ row.rightText }}</pre>
              </div>
            </template>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref, onUnmounted } from 'vue'
import * as Diff from 'diff'

const props = defineProps({
  baselineSource: { type: String, default: '' },
  targetSource: { type: String, default: '' },
  filePath: { type: String, default: '' },
  diffType: { type: String, default: 'MODIFIED' },
  error: { type: String, default: null },
  bytecodeDiffButSourceSame: { type: Boolean, default: false },
  originalDiffType: { type: String, default: '' }
})

const leftPane = ref(null)
const rightPane = ref(null)
const expandedMethods = ref(new Set([0])) // 默认展开第一个方法
const allExpanded = ref(false)
let scrolling = false

// Resize state
const baselineWidth = ref(50) // percentage
const targetWidth = computed(() => 100 - baselineWidth.value)
const isResizing = ref(false)
const diffContentRef = ref(null)

const diffTypeTag = computed(() => {
  // 优先使用方法级 diff 的实际状态
  const actualStatus = actualDiffType.value
  const map = { ADDED: 'success', MODIFIED: 'warning', DELETED: 'danger', UNCHANGED: 'info' }
  return map[actualStatus] || 'info'
})

const diffTypeLabel = computed(() => {
  const actualStatus = actualDiffType.value
  const map = { ADDED: '新增', MODIFIED: '修改', DELETED: '删除', UNCHANGED: '未变更' }
  return map[actualStatus] || actualStatus
})

// 根据 methodBlocks 的实际状态重新计算 diffType
const actualDiffType = computed(() => {
  // 如果有新增方法但无删除 → ADDED
  const hasAdded = methodBlocks.value.some(b => b.status === 'added')
  const hasDeleted = methodBlocks.value.some(b => b.status === 'deleted')
  const hasModified = methodBlocks.value.some(b => b.status === 'modified')

  // 根据方法变更情况推断文件状态
  if (hasAdded && !hasDeleted && !hasModified) return 'ADDED'
  if (hasDeleted && !hasAdded && !hasModified) return 'DELETED'
  if (hasAdded || hasDeleted || hasModified) return 'MODIFIED'

  // 所有块都未变更
  return 'UNCHANGED'
})

const unchangedCount = computed(() => {
  return methodBlocks.value.filter(b => b.status === 'unchanged').length
})

const modifiedCount = computed(() => {
  return methodBlocks.value.filter(b => b.status !== 'unchanged').length
})

// Parse source into blocks: class header + methods
function parseBlocks(source) {
  if (!source) return { header: null, methods: [] }

  const lines = source.split('\n')
  const methods = []

  // Regex for method signatures (both interface and class methods)
  // Matches: [annotations] [modifiers] return_type name(params) [throws] { or ;
  const methodSigRegex = /^\s*(?:(?:public|private|protected|static|final|abstract|synchronized|native|strictfp)\s+)*(?:\w+(?:<[^>]+>)?(?:\[\])*)\s+(\w+)\s*\([^)]*\)\s*(?:throws\s+[\w\s,.]+)?\s*([;{])/

  // Regex for annotation lines
  const annotationRegex = /^\s*@/

  // Regex for class/interface/enum declaration
  const classDeclRegex = /^\s*(?:public\s+)?(?:abstract\s+)?(?:class|interface|enum|record)\s+(\w+)/

  // Find class declaration line to determine header start
  let classDeclLine = -1
  for (let i = 0; i < lines.length; i++) {
    if (classDeclRegex.test(lines[i])) {
      classDeclLine = i
      break
    }
  }

  // Extract methods by scanning through the file
  let i = 0

  // First, skip to the class declaration
  while (i < lines.length && classDeclLine >= 0 && i < classDeclLine) {
    i++
  }

  // Now scan for methods
  while (i < lines.length) {
    const line = lines[i]

    // Skip empty lines and comments
    if (line.trim() === '' || line.trim().startsWith('//') || line.trim().startsWith('/*') || line.trim().startsWith('*')) {
      i++
      continue
    }

    // Collect annotations before method
    const annotations = []
    while (i < lines.length && annotationRegex.test(lines[i])) {
      annotations.push(lines[i])
      i++
    }

    if (i >= lines.length) break

    // Check if current line is a method signature
    const currentLine = lines[i]
    if (methodSigRegex.test(currentLine)) {
      const match = currentLine.match(methodSigRegex)
      if (match) {
        const methodName = match[1]
        const endsWithBrace = match[2] === '{'
        const isInterfaceMethod = !endsWithBrace

        // Build method signature (include annotations)
        const sigLines = [...annotations, currentLine]
        const signature = sigLines.join(' ').replace(/\s+/g, ' ').replace(/[;{]$/, '').trim()

        const method = {
          name: methodName,
          signature: signature,
          uniqueId: signature,  // 使用完整签名作为唯一标识，避免重载方法被错误覆盖
          startLine: i - annotations.length,
          lines: [...annotations, currentLine],
          isInterface: isInterfaceMethod
        }

        i++

        if (isInterfaceMethod) {
          // Interface method: single line ending with ;
          methods.push(method)
        } else {
          // Regular method: track braces
          let braceDepth = (currentLine.match(/\{/g) || []).length
          braceDepth -= (currentLine.match(/\}/g) || []).length

          while (i < lines.length && braceDepth > 0) {
            method.lines.push(lines[i])
            braceDepth += (lines[i].match(/\{/g) || []).length
            braceDepth -= (lines[i].match(/\}/g) || []).length
            i++
          }

          methods.push(method)
        }
        continue
      }
    }

    i++
  }

  // Determine header: everything before the first method (or first annotation before method)
  const firstMethodLine = methods.length > 0 ? methods[0].startLine : lines.length
  const headerLines = lines.slice(0, firstMethodLine)
  const header = headerLines.length > 0 ? { lines: headerLines, startLine: 0 } : null

  return { header, methods }
}

const methodBlocks = computed(() => {
  if (props.error) return []

  const baseline = props.baselineSource || ''
  const target = props.targetSource || ''

  // ADDED file: all green
  if (!baseline && target) {
    const { header, methods } = parseBlocks(target)
    const blocks = []

    if (header) {
      blocks.push({
        type: 'header',
        signature: '类定义/导入',
        status: 'added',
        lines: header.lines.map((text, i) => ({
          leftNum: '', leftText: '', leftType: 'empty',
          rightNum: i + 1, rightText: text, rightType: 'added'
        }))
      })
    }

    for (const m of methods) {
      blocks.push({
        type: 'method',
        signature: m.signature || m.name,
        status: 'added',
        lines: m.lines.map((text, i) => ({
          leftNum: '', leftText: '', leftType: 'empty',
          rightNum: i + 1, rightText: text, rightType: 'added'
        }))
      })
    }

    return blocks
  }

  // DELETED file: all red
  if (baseline && !target) {
    const { header, methods } = parseBlocks(baseline)
    const blocks = []

    if (header) {
      blocks.push({
        type: 'header',
        signature: '类定义/导入',
        status: 'deleted',
        lines: header.lines.map((text, i) => ({
          leftNum: i + 1, leftText: text, leftType: 'removed',
          rightNum: '', rightText: '', rightType: 'empty'
        }))
      })
    }

    for (const m of methods) {
      blocks.push({
        type: 'method',
        signature: m.signature || m.name,
        status: 'deleted',
        lines: m.lines.map((text, i) => ({
          leftNum: i + 1, leftText: text, leftType: 'removed',
          rightNum: '', rightText: '', rightType: 'empty'
        }))
      })
    }

    return blocks
  }

  // MODIFIED: block-aware diff
  const baselineParsed = parseBlocks(baseline)
  const targetParsed = parseBlocks(target)
  const blocks = []

  // 1. Compare headers - always show header block
  const headerDiff = diffBlock(
    baselineParsed.header?.lines || [],
    targetParsed.header?.lines || [],
    'Header (类定义/导入)'
  )
  blocks.push({
    type: 'header',
    signature: '类定义/导入',
    status: headerDiff.status,
    lines: headerDiff.lines
  })

  // 2. Compare methods
  const baselineMethods = baselineParsed.methods
  const targetMethods = targetParsed.methods

  const baselineMap = new Map(baselineMethods.map(m => [m.uniqueId || m.signature, m]))
  const targetMap = new Map(targetMethods.map(m => [m.uniqueId || m.signature, m]))
  const processedNames = new Set()

  // Process in target order
  for (const targetMethod of targetMethods) {
    const uniqueId = targetMethod.uniqueId || targetMethod.signature
    const baselineMethod = baselineMap.get(uniqueId)

    if (baselineMethod) {
      const baselineText = baselineMethod.lines.join('\n')
      const targetText = targetMethod.lines.join('\n')

      if (baselineText === targetText && baselineMethod.lines.length === targetMethod.lines.length) {
        blocks.push({
          type: 'method',
          signature: targetMethod.signature || uniqueId,
          status: 'unchanged',
          lines: targetMethod.lines.map((text, i) => ({
            leftNum: i + 1, leftText: text, leftType: 'equal',
            rightNum: i + 1, rightText: text, rightType: 'equal'
          }))
        })
      } else {
        const diff = diffBlock(baselineMethod.lines, targetMethod.lines, uniqueId)
        blocks.push({
          type: 'method',
          signature: targetMethod.signature || uniqueId,
          status: diff.status,
          lines: diff.lines
        })
      }
      processedNames.add(uniqueId)
    } else {
      blocks.push({
        type: 'method',
        signature: targetMethod.signature || uniqueId,
        status: 'added',
        lines: targetMethod.lines.map((text, i) => ({
          leftNum: '', leftText: '', leftType: 'empty',
          rightNum: i + 1, rightText: text, rightType: 'added'
        }))
      })
      processedNames.add(uniqueId)
    }
  }

  // Deleted methods
  for (const baselineMethod of baselineMethods) {
    if (!processedNames.has(baselineMethod.uniqueId || baselineMethod.signature)) {
      blocks.push({
        type: 'method',
        signature: baselineMethod.signature || baselineMethod.name,
        status: 'deleted',
        lines: baselineMethod.lines.map((text, i) => ({
          leftNum: i + 1, leftText: text, leftType: 'removed',
          rightNum: '', rightText: '', rightType: 'empty'
        }))
      })
    }
  }

  return blocks
})

function diffBlock(baselineLines, targetLines, methodSignature = 'unknown') {
  const baselineText = (baselineLines || []).join('\n')
  const targetText = (targetLines || []).join('\n')

  if (baselineText === targetText) {
    return {
      status: 'unchanged',
      lines: targetLines.map((text, i) => ({
        leftNum: i + 1, leftText: text, leftType: 'equal',
        rightNum: i + 1, rightText: text, rightType: 'equal'
      }))
    }
  }

  const changes = Diff.diffLines(baselineText, targetText)

  const lines = []
  let leftLine = 1, rightLine = 1

  for (const change of changes) {
    const changeLines = (change.value || '').replace(/\n$/, '').split('\n')
    if (change.added) {
      for (const text of changeLines) {
        lines.push({
          leftNum: '', leftText: '', leftType: 'empty',
          rightNum: rightLine++, rightText: text, rightType: 'added'
        })
      }
    } else if (change.removed) {
      for (const text of changeLines) {
        lines.push({
          leftNum: leftLine++, leftText: text, leftType: 'removed',
          rightNum: '', rightText: '', rightType: 'empty'
        })
      }
    } else {
      for (const text of changeLines) {
        lines.push({
          leftNum: leftLine++, leftText: text, leftType: 'equal',
          rightNum: rightLine++, rightText: text, rightType: 'equal'
        })
      }
    }
  }

  // Determine status - 对于已存在的方法，即使只有新增行也应该是 'modified'
  const hasRemoved = lines.some(l => l.leftType === 'removed')
  const hasAdded = lines.some(l => l.rightType === 'added')

  let status = 'modified'  // 默认是 modified，因为方法已存在于两边
  // 只有当方法本身是新增或删除时，才使用 added/deleted 状态
  // 对于已匹配的方法，只要有任何变更就是 modified

  return { status, lines }
}

function blockStatusLabel(status) {
  const labels = { added: '新增', modified: '修改', deleted: '删除', unchanged: '未变更' }
  return labels[status] || status
}

function toggleMethod(idx) {
  if (expandedMethods.value.has(idx)) {
    expandedMethods.value.delete(idx)
  } else {
    expandedMethods.value.add(idx)
  }
  expandedMethods.value = new Set(expandedMethods.value)
}

function toggleAll() {
  if (allExpanded.value) {
    expandedMethods.value = new Set([0])
    allExpanded.value = false
  } else {
    const all = new Set()
    for (let i = 0; i < methodBlocks.value.length; i++) {
      all.add(i)
    }
    expandedMethods.value = all
    allExpanded.value = true
  }
}

function leftPrefix(type) {
  return type === 'removed' ? '-' : ' '
}

function rightPrefix(type) {
  return type === 'added' ? '+' : ' '
}

function onLeftScroll(e) {
  if (scrolling) return
  scrolling = true
  if (rightPane.value) {
    rightPane.value.scrollTop = e.target.scrollTop
  }
  requestAnimationFrame(() => { scrolling = false })
}

function onRightScroll(e) {
  if (scrolling) return
  scrolling = true
  if (leftPane.value) {
    leftPane.value.scrollTop = e.target.scrollTop
  }
  requestAnimationFrame(() => { scrolling = false })
}

// Resize functionality
function startResize(e) {
  isResizing.value = true
  const container = diffContentRef.value
  if (!container) return

  const containerRect = container.getBoundingClientRect()
  const startX = e.clientX

  const onMouseMove = (e) => {
    const currentX = e.clientX
    const deltaX = currentX - startX
    const newWidth = ((containerRect.width / 2 + deltaX) / containerRect.width) * 100

    // Allow 0-100% range
    baselineWidth.value = Math.max(0, Math.min(100, newWidth))
  }

  const onMouseUp = () => {
    isResizing.value = false
    document.removeEventListener('mousemove', onMouseMove)
    document.removeEventListener('mouseup', onMouseUp)
  }

  document.addEventListener('mousemove', onMouseMove)
  document.addEventListener('mouseup', onMouseUp)
}

// Cleanup on component unmount
onUnmounted(() => {
  // Remove any dangling event listeners (safety measure)
  document.removeEventListener('mousemove', () => {})
  document.removeEventListener('mouseup', () => {})
})
</script>

<style scoped>
.file-diff-viewer {
  height: 100%;
  display: flex;
  flex-direction: column;
  background: #fff;
  border-radius: 4px;
  overflow: hidden;
}

.diff-header {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 16px;
  background: #f5f7fa;
  border-bottom: 1px solid #e4e7ed;
  font-size: 13px;
}

.diff-file-path {
  font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
  color: #606266;
  word-break: break-all;
}

.diff-content {
  flex: 1;
  display: flex;
  overflow: hidden;
}

.diff-pane {
  overflow: auto;
  min-width: 0;
}

.diff-pane-header {
  position: sticky;
  top: 0;
  z-index: 1;
  padding: 4px 12px;
  background: #fafafa;
  border-bottom: 1px solid #e4e7ed;
  font-size: 12px;
  color: #909399;
  text-align: center;
  font-weight: 500;
}

.resize-handle {
  width: 6px;
  background: #dcdfe6;
  flex-shrink: 0;
  cursor: col-resize;
  position: relative;
  transition: background 0.2s ease;
}

.resize-handle:hover {
  background: #409eff;
}

.resize-handle.resizing {
  background: #409eff;
}

.method-block {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  background: #f5f7fa;
  border-bottom: 1px solid #e4e7ed;
  font-size: 12px;
  font-family: 'SFMono-Regular', Consolas, monospace;
}

.method-block.unchanged {
  background: #f5f7fa;
  color: #909399;
}

.method-block.collapsed {
  cursor: pointer;
  user-select: none;
}

.method-block.collapsed:hover {
  background: #eef0f3;
}

.method-block.added {
  background: #e6ffec;
}

.method-block.deleted {
  background: #ffebe9;
}

.method-block.modified {
  background: #fff8e6;
}

.collapse-icon {
  width: 16px;
  color: #909399;
  font-size: 10px;
}

.method-sig {
  flex: 1;
  color: #606266;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.method-status {
  flex-shrink: 0;
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 3px;
}

.method-status.unchanged {
  background: #f0f2f5;
  color: #909399;
}

.method-status.added {
  background: #28a745;
  color: #fff;
}

.method-status.deleted {
  background: #cb2431;
  color: #fff;
}

.method-status.modified {
  background: #f5a623;
  color: #fff;
}

.diff-line {
  display: flex;
  align-items: stretch;
  min-height: 20px;
  line-height: 20px;
  font-size: 12px;
}

.diff-line.equal {
  background: #fff;
}

.diff-line.added {
  background: #e6ffec;
}

.diff-line.removed {
  background: #ffebe9;
}

.diff-line.empty {
  background: #fafbfc;
}

.line-num {
  flex-shrink: 0;
  width: 50px;
  text-align: right;
  padding: 0 8px;
  color: #adb5bd;
  background: #fafbfc;
  border-right: 1px solid #e4e7ed;
  user-select: none;
  font-family: 'SFMono-Regular', Consolas, monospace;
  font-size: 11px;
}

.diff-line.empty .line-num {
  background: #f0f0f0;
}

.line-prefix {
  flex-shrink: 0;
  width: 20px;
  text-align: center;
  color: #909399;
  user-select: none;
  font-family: 'SFMono-Regular', Consolas, monospace;
  font-weight: bold;
}

.diff-line.added .line-prefix {
  color: #22863a;
}

.diff-line.removed .line-prefix {
  color: #cb2431;
}

.line-text {
  flex: 1;
  margin: 0;
  padding: 0 8px;
  white-space: pre;
  font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
  font-size: 12px;
  color: #24292e;
  overflow-x: auto;
  min-width: 0;
}
</style>