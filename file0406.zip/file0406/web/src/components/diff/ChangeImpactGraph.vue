<template>
  <div class="change-impact-graph">
    <div v-if="loading" class="loading-container">
      <el-progress type="circle" :percentage="100" :indeterminate="true" />
      <p>加载变更影响图谱...</p>
    </div>

    <div v-else-if="graphData" class="graph-container" ref="graphContainer"></div>

    <el-empty v-else description="暂无变更影响数据" />
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, watch, nextTick } from 'vue'
import { Graph } from '@antv/g6'
import diffAnalysisApi from '@/api/diffAnalysis'

const props = defineProps({
  diffTaskId: {
    type: [Number, String],
    required: false  // 改为可选，支持通过 graphData 直接传入数据
  },
  graphData: {
    type: Object,
    default: null  // 新增：支持直接传入图谱数据（用于快速比对）
  },
  focusChangeId: {
    type: String,
    default: null
  },
  filters: {
    type: Object,
    default: () => ({
      riskLevels: ['HIGH', 'MEDIUM', 'LOW'],
      changeTypes: ['ADDED', 'MODIFIED', 'DELETED']
    })
  }
})

const emit = defineEmits(['node-click'])

const graphContainer = ref(null)
const graph = ref(null)
const graphData = ref(null)
const loading = ref(true)

const loadImpactGraph = async () => {
  loading.value = true
  try {
    let data = null

    // 方式1：直接使用传入的图谱数据（用于快速比对）
    if (props.graphData) {
      data = props.graphData
      console.log('使用传入的图谱数据:', data)
    }
    // 方式2：通过API获取图谱数据（用于差异分析任务）
    else if (props.diffTaskId) {
      data = await diffAnalysisApi.getImpactGraph(props.diffTaskId, props.filters)
      console.log('从API获取图谱数据:', data)
    }

    graphData.value = data
    if (data) {
      console.log('图谱数据统计:', {
        changes: data.changes?.length || 0,
        affected: data.affected?.length || 0,
        apis: data.apis?.length || 0,
        callEdges: data.callEdges?.length || 0,
        impactEdges: data.impactEdges?.length || 0
      })
      // 先设置loading=false，等待DOM更新后再渲染
      loading.value = false
      await nextTick()
      renderGraph(data)
    } else {
      console.warn('图谱数据为空')
      loading.value = false
    }
  } catch (e) {
    console.error('Failed to load impact graph:', e)
    loading.value = false
  }
}

const renderGraph = (data) => {
  console.log('renderGraph被调用，graphContainer.value:', graphContainer.value)
  if (!graphContainer.value) {
    console.error('graphContainer.value为null，无法渲染图谱！')
    return
  }

  const width = graphContainer.value.offsetWidth
  const height = graphContainer.value.offsetHeight || 600
  console.log('图谱容器尺寸:', { width, height })

  // 构建节点和边
  const nodes = buildNodes(data)
  const edges = buildEdges(data)

  // 创建图谱实例
  graph.value = new Graph({
    container: graphContainer.value,
    width,
    height,
    autoFit: 'view',
    padding: 20,
    behaviors: ['drag-canvas', 'zoom-canvas', 'drag-element'],
    layout: {
      type: 'dagre',
      rankdir: 'LR', // 从左到右
      nodesep: 80,
      ranksep: 120
    },
    node: {
      style: {
        size: (d) => {
          const label = d.data?.label || ''
          const lines = label.split('\n').length
          return [Math.max(150, label.length * 8), Math.max(40, lines * 20)]
        },
        fill: (d) => {
          const type = d.data?.nodeType
          if (type === 'change') return '#FFCDD2' // 红色 - 变更点
          if (type === 'api') return '#BBDEFB' // 蓝色 - API
          const risk = d.data?.riskLevel
          if (risk === 'HIGH') return '#FFCCBC' // 橙色
          if (risk === 'MEDIUM') return '#FFE0B2' // 黄色
          return '#E8F5E9' // 绿色
        },
        stroke: (d) => {
          const risk = d.data?.riskLevel
          if (risk === 'HIGH') return '#E53935'
          if (risk === 'MEDIUM') return '#FB8C00'
          return '#43A047'
        },
        lineWidth: 2,
        labelText: (d) => d.data?.label || '',
        labelFontSize: 12,
        labelFill: '#424242'
      }
    },
    edge: {
      style: {
        stroke: (d) => d.data?.edgeType === 'impact' ? '#FF9800' : '#5B8FF9',
        lineWidth: 2,
        lineDash: (d) => d.data?.edgeType === 'impact' ? [5, 5] : [],
        endArrow: true
      }
    }
  })

  // 设置数据
  graph.value.setData({ nodes, edges })

  // 绑定事件
  graph.value.on('node:click', (event) => {
    const node = event.target
    emit('node-click', node.data)
  })

  // 渲染
  graph.value.render()
}

const buildNodes = (data) => {
  const nodes = []
  const nodeMap = new Map()

  // 添加变更节点
  if (data.changes) {
    data.changes.forEach(change => {
      const nodeId = `change-${change.id}`
      if (!nodeMap.has(nodeId)) {
        nodes.push({
          id: nodeId,
          data: {
            nodeType: 'change',
            label: `${change.className.split('.').pop()}\n${change.methodName}()`,
            ...change
          }
        })
        nodeMap.set(nodeId, true)
      }
    })
  }

  // 添加受影响节点
  if (data.affected) {
    data.affected.forEach(affected => {
      const nodeId = `affected-${affected.id}`
      if (!nodeMap.has(nodeId)) {
        nodes.push({
          id: nodeId,
          data: {
            nodeType: 'affected',
            label: `${affected.className.split('.').pop()}\n${affected.methodName}()`,
            ...affected
          }
        })
        nodeMap.set(nodeId, true)
      }
    })
  }

  // 添加API节点
  if (data.apis) {
    data.apis.forEach(api => {
      const nodeId = `api-${api.id}`
      if (!nodeMap.has(nodeId)) {
        nodes.push({
          id: nodeId,
          data: {
            nodeType: 'api',
            label: `${api.controllerClass?.split('.').pop() || 'Unknown'}\n${api.httpMethod} ${api.apiUrl}`,
            ...api
          }
        })
        nodeMap.set(nodeId, true)
      }
    })
  }

  console.log('构建节点:', nodes.length, '个', nodes)
  return nodes
}

const buildEdges = (data) => {
  const edges = []

  // 添加调用边（affected节点之间的调用关系）
  if (data.callEdges && data.callEdges.length > 0) {
    data.callEdges.forEach(edge => {
      // 查找source节点是change还是affected
      const sourceIsChange = data.changes?.some(c => c.id === edge.sourceId)
      const sourceIsAffected = data.affected?.some(a => a.id === edge.sourceId)
      const targetIsAffected = data.affected?.some(a => a.id === edge.targetId)

      const sourcePrefix = sourceIsChange ? 'change' : (sourceIsAffected ? 'affected' : 'change')
      const targetPrefix = targetIsAffected ? 'affected' : 'affected'

      const edgeData = {
        id: `call-edge-${edge.id}`,
        source: `${sourcePrefix}-${edge.sourceId}`,
        target: `${targetPrefix}-${edge.targetId}`,
        data: {
          edgeType: 'call',
          callLine: edge.callLine
        }
      }
      edges.push(edgeData)
      console.log('调用边:', edgeData.id, 'source:', edgeData.source, '-> target:', edgeData.target)
    })
  }

  // 添加影响边（连接change/affected节点到API节点）
  if (data.impactEdges && data.impactEdges.length > 0) {
    data.impactEdges.forEach(edge => {
      // 查找source节点是change还是affected
      const sourceIsChange = data.changes?.some(c => c.id === edge.sourceId)
      const sourceIsAffected = data.affected?.some(a => a.id === edge.sourceId)

      const sourcePrefix = sourceIsChange ? 'change' : (sourceIsAffected ? 'affected' : 'change')

      const edgeData = {
        id: `impact-edge-${edge.id}`,
        source: `${sourcePrefix}-${edge.sourceId}`,
        target: `api-${edge.targetId}`,
        data: {
          edgeType: 'impact'
        }
      }
      edges.push(edgeData)
      console.log('影响边:', edgeData.id, 'source:', edgeData.source, '-> target:', edgeData.target)
    })
  }

  console.log('构建边:', edges.length, '条', edges)
  return edges
}

onMounted(() => {
  loadImpactGraph()
})

onBeforeUnmount(() => {
  if (graph.value) {
    graph.value.destroy()
  }
})

// 监听 graphData prop 变化（用于快速比对动态数据）
watch(() => props.graphData, async (newData, oldData) => {
  // 只在数据真正变化且非首次加载时处理（首次由onMounted处理）
  if (newData && oldData && newData !== oldData) {
    graphData.value = newData
    loading.value = false
    await nextTick()
    renderGraph(newData)
  }
}, { immediate: false }) // 改为false，避免与onMounted冲突

// 监听 filters 变化（用于差异分析任务）
watch(() => props.filters, () => {
  if (props.diffTaskId) {
    loadImpactGraph()
  }
}, { deep: true })
</script>

<style lang="scss" scoped>
.change-impact-graph {
  width: 100%;
  height: 600px;

  .loading-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
  }

  .graph-container {
    width: 100%;
    height: 100%;
  }
}
</style>