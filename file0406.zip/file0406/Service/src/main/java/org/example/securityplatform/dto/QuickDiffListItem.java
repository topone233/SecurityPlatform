package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 快速差异对比列表项响应
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QuickDiffListItem {
    /**
     * 记录ID
     */
    private Long id;

    /**
     * 基线文件名
     */
    private String baselineFileName;

    /**
     * 目标文件名
     */
    private String targetFileName;

    /**
     * 分析耗时（毫秒）
     */
    private Long durationMs;

    /**
     * 描述
     */
    private String description;

    /**
     * 创建时间
     */
    private LocalDateTime createdAt;

    /**
     * 总文件变更数
     */
    private Integer totalFilesChanged;

    /**
     * 总方法变更数
     */
    private Integer totalMethodChanges;

    /**
     * 总API变更数
     */
    private Integer totalApiChanges;

    }
